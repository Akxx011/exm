function saveRegForm() {
	

	 var checkArray = [ "nameOfExaminee", "rollNumber", "registrationNumber",
	 "email", "mobileNumber", "gender", "category", "address",
	 "countryId", "stateId", "cityId", "pin"];
	 var msgArray = [ "Please enter nameOfExaminee", "Please enter RollNumber",
	 "Please enter RegistrationNumber", "Please enter Email",
	 "Please enter MobileNumber", "Please enter Gender",
	 "Please enter Category", "Please enter Address",
	 "Please select Country", "Please select State",
	 "Please select City", "Please enter Pin"];
	
	 if (validateFields(checkArray, 1, msgArray)) {
		 if (!$('#isChk').is(':checked')) {
			 $.alert.open('Please accept the term..!!');
		        $('#isChk').focus();
		        return false;
		    } 
		if (confirm("You are going to create Pre Registration Detail. Are you sure ?")) {
			document.form1.submit();
			
		}
		}
}
function loadCountry() {

	var htmlStr = "<option value=-1><b>Country</b></option>";
	$.ajax({
		type : "get",
		url : "eontdmlecGetCountry",

		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].countryId + ">"
						+ response[i].countryName + "</option>";
			}
			$('#country').html(htmlStr);
		},
		error : function() {
			$.alert.open('Error while load Country');
		}
	});
}
/*
 * This function is call the controller " lecGetState" and Get the no of State
 * and Set all the states in the dropDown
 */
function loadState(obj) {

	var htmlStr = "<option value=-1><b>State</b></option>";
	$.ajax({
		type : "get",
		url : "eontdmlecGetStateRegistration?countryID=" + obj.value,

		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].stateId + ">"
						+ response[i].stateName + "</option>";
			}

			$('#state').html(htmlStr);
		},
		error : function() {
			$.alert.open('Error while load State');
		}
	});
}

/*
 * This function is call the controller " lecGetCity" and Get the no of City and
 * Set all the City in the dropDown
 */
function loadCity(obj) {

	var htmlStr = "<option value=-1><b>City</b></option>";
	$.ajax({
		type : "get",
		url : "eontdmlecGetCityRegistration?stateId=" + obj.value,
		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].cityId + ">"
						+ response[i].cityName + "</option>";
			}

			$('#city').html(htmlStr);

		},
		error : function() {
			$.alert.open('Error while load city');
		}
	});
}
function authenticateRollNo(obj) {
	if (obj.value == "") {

		return;
	}
	$.ajax({
		type : "get",
		url : "eontdmauthenticateRollNo?rollNo=" + obj.value,
		cache : false,
		success : function(response) {

			if (response == 0) {
				$.alert.open("Please enter the correct Roll Number");
				$("#rollNumber").focus();
			}
		},
		error : function() {
			$.alert.open('Error while  authenticateRollNo');
		}
	});
}
function authenticateRegsNo(obj) {

	if (obj.value == "") {

		return;
	}
	$.ajax({
		type : "get",
		url : "eontdmauthenticateRegsNo?regNo=" + obj.value,
		cache : false,
		success : function(response) {
			
			if (response == 0) {
				$.alert.open("Please enter the correct Registration Number");
				$("#registrationNumber").focus();
			}
		},
		error : function() {
			$.alert.open('Error while authenticate Regs No');
		}
	});
}	
function clearRegField(){
	//alert(">>>>>>>>>>>>>>>>>>>");
	$("#gender").html("<option value=-1>Select Gender</option>");
	$("input:text").each(function(i) {
	       this.value = "";
	});
		
	  
}
