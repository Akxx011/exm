function unlockLoginPage() {
	
	 var checkArray = ["username", "password", "unlockCode"];
	 var msgArray = [ "Please enter username", "Please enter password", "Please enter unlockCode"];
	
	 if (validateFields(checkArray, 1, msgArray)) {
		
		if (confirm("You are going to unlock. Are you sure ?")) {
			document.form1.submit();
			
		}
		}
}