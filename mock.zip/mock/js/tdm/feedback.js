function loadFeedBackQuestion(){

	var htmlstr="";
	$.ajax({
   		type : "get",
   		url : "tdmloadFeedbackQuestion",
   		cache : false,
   		success : function(response) {
   			
   			for(var i=0;i<response.length;i++){
   				var j=i+1;
   				htmlstr+="<tr><td style='color: #0044cc;'><b>Q"+j+":</b></td><td style='color: #0044cc;'><b>"+response[i].feedBkQuestion+"<input type=hidden name=feedBkQuesId value="+response[i].feedBkQuesId+"></b></td></tr>";
   				
   				for(var k=0;k<response[i].listFeedbkOption.length;k++){
   					htmlstr+="<tr><td><input type=radio name="+response[i].feedBkQuesId+" value="+response[i].listFeedbkOption[k].feedBkOptionId+"></td><td style='color: #0088cc;'><b>"+response[i].listFeedbkOption[k].feedBkOption+"</b></td></tr>";
   				}
   				//htmlstr+="<br>"
   				$("#feedbacktbl").html(htmlstr);
   			}
   		},
   		error : function() {
   			$.alert.open('Error while loading Master Data');
   		}
   	});
	
}

function saveFeedBackForm(){
	var questId=[];
	var optionId=[];
	$("input[type=radio]").each(function(){
		if(this.checked==true){
			questId.push(this.name);
			optionId.push(this.value);
		}
		
		})
	$.ajax({
   		type : "get",
   		url : "tdmsaveFeedBackForm?quesId="+questId+"&ansId="+optionId,
   		cache : false,
   		success : function(response) {
   			window.location.href="tdmviewfeedBackSuccess";
   		},
   		error : function() {
   			$.alert.open('Error while loading FeeedBack');
   		}
   	});
	
}