


var myVar = setInterval(myTimer, 1000);

var hourLeft=0;
var minitLeft=0;
var secLeft=0;
var flag=0;


function checkValidation(){

	var username = $("#username").val();
	var password = $("#password").val();
	if( username== "" || password == ""){
		alert("Please enter User Id or Password" );
		return false;
	}else{
		if(username == "demo" && password == "demo"){
			//return true;
			/*var height = $( window ).height();
			var width =  $( window ).width();*/

			var height = screen.height;
			var width = screen.width;

			window.open('loginSuccessful.html', 'PoP_Up', 'directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,fullscreen=yes,scrollbars=auto,width=' + width + ',height=' + height);
		}else{
			alert("Please enter correct User Id or Password" );
			return false;
		}
	}
}


function myTimer()
{
	if(hourLeft==0 && minitLeft==0 && secLeft==0)
		{
		flag=1;
		}
	
// 	$("#timerDurationLeft").text((hourLeft<10 ?"0"+hourLeft:hourLeft)+":"+(minitLeft<10?"0"+minitLeft:minitLeft)+":"+(secLeft<10?"0"+secLeft:secLeft));
	///left time duration
	if(minitLeft>=0)
		{
		if(secLeft>=0)
			{
			secLeft--;
			if(secLeft<0)secLeft=0;
			}
		}
	if(secLeft<=0)
	{
		if(minitLeft>0)
			{
				minitLeft--;
			}
		if(minitLeft>=0)
		{
			if(flag==0)
			secLeft=59;
			
		}
	}
	if(minitLeft<=0)
	{
		if(hourLeft>0)
			{
				hourLeft--;
				minitLeft=59;
			}
	}
	if(flag==1)secLeft=1;
	
	if(hourLeft==0 && minitLeft==0 && secLeft==1){
		//window.location.href="eontdmloginFailed";
		$("#submitId").show();
		flag=1;
		secLeft=0;
	}
	//$("#submitId").show();
}

function deleteCokie()
{   
    var cookies = document.cookie.split(";");
    //alert(cookies.length);
    for (var i = 0; i < cookies.length; i++)
    {   
        var spcook =  cookies[i].split("=");
        deleteCookie(spcook[0]);
    }
    function deleteCookie(cookiename)
    {
        var d = new Date();
        d.setDate(d.getDate() - 1);
        var expires = ";expires="+d;
        var name=cookiename;
        //alert(name);
        var value="";
        document.cookie = name + "=" + value + expires + "; path=/acc/html";                    
    }
    
}
function chekk()
{
		//alert("ji");
}



$(document).ready(function() {
	//$(document)[0].oncontextmenu = function() {return false;} //for right click disable
 jqKeyboard.init({
	  containment: "#container",
	  icon: "dark",
	}); 
 jQuery(function(){
	   jQuery('#jqk-toggle-btn').click();
	});
// 	jqKeyboard.init();
// window.history.forward();
  history.pushState(null, null, '');
  window.addEventListener('popstate', function () {
     history.pushState(null, null, '');
 }); 

});


function loadTimerDate(){
	$("#timerDurationLeft").text("00:00");
		 /*display = document.querySelector('#timerDurationLeft');
		 startTimer(120*60, display);
		$.ajax({
	   		type : "get",
	   		url : "loadLoginTimer",
	   		cache : false,
	   		success : function(response) {	
	   			$("#timerDurationLeft").text(response);
	   			if(response != "00:00"){
	   				var times = response.split(":");
// 	   				alert(times[0]+"_"+times[1]+" ="+times[0]*60+"   "+response);
		   			var sec = parseInt(times[0]*60)+parseInt(times[1]);
// 		   			alert(sec);
		   			startTimer(sec, display);
	   			}
	   			
	   			
	   		},
	   			error : function() {
	   			$.alert.open('Error while loading Section Tabs');
	   		}
	   	});*/
	}
	
	function submitFormAfterTime(){
		var timer = $("#timerDurationLeft").html();
		if(timer == "00:00"){
			return true;
		}else{
			$.alert.open('You have '+timer+' minutes left to login.');
			return false;
		}
	}