function loadCandidateInfo(){
	
	$.ajax({
		type : "get",
		url : "eontdmloadCandidateInfo",
		cache : false,
		success : function(response) {
			$("#nameOfExaminee").text(response[0].name);
			$("#category").text(response[0].category);
			$("#gender").text(response[0].gender);
			$("#mobileNo").text(response[0].mobileNo);
			$("#regNo").text(response[0].regNo);
			$("#rollNumber").text(response[0].applicationNo);
			$("#emailId").text(response[0].email);
			
			var myDate = new Date(new Date(response[0].dOB));
			var localTime = myDate.toLocaleString().split(",");
			var date = localTime[0].split("/");
//			alert(date+"__"+date[1]+"/"+date[0]+"/"+date[2]);
			$("#dob").text(date[1]+"/"+date[0]+"/"+date[2]);
//			$("#dob").text(new Date(response[0].dOB).toUTCString());
			if(response[0].img!=null){
				document.getElementById("img").src = "data:image/png;base64," + response[0].img;
			}
			
	},
	error : function() {
		$.alert.open('Error while load CandidateInfo');
		}
	});
}