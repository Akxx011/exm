var currentSrnoQid = "1_7148";

$(document).ready(function () {
    var data = currentSrnoQid.split('_');
    loadQuestfromPreview(data[0], data[1]);
    loadButtons();
    $('[data-toggle="tooltip"]').tooltip();
});

function loadTooltipJS() {
    $('[data-toggle="tooltip"]').tooltip();
}

var lastSavedAnswer = 0;
var myVar = setInterval(myTimer, 5000);
var second = 0;
var replaceData;

var totalTimeOfExam = 120 * 60;
var timeAfterStartExam = 60 * 60;
var timeBeforeEndExam = 30 * 60;
var totalAllowedBiocall = 2;
var autoSubmit;
var masterAnswerRecord = new Object();
var totalQuest = 10;
var ansrd = 0;
var unAnsrd = 0;
var ansrdAndMark = 0;
var unAnsrdAndMark = 0;
var ntVewd = 0;

var negetiveMarks = 0;
var correctMarks = 0;
//var resultKey={ "1":"3151", "2":"31", "3":"3159" };
var resultKey = { "1": "28591", "2": "28597", "3": "28598", "4": "28600", "5": "28597", "6": "28598", "7": "28601", "8": "28598", "9": "28598", "10": "28601", "11": "3191", "12": "3195", "13": "3201", "14": "3206", "15": "3209", "16": "3214", "17": "3216", "18": "3220", "19": "3226", "20": "3230" };

var masterQuestionLoad = [
		{
		    "qID": 7148,
		    "qBID": 0,
		    "templateId": 47,
		    "qpSectionObj": {
		        "@id": 1,
		        "sectionId": 54,
		        "templateId": 47,
		        "sectionName": "SECTION ONE",
		        "maximumDuration": 100,
		        "minimumDuration": 100,
		        "sectionText": "SECTION ONE",
		        "subjectId": 2603,
		        "sectionTotalMarks": 25,
		        "noOfSubsection": 1,
		        "noOfQuestions": 25,
		        "noOfQuestionsNeedToAttempt": 25,
		        "questionTypeID": 1102,
		        "optionCount": 0,
		        "language": "1",
		        "marksForCorrect": 1,
		        "marksForWrong": 1,
		        "marksForBlank": 1,
		        "isMandatory": 1,
		        "isRevisitAllowedEdit": 0,
		        "isRevisitAllowedView": 0,
		        "isQuestionShuffle": 0,
		        "isOptionShuffle": 0,
		        "isActive": 1,
		        "isDeleted": 0,
		        "startQSrlNo": 1,
		        "lastQSrlNo": 25,
		        "qtypename": null
		    },
		    "qpSubSectionObj": {
		        "subSectionId": 55,
		        "subSectionCode": 1,
		        "subSectionHeading": "SUB",
		        "isSectionQuestionShuffle": 0,
		        "isSectionOptionShuffle": 0,
		        "isActive": 1,
		        "isDeleted": 0
		    },
		    "qpGroupObj": {
		        "groupId": 54,
		        "templateId": 47,
		        "sectionId": 54,
		        "groupText": "GROUP",
		        "groupType": 1102,
		        "isQuestionShuffle": 0,
		        "isOptionShuffle": 0,
		        "startQSrlNo": 1,
		        "lastQSrlNo": 25,
		        "noOfQuestions": 25,
		        "isActive": 1,
		        "isDeleted": 0,
		        "optionCount": 5
		    },
		    "questionId": 7148,
		    "questionText": "In a hostel of 50 girls, there are food provisions for 40 days. If 30 more girls join the hosteI, the food provisionS Will last for :",
		    "noOfOption": 5,
		    "qtype": 0,
		    "qsrl": 0,
		    "marksCorrect": 0,
		    "marksWrong": 0,
		    "marksBlank": 0,
		    "difficutyLevel": 1,
		    "isDeleted": 0,
		    "createdOn": 1512479280000,
		    "createdBy": 0,
		    "modifiedOn": 1512479280000,
		    "modifiedBy": 0,
		    "isActive": 1,
		    "batchId": 0,
		    "batchName": null,
		    "examId": 2,
		    "slotId": 10,
		    "secondaryQuestionText": "",
		    "qPQuestionImages": [],
		    "qPQuestionOptions": [{
		        "oID": 28589,
		        "templateId": 47,
		        "optionId": 28589,
		        "optionSrl": 0,
		        "optionText": "35 days",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28590,
		        "templateId": 47,
		        "optionId": 28590,
		        "optionSrl": 0,
		        "optionText": "30 days",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28591,
		        "templateId": 47,
		        "optionId": 28591,
		        "optionSrl": 0,
		        "optionText": "25 days",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28592,
		        "templateId": 47,
		        "optionId": 28592,
		        "optionSrl": 0,
		        "optionText": "20 days",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28592,
		        "templateId": 47,
		        "optionId": 28592,
		        "optionSrl": 0,
		        "optionText": "15 days",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }],
		    "date": 1512479436314,
		    "actionId": 0,
		    "positionNo": 1,
		    "studentAnsId": 0,
		    "sectionName": "SECTION ONE",
		    "status": 0,
		    "studName": "",
		    "studRollNo": 0,
		    "gender": "",
		    "qtypename": null
		},
		{
		    "qID": 7149,
		    "qBID": 0,
		    "templateId": 47,
		    "qpSectionObj": 1,
		    "qpSubSectionObj": {
		        "subSectionId": 55,
		        "subSectionCode": 1,
		        "subSectionHeading": "SUB",
		        "isSectionQuestionShuffle": 0,
		        "isSectionOptionShuffle": 0,
		        "isActive": 1,
		        "isDeleted": 0
		    },
		    "qpGroupObj": {
		        "groupId": 54,
		        "templateId": 47,
		        "sectionId": 54,
		        "groupText": "GROUP",
		        "groupType": 1102,
		        "isQuestionShuffle": 0,
		        "isOptionShuffle": 0,
		        "startQSrlNo": 1,
		        "lastQSrlNo": 25,
		        "noOfQuestions": 25,
		        "isActive": 1,
		        "isDeleted": 0,
		        "optionCount": 5
		    },
		    "questionId": 7149,
		    "questionText": "A man bought an article and sold it at a gain of 10%. If he had bought it al 20% less and sold it for Rs. 10 more, he would have made a profit of 40%. The cost price of the article is:",
		    "noOfOption": 5,
		    "qtype": 0,
		    "qsrl": 0,
		    "marksCorrect": 0,
		    "marksWrong": 0,
		    "marksBlank": 0,
		    "difficutyLevel": 1,
		    "isDeleted": 0,
		    "createdOn": 1512479280000,
		    "createdBy": 0,
		    "modifiedOn": 1512479280000,
		    "modifiedBy": 0,
		    "isActive": 1,
		    "batchId": 0,
		    "batchName": null,
		    "examId": 2,
		    "slotId": 10,
		    "secondaryQuestionText": "",
		    "qPQuestionImages": [],
		    "qPQuestionOptions": [{
		        "oID": 28597,
		        "templateId": 47,
		        "optionId": 28597,
		        "optionSrl": 0,
		        "optionText": "Rs. 500",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28598,
		        "templateId": 47,
		        "optionId": 28598,
		        "optionSrl": 0,
		        "optionText": "Rs. 480",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28599,
		        "templateId": 47,
		        "optionId": 28599,
		        "optionSrl": 0,
		        "optionText": "Rs. 450",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28600,
		        "templateId": 47,
		        "optionId": 28600,
		        "optionSrl": 0,
		        "optionText": "Rs. 400",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28601,
		        "templateId": 47,
		        "optionId": 28601,
		        "optionSrl": 0,
		        "optionText": "Rs. 350",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }],
		    "date": 1512479436314,
		    "actionId": 0,
		    "positionNo": 1,
		    "studentAnsId": 0,
		    "sectionName": "SECTION ONE",
		    "status": 0,
		    "studName": "",
		    "studRollNo": 0,
		    "gender": "",
		    "qtypename": null
		},
		{
		    "qID": 7150,
		    "qBID": 0,
		    "templateId": 47,
		    "qpSectionObj": 1,
		    "qpSubSectionObj": {
		        "subSectionId": 55,
		        "subSectionCode": 1,
		        "subSectionHeading": "SUB",
		        "isSectionQuestionShuffle": 0,
		        "isSectionOptionShuffle": 0,
		        "isActive": 1,
		        "isDeleted": 0
		    },
		    "qpGroupObj": {
		        "groupId": 54,
		        "templateId": 47,
		        "sectionId": 54,
		        "groupText": "GROUP",
		        "groupType": 1102,
		        "isQuestionShuffle": 0,
		        "isOptionShuffle": 0,
		        "startQSrlNo": 1,
		        "lastQSrlNo": 25,
		        "noOfQuestions": 25,
		        "isActive": 1,
		        "isDeleted": 0,
		        "optionCount": 5
		    },
		    "questionId": 7150,
		    "questionText": "At what rate percent per annum compound intetest, will Rs. 10,000 amount to Rs. 13,310 in three years ?",
		    "noOfOption": 5,
		    "qtype": 0,
		    "qsrl": 0,
		    "marksCorrect": 0,
		    "marksWrong": 0,
		    "marksBlank": 0,
		    "difficutyLevel": 1,
		    "isDeleted": 0,
		    "createdOn": 1512479280000,
		    "createdBy": 0,
		    "modifiedOn": 1512479280000,
		    "modifiedBy": 0,
		    "isActive": 1,
		    "batchId": 0,
		    "batchName": null,
		    "examId": 2,
		    "slotId": 10,
		    "secondaryQuestionText": "",
		    "qPQuestionImages": [],
		    "qPQuestionOptions": [{
		        "oID": 28597,
		        "templateId": 47,
		        "optionId": 28597,
		        "optionSrl": 0,
		        "optionText": "8%",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28598,
		        "templateId": 47,
		        "optionId": 28598,
		        "optionSrl": 0,
		        "optionText": "10%",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28599,
		        "templateId": 47,
		        "optionId": 28599,
		        "optionSrl": 0,
		        "optionText": "12%",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28600,
		        "templateId": 47,
		        "optionId": 28600,
		        "optionSrl": 0,
		        "optionText": "15%",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28601,
		        "templateId": 47,
		        "optionId": 28601,
		        "optionSrl": 0,
		        "optionText": "18%",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }],
		    "date": 1512479436314,
		    "actionId": 0,
		    "positionNo": 1,
		    "studentAnsId": 0,
		    "sectionName": "SECTION ONE",
		    "status": 0,
		    "studName": "",
		    "studRollNo": 0,
		    "gender": "",
		    "qtypename": null
		},
		{
		    "qID": 7151,
		    "qBID": 0,
		    "templateId": 47,
		    "qpSectionObj": 1,
		    "qpSubSectionObj": {
		        "subSectionId": 55,
		        "subSectionCode": 1,
		        "subSectionHeading": "SUB",
		        "isSectionQuestionShuffle": 0,
		        "isSectionOptionShuffle": 0,
		        "isActive": 1,
		        "isDeleted": 0
		    },
		    "qpGroupObj": {
		        "groupId": 54,
		        "templateId": 47,
		        "sectionId": 54,
		        "groupText": "GROUP",
		        "groupType": 1102,
		        "isQuestionShuffle": 0,
		        "isOptionShuffle": 0,
		        "startQSrlNo": 1,
		        "lastQSrlNo": 25,
		        "noOfQuestions": 25,
		        "isActive": 1,
		        "isDeleted": 0,
		        "optionCount": 5
		    },
		    "questionId": 7151,
		    "questionText": "The Fort at Pulicat was built by :",
		    "noOfOption": 5,
		    "qtype": 0,
		    "qsrl": 0,
		    "marksCorrect": 0,
		    "marksWrong": 0,
		    "marksBlank": 0,
		    "difficutyLevel": 1,
		    "isDeleted": 0,
		    "createdOn": 1512479280000,
		    "createdBy": 0,
		    "modifiedOn": 1512479280000,
		    "modifiedBy": 0,
		    "isActive": 1,
		    "batchId": 0,
		    "batchName": null,
		    "examId": 2,
		    "slotId": 10,
		    "secondaryQuestionText": "",
		    "qPQuestionImages": [],
		    "qPQuestionOptions": [{
		        "oID": 28597,
		        "templateId": 47,
		        "optionId": 28597,
		        "optionSrl": 0,
		        "optionText": "Portuguese",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28598,
		        "templateId": 47,
		        "optionId": 28598,
		        "optionSrl": 0,
		        "optionText": "British",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28599,
		        "templateId": 47,
		        "optionId": 28599,
		        "optionSrl": 0,
		        "optionText": "French",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28600,
		        "templateId": 47,
		        "optionId": 28600,
		        "optionSrl": 0,
		        "optionText": "Dutch",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28601,
		        "templateId": 47,
		        "optionId": 28601,
		        "optionSrl": 0,
		        "optionText": "None of these",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }],
		    "date": 1512479436314,
		    "actionId": 0,
		    "positionNo": 1,
		    "studentAnsId": 0,
		    "sectionName": "SECTION ONE",
		    "status": 0,
		    "studName": "",
		    "studRollNo": 0,
		    "gender": "",
		    "qtypename": null
		},
		{
		    "qID": 7152,
		    "qBID": 0,
		    "templateId": 47,
		    "qpSectionObj": 1,
		    "qpSubSectionObj": {
		        "subSectionId": 55,
		        "subSectionCode": 1,
		        "subSectionHeading": "SUB",
		        "isSectionQuestionShuffle": 0,
		        "isSectionOptionShuffle": 0,
		        "isActive": 1,
		        "isDeleted": 0
		    },
		    "qpGroupObj": {
		        "groupId": 54,
		        "templateId": 47,
		        "sectionId": 54,
		        "groupText": "GROUP",
		        "groupType": 1102,
		        "isQuestionShuffle": 0,
		        "isOptionShuffle": 0,
		        "startQSrlNo": 1,
		        "lastQSrlNo": 25,
		        "noOfQuestions": 25,
		        "isActive": 1,
		        "isDeleted": 0,
		        "optionCount": 5
		    },
		    "questionId": 7152,
		    "questionText": "Chand Bibi was the ruler of :",
		    "noOfOption": 5,
		    "qtype": 0,
		    "qsrl": 0,
		    "marksCorrect": 0,
		    "marksWrong": 0,
		    "marksBlank": 0,
		    "difficutyLevel": 1,
		    "isDeleted": 0,
		    "createdOn": 1512479280000,
		    "createdBy": 0,
		    "modifiedOn": 1512479280000,
		    "modifiedBy": 0,
		    "isActive": 1,
		    "batchId": 0,
		    "batchName": null,
		    "examId": 2,
		    "slotId": 10,
		    "secondaryQuestionText": "",
		    "qPQuestionImages": [],
		    "qPQuestionOptions": [{
		        "oID": 28597,
		        "templateId": 47,
		        "optionId": 28597,
		        "optionSrl": 0,
		        "optionText": "Ahmednagar",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28598,
		        "templateId": 47,
		        "optionId": 28598,
		        "optionSrl": 0,
		        "optionText": "Bijapur",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28599,
		        "templateId": 47,
		        "optionId": 28599,
		        "optionSrl": 0,
		        "optionText": "Gondwana",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28600,
		        "templateId": 47,
		        "optionId": 28600,
		        "optionSrl": 0,
		        "optionText": "Warangal",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28601,
		        "templateId": 47,
		        "optionId": 28601,
		        "optionSrl": 0,
		        "optionText": "Asirgarh",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }],
		    "date": 1512479436314,
		    "actionId": 0,
		    "positionNo": 1,
		    "studentAnsId": 0,
		    "sectionName": "SECTION ONE",
		    "status": 0,
		    "studName": "",
		    "studRollNo": 0,
		    "gender": "",
		    "qtypename": null
		},
		{
		    "qID": 7153,
		    "qBID": 0,
		    "templateId": 47,
		    "qpSectionObj": 1,
		    "qpSubSectionObj": {
		        "subSectionId": 55,
		        "subSectionCode": 1,
		        "subSectionHeading": "SUB",
		        "isSectionQuestionShuffle": 0,
		        "isSectionOptionShuffle": 0,
		        "isActive": 1,
		        "isDeleted": 0
		    },
		    "qpGroupObj": {
		        "groupId": 54,
		        "templateId": 47,
		        "sectionId": 54,
		        "groupText": "GROUP",
		        "groupType": 1102,
		        "isQuestionShuffle": 0,
		        "isOptionShuffle": 0,
		        "startQSrlNo": 1,
		        "lastQSrlNo": 25,
		        "noOfQuestions": 25,
		        "isActive": 1,
		        "isDeleted": 0,
		        "optionCount": 5
		    },
		    "questionId": 7153,
		    "questionText": "The phenomenon of summer sleep by animals is called :",
		    "noOfOption": 5,
		    "qtype": 0,
		    "qsrl": 0,
		    "marksCorrect": 0,
		    "marksWrong": 0,
		    "marksBlank": 0,
		    "difficutyLevel": 1,
		    "isDeleted": 0,
		    "createdOn": 1512479280000,
		    "createdBy": 0,
		    "modifiedOn": 1512479280000,
		    "modifiedBy": 0,
		    "isActive": 1,
		    "batchId": 0,
		    "batchName": null,
		    "examId": 2,
		    "slotId": 10,
		    "secondaryQuestionText": "",
		    "qPQuestionImages": [],
		    "qPQuestionOptions": [{
		        "oID": 28597,
		        "templateId": 47,
		        "optionId": 28597,
		        "optionSrl": 0,
		        "optionText": "Hibernation",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28598,
		        "templateId": 47,
		        "optionId": 28598,
		        "optionSrl": 0,
		        "optionText": "Aestivation",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28599,
		        "templateId": 47,
		        "optionId": 28599,
		        "optionSrl": 0,
		        "optionText": "Salvation",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28600,
		        "templateId": 47,
		        "optionId": 28600,
		        "optionSrl": 0,
		        "optionText": "lethargy",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28601,
		        "templateId": 47,
		        "optionId": 28601,
		        "optionSrl": 0,
		        "optionText": "None of the above",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }],
		    "date": 1512479436314,
		    "actionId": 0,
		    "positionNo": 1,
		    "studentAnsId": 0,
		    "sectionName": "SECTION ONE",
		    "status": 0,
		    "studName": "",
		    "studRollNo": 0,
		    "gender": "",
		    "qtypename": null
		},
		{
		    "qID": 7154,
		    "qBID": 0,
		    "templateId": 47,
		    "qpSectionObj": 1,
		    "qpSubSectionObj": {
		        "subSectionId": 55,
		        "subSectionCode": 1,
		        "subSectionHeading": "SUB",
		        "isSectionQuestionShuffle": 0,
		        "isSectionOptionShuffle": 0,
		        "isActive": 1,
		        "isDeleted": 0
		    },
		    "qpGroupObj": {
		        "groupId": 54,
		        "templateId": 47,
		        "sectionId": 54,
		        "groupText": "GROUP",
		        "groupType": 1102,
		        "isQuestionShuffle": 0,
		        "isOptionShuffle": 0,
		        "startQSrlNo": 1,
		        "lastQSrlNo": 25,
		        "noOfQuestions": 25,
		        "isActive": 1,
		        "isDeleted": 0,
		        "optionCount": 5
		    },
		    "questionId": 7154,
		    "questionText": "If 15 boys earn Rs. 900 in 5 days, how much will 20 boys earn in 7 days ?",
		    "noOfOption": 5,
		    "qtype": 0,
		    "qsrl": 0,
		    "marksCorrect": 0,
		    "marksWrong": 0,
		    "marksBlank": 0,
		    "difficutyLevel": 1,
		    "isDeleted": 0,
		    "createdOn": 1512479280000,
		    "createdBy": 0,
		    "modifiedOn": 1512479280000,
		    "modifiedBy": 0,
		    "isActive": 1,
		    "batchId": 0,
		    "batchName": null,
		    "examId": 2,
		    "slotId": 10,
		    "secondaryQuestionText": "",
		    "qPQuestionImages": [],
		    "qPQuestionOptions": [{
		        "oID": 28597,
		        "templateId": 47,
		        "optionId": 28597,
		        "optionSrl": 0,
		        "optionText": "Rs. 1980",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28598,
		        "templateId": 47,
		        "optionId": 28598,
		        "optionSrl": 0,
		        "optionText": "Rs. 1820",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28599,
		        "templateId": 47,
		        "optionId": 28599,
		        "optionSrl": 0,
		        "optionText": "Rs. 1780",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28600,
		        "templateId": 47,
		        "optionId": 28600,
		        "optionSrl": 0,
		        "optionText": "Rs. 1740",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28601,
		        "templateId": 47,
		        "optionId": 28601,
		        "optionSrl": 0,
		        "optionText": "Rs. 1680",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }],
		    "date": 1512479436314,
		    "actionId": 0,
		    "positionNo": 1,
		    "studentAnsId": 0,
		    "sectionName": "SECTION ONE",
		    "status": 0,
		    "studName": "",
		    "studRollNo": 0,
		    "gender": "",
		    "qtypename": null
		},
		{
		    "qID": 7155,
		    "qBID": 0,
		    "templateId": 47,
		    "qpSectionObj": 1,
		    "qpSubSectionObj": {
		        "subSectionId": 55,
		        "subSectionCode": 1,
		        "subSectionHeading": "SUB",
		        "isSectionQuestionShuffle": 0,
		        "isSectionOptionShuffle": 0,
		        "isActive": 1,
		        "isDeleted": 0
		    },
		    "qpGroupObj": {
		        "groupId": 54,
		        "templateId": 47,
		        "sectionId": 54,
		        "groupText": "GROUP",
		        "groupType": 1102,
		        "isQuestionShuffle": 0,
		        "isOptionShuffle": 0,
		        "startQSrlNo": 1,
		        "lastQSrlNo": 25,
		        "noOfQuestions": 25,
		        "isActive": 1,
		        "isDeleted": 0,
		        "optionCount": 5
		    },
		    "questionId": 7155,
		    "questionText": "The first dynasty of the Vijayanagar Kingdom was :",
		    "noOfOption": 5,
		    "qtype": 0,
		    "qsrl": 0,
		    "marksCorrect": 0,
		    "marksWrong": 0,
		    "marksBlank": 0,
		    "difficutyLevel": 1,
		    "isDeleted": 0,
		    "createdOn": 1512479280000,
		    "createdBy": 0,
		    "modifiedOn": 1512479280000,
		    "modifiedBy": 0,
		    "isActive": 1,
		    "batchId": 0,
		    "batchName": null,
		    "examId": 2,
		    "slotId": 10,
		    "secondaryQuestionText": "",
		    "qPQuestionImages": [],
		    "qPQuestionOptions": [{
		        "oID": 28597,
		        "templateId": 47,
		        "optionId": 28597,
		        "optionSrl": 0,
		        "optionText": "Hoysala",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28598,
		        "templateId": 47,
		        "optionId": 28598,
		        "optionSrl": 0,
		        "optionText": "Sangama",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28599,
		        "templateId": 47,
		        "optionId": 28599,
		        "optionSrl": 0,
		        "optionText": "Saluva",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28600,
		        "templateId": 47,
		        "optionId": 28600,
		        "optionSrl": 0,
		        "optionText": "Aravidu",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28601,
		        "templateId": 47,
		        "optionId": 28601,
		        "optionSrl": 0,
		        "optionText": "Tuluva",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }],
		    "date": 1512479436314,
		    "actionId": 0,
		    "positionNo": 1,
		    "studentAnsId": 0,
		    "sectionName": "SECTION ONE",
		    "status": 0,
		    "studName": "",
		    "studRollNo": 0,
		    "gender": "",
		    "qtypename": null
		},
		{
		    "qID": 7156,
		    "qBID": 0,
		    "templateId": 47,
		    "qpSectionObj": 1,
		    "qpSubSectionObj": {
		        "subSectionId": 55,
		        "subSectionCode": 1,
		        "subSectionHeading": "SUB",
		        "isSectionQuestionShuffle": 0,
		        "isSectionOptionShuffle": 0,
		        "isActive": 1,
		        "isDeleted": 0
		    },
		    "qpGroupObj": {
		        "groupId": 54,
		        "templateId": 47,
		        "sectionId": 54,
		        "groupText": "GROUP",
		        "groupType": 1102,
		        "isQuestionShuffle": 0,
		        "isOptionShuffle": 0,
		        "startQSrlNo": 1,
		        "lastQSrlNo": 25,
		        "noOfQuestions": 25,
		        "isActive": 1,
		        "isDeleted": 0,
		        "optionCount": 5
		    },
		    "questionId": 7156,
		    "questionText": "The Characteristic feature of Virus is :",
		    "noOfOption": 5,
		    "qtype": 0,
		    "qsrl": 0,
		    "marksCorrect": 0,
		    "marksWrong": 0,
		    "marksBlank": 0,
		    "difficutyLevel": 1,
		    "isDeleted": 0,
		    "createdOn": 1512479280000,
		    "createdBy": 0,
		    "modifiedOn": 1512479280000,
		    "modifiedBy": 0,
		    "isActive": 1,
		    "batchId": 0,
		    "batchName": null,
		    "examId": 2,
		    "slotId": 10,
		    "secondaryQuestionText": "",
		    "qPQuestionImages": [],
		    "qPQuestionOptions": [{
		        "oID": 28597,
		        "templateId": 47,
		        "optionId": 28597,
		        "optionSrl": 0,
		        "optionText": "It multiplies only on dead animals",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28598,
		        "templateId": 47,
		        "optionId": 28598,
		        "optionSrl": 0,
		        "optionText": "It multiplies only on hosts",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28599,
		        "templateId": 47,
		        "optionId": 28599,
		        "optionSrl": 0,
		        "optionText": "It lacks chlorophyl",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28600,
		        "templateId": 47,
		        "optionId": 28600,
		        "optionSrl": 0,
		        "optionText": "It is made up of fats",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28601,
		        "templateId": 47,
		        "optionId": 28601,
		        "optionSrl": 0,
		        "optionText": "None of These",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }],
		    "date": 1512479436314,
		    "actionId": 0,
		    "positionNo": 1,
		    "studentAnsId": 0,
		    "sectionName": "SECTION ONE",
		    "status": 0,
		    "studName": "",
		    "studRollNo": 0,
		    "gender": "",
		    "qtypename": null
		},
		{
		    "qID": 7157,
		    "qBID": 0,
		    "templateId": 47,
		    "qpSectionObj": 1,
		    "qpSubSectionObj": {
		        "subSectionId": 55,
		        "subSectionCode": 1,
		        "subSectionHeading": "SUB",
		        "isSectionQuestionShuffle": 0,
		        "isSectionOptionShuffle": 0,
		        "isActive": 1,
		        "isDeleted": 0
		    },
		    "qpGroupObj": {
		        "groupId": 54,
		        "templateId": 47,
		        "sectionId": 54,
		        "groupText": "GROUP",
		        "groupType": 1102,
		        "isQuestionShuffle": 0,
		        "isOptionShuffle": 0,
		        "startQSrlNo": 1,
		        "lastQSrlNo": 25,
		        "noOfQuestions": 25,
		        "isActive": 1,
		        "isDeleted": 0,
		        "optionCount": 5
		    },
		    "questionId": 7157,
		    "questionText": "In a Parliamentary form of government, real powers are vested in :",
		    "noOfOption": 5,
		    "qtype": 0,
		    "qsrl": 0,
		    "marksCorrect": 0,
		    "marksWrong": 0,
		    "marksBlank": 0,
		    "difficutyLevel": 1,
		    "isDeleted": 0,
		    "createdOn": 1512479280000,
		    "createdBy": 0,
		    "modifiedOn": 1512479280000,
		    "modifiedBy": 0,
		    "isActive": 1,
		    "batchId": 0,
		    "batchName": null,
		    "examId": 2,
		    "slotId": 10,
		    "secondaryQuestionText": "",
		    "qPQuestionImages": [],
		    "qPQuestionOptions": [{
		        "oID": 28597,
		        "templateId": 47,
		        "optionId": 28597,
		        "optionSrl": 0,
		        "optionText": "President",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28598,
		        "templateId": 47,
		        "optionId": 28598,
		        "optionSrl": 0,
		        "optionText": "Parliament",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28599,
		        "templateId": 47,
		        "optionId": 28599,
		        "optionSrl": 0,
		        "optionText": "Judiciary",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28600,
		        "templateId": 47,
		        "optionId": 28600,
		        "optionSrl": 0,
		        "optionText": "Government",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }, {
		        "oID": 28601,
		        "templateId": 47,
		        "optionId": 28601,
		        "optionSrl": 0,
		        "optionText": "Council of Ministers headed by the Prime Minister",
		        "isItCorrectOption": null,
		        "isActive": 1,
		        "isDeleted": 0,
		        "createdOn": 1512479280000,
		        "createdBy": 0,
		        "batchId": 0,
		        "batchName": null,
		        "qPQuestionOptionsImages": [],
		        "secondaryOptionText": "",
		        "modifiedOn": 1512479280000,
		        "modifiedBy": 0,
		        "optionIdUpdate": null,
		        "positionNo": 0,
		        "studentAns": 0
		    }]

		}];

function myTimer() {
    //	alert(totalTimeOfExam);
    second = second + 5;

    //if ($('#timerDurationLeft').text() == "05:00") {
    //    $("#popUptimeleft").text("05:00");
    //    $("#timeLeftPopup").modal('show');
    //}
    if ($('#timerDurationLeft').text() == "00:00") {
        submitExam();
    }
    if (second == 80) {
        second = 0;
    }

    var timeRemin = $('#timerDurationLeft').text();
    var timeSeconds = timeRemin.split(":");
    var tdmReminingTime = (60 * parseInt(timeSeconds[0])) + parseInt(timeSeconds[1]);

    if (tdmReminingTime <= (totalTimeOfExam - timeAfterStartExam) && tdmReminingTime > timeBeforeEndExam) {
        $("#shortRelief").css("pointer-events", "auto");
    } else if (tdmReminingTime <= timeBeforeEndExam) {
        $("#shortRelief").css("pointer-events", "none");
    }
    //	alert((60*parseInt(timeSeconds[0])) +parseInt(timeSeconds[1]) );

}

function loadMasterQuestion() {
    // loadSectionTab(masterQuestionLoad);
    var timeRemaining = parseFloat($('#timerDurationLeft').text());
    display = document.querySelector('#timerDurationLeft');
    startTimer((timeRemaining * 60), display);
}

function loadButtons() {
    //var cName = $("#hdnCourse").val();
    var strhtml = "", allQuest = "";
    var aar = new Array(); aar.push("A)"); aar.push("B)"); aar.push("C)"); aar.push("D)"); aar.push("E)");

    allQuest += '<tr><td style="display:block; margin:0; padding:0; height:0px;">&nbsp; </td></tr>';
    //allQuest += '<tr><td colspan="6" class="headingTextCenter">FUNDAMENTALS OF COMPUTER - 1 ' + cName + '</td></tr>';
    //allQuest += '<tr><td style="display:block; margin:0; padding:0; height:0px;">&nbsp; </td></tr>';
    allQuest += '<tr><td style="display:block; margin:0; padding:0; height:0px;">&nbsp; </td></tr>';
    allQuest += '<tr class="ab"><td colspan="7" class="group_heading_text">सभी प्रश्न अनिवार्य हैं / ALL QUESTIONS ARE MANDATORY</td></tr>';
    allQuest += '<tr><td style="display:block; margin:0; padding:0; height:0px;">&nbsp; </td></tr>';

    for (var i = 0; i < masterQuestionLoad.length; i++) {
        strhtml += ' <button type="button" class="btn btn-circle btn-default" onclick="loadQuestfromPreview(this.id,this.value);" id="' + (i + 1) + '" value="' + masterQuestionLoad[i].qID + '">' + (i + 1) + '</button>';
        allQuest += '<tr id="question' + masterQuestionLoad[i].qID + '" style="font-weight: bold;"><td style="vertical-align:top; width:60px; padding: 0 0 6px 0;">Q ' + (i + 1) + ':</td><td colspan="6">' + masterQuestionLoad[i].questionText + '<span class="optionBreak"></span>' + masterQuestionLoad[i].secondaryQuestionText + '</td></tr>';

        for (var j = 0; j < masterQuestionLoad[i].qPQuestionOptions.length; j++) {
            if (j == 0) { allQuest += '<tr><td colspan="6">&nbsp;</td></tr> <tr id="question' + masterQuestionLoad[i].qID + '"><td></td>'; }
            allQuest += '<td class="aligntoppaper" style="width:20px; margin:5px;"><b>' + aar[j] + '</b>&nbsp;</td><td style="vertical-align: top; width:33.333%; padding: 0 0 6px 0;">' + masterQuestionLoad[i].qPQuestionOptions[j].optionText + '<span class="optionBreak"></span>' + masterQuestionLoad[i].qPQuestionOptions[j].secondaryOptionText + '</td>';
            if (j == 1) { allQuest += '</tr><tr><td></td>'; }
        }
        allQuest += '</tr><tr><td colspan="7"><hr class="qp_seprator"></td></tr>';
    }

    $("#tbodyQuestion").html('').html(allQuest);
    $("#questPrevDiv").html('').html(strhtml);
}

function loadSectionTab(qpMasterQuestionList) {
    var htmlStr = "";
    var htmlTabContentDiv = "";
    htmlTabContentDiv += "<div id='questionDiv' class='tab-pane fade in active' style='height: 380px; overflow: auto;'>";
    blockU();
    var response = { "53": { "@id": 1, "sectionId": 53, "templateId": 46, "sectionName": "UNIT ONE", "maximumDuration": 24, "minimumDuration": 20, "sectionText": "HISTORY OF COMPUTER", "subjectId": 2301, "sectionTotalMarks": 40, "noOfSubsection": 1, "noOfQuestions": 100, "noOfQuestionsNeedToAttempt": 100, "questionTypeID": 1102, "optionCount": 0, "language": "1", "marksForCorrect": 2, "marksForWrong": 1, "marksForBlank": 0, "isMandatory": 1, "isRevisitAllowedEdit": 0, "isRevisitAllowedView": 0, "isQuestionShuffle": 0, "isOptionShuffle": 0, "isActive": 1, "isDeleted": 0, "startQSrlNo": 1, "lastQSrlNo": 100, "qtypename": null }, "54": { "@id": 2, "sectionId": 54, "templateId": 39, "sectionName": "UNIT TWO", "maximumDuration": 24, "minimumDuration": 20, "sectionText": "IMPUT & OUTPUT DEVICES", "subjectId": 2301, "sectionTotalMarks": 40, "noOfSubsection": 1, "noOfQuestions": 20, "noOfQuestionsNeedToAttempt": 20, "questionTypeID": 1102, "optionCount": 0, "language": "1", "marksForCorrect": 2, "marksForWrong": 1, "marksForBlank": 0, "isMandatory": 1, "isRevisitAllowedEdit": 0, "isRevisitAllowedView": 0, "isQuestionShuffle": 0, "isOptionShuffle": 0, "isActive": 1, "isDeleted": 0, "startQSrlNo": 21, "lastQSrlNo": 40, "qtypename": null }, "55": { "@id": 3, "sectionId": 55, "templateId": 39, "sectionName": "UNIT THREE", "maximumDuration": 24, "minimumDuration": 20, "sectionText": "STOREG DEVICES", "subjectId": 2301, "sectionTotalMarks": 40, "noOfSubsection": 1, "noOfQuestions": 20, "noOfQuestionsNeedToAttempt": 20, "questionTypeID": 1102, "optionCount": 0, "language": "1", "marksForCorrect": 2, "marksForWrong": 1, "marksForBlank": 0, "isMandatory": 1, "isRevisitAllowedEdit": 0, "isRevisitAllowedView": 0, "isQuestionShuffle": 0, "isOptionShuffle": 0, "isActive": 1, "isDeleted": 0, "startQSrlNo": 41, "lastQSrlNo": 60, "qtypename": null }, "56": { "@id": 4, "sectionId": 56, "templateId": 39, "sectionName": "UNIT FOUR", "maximumDuration": 24, "minimumDuration": 20, "sectionText": "OPERATION SYSTEM & NUMBER SYSTEM", "subjectId": 2301, "sectionTotalMarks": 40, "noOfSubsection": 1, "noOfQuestions": 20, "noOfQuestionsNeedToAttempt": 20, "questionTypeID": 1102, "optionCount": 0, "language": "1", "marksForCorrect": 2, "marksForWrong": 1, "marksForBlank": 0, "isMandatory": 1, "isRevisitAllowedEdit": 0, "isRevisitAllowedView": 0, "isQuestionShuffle": 0, "isOptionShuffle": 0, "isActive": 1, "isDeleted": 0, "startQSrlNo": 61, "lastQSrlNo": 80, "qtypename": null }, "57": { "@id": 5, "sectionId": 57, "templateId": 39, "sectionName": "UNIT FIVE", "maximumDuration": 24, "minimumDuration": 20, "sectionText": "COMPUTER VIRUS AND NETWORKING", "subjectId": 2301, "sectionTotalMarks": 40, "noOfSubsection": 1, "noOfQuestions": 20, "noOfQuestionsNeedToAttempt": 20, "questionTypeID": 1102, "optionCount": 0, "language": "1", "marksForCorrect": 2, "marksForWrong": 1, "marksForBlank": 0, "isMandatory": 1, "isRevisitAllowedEdit": 0, "isRevisitAllowedView": 0, "isQuestionShuffle": 0, "isOptionShuffle": 0, "isActive": 1, "isDeleted": 0, "startQSrlNo": 1, "lastQSrlNo": 100, "qtypename": null } };
    //key is SECTIONID
    var cnt = 0;
    var sectionId = 0;
    var secName = "";
    for (var key in response) {
        if (response.hasOwnProperty(key)) {
            secName = response[key].sectionName.trim();
            secName = secName.replace(" ", "_");
            //   	        	console.log(secName);
            if (response[key].isMandatory != 1) {
                if (cnt == 0) {
                    htmlStr += "<li  id='secTab" + key + "' class='active'><a data-toggle='tab' href='#" + key + "' onClick=loadSectionWiseQuestion(" + key + ",'" + secName + "');><b style='color:#ffffff;'> " + secName + " (Optional)</b></a></li>";
                    sectionId = key;
                    //	   	   	        	secName=response[key].sectionName;
                } else {
                    htmlStr += "<li id='secTab" + key + "' class=''><a data-toggle='tab' href='#" + key + "' onClick=loadSectionWiseQuestion(" + key + ",'" + secName + "');><b style='color:#ffffff;'> " + secName + " (Optional)</b></a></li>";
                }
            } else {
                if (cnt == 0) {
                    htmlStr += "<li  id='secTab" + key + "' class='active'><a data-toggle='tab' href='#" + key + "' onClick=loadSectionWiseQuestion(" + key + ",'" + secName + "');><b style='color:#ffffff;'> " + secName + "</b></a></li>";
                    sectionId = key;
                    //	   	   	        	secName=response[key].sectionName;
                } else {
                    htmlStr += "<li id='secTab" + key + "' class=''><a data-toggle='tab' href='#" + key + "' onClick=loadSectionWiseQuestion(" + key + ",'" + secName + "');><b style='color:#ffffff;'> " + secName + "</b></a></li>";
                }
            }

        }
        cnt++;
    }
    htmlTabContentDiv += "<div id='grpTextTable'></div>";
    htmlTabContentDiv += "<table id='questTable'></table>";
    htmlTabContentDiv += "</div>   <div class='btn center-block bottomButtonsWraper' style='margin-top: 2px;'>" +
    "<div id='markforCheck'></div><div class='btn-group left_part_buttons'>" +
    //"<button type='button' class='btn btn-primary'  onClick='saveAndPrevious();' style='width:175px;'><span class='h_text_2'>सुरक्षित और पिछला </span> <span class='glyphicon glyphicon-backward' aria-hidden='true'></span> Save & Previous</button>" +
        "<button type='button' class='btn btn-warning'  onClick='ClearOption();'><span class='h_text_2'>खाली</span>Clear <span class='glyphicon glyphicon-erase' aria-hidden='true'></span></button>" +
        "<button type='button' class='btn btn- danger' onclick='skipQuestions(); '><span class='h_text_1 white- text'>छोड़ें</span>Skip</button>"+
    "<button type='button' class='btn btn-success' onClick='saveQuestionAnswer();' style='width:175px;'><span class='h_text_2'>सुरक्षित और अगला</span>Save & Next <span class='glyphicon glyphicon-forward' aria-hidden='true'></span></button>" +
    /*"<button type='button' class='btn btn-primary' style='padding-right: 20px;padding-left: 20px;' onClick='saveUnAnsweredData();'>Skip <span class='glyphicon glyphicon-forward' aria-hidden='true'></span></button>"+*/
    "</div></div>";

    $("#tabId").html(htmlStr);
    $("#tabContentId").html(htmlTabContentDiv);

    loadQuestionPaperSet(sectionId, secName, response);
    unblockU();
}

//Load Question Paper according to the set
function loadQuestionPaperSet(sectionId, secName, sectionObjMap) {
    blockU();
    $.ajax({
        type: "get",
        url: "eongetQuestionPaperSet",
        cache: false,
        success: function (response) {
            unblockU();
            displayTimerWithLastSavedQuest(sectionId, secName, sectionObjMap);
            displaySummary("");
        },
        error: function () {
            $.alert.open('Error while loading Section Tabs');
            unblockU();
        }
    });
}

function displayTimerWithLastSavedQuest(sectionId, secName, sectionObjMap) {
    display = document.querySelector('#timerDurationLeft');
    blockU();
    $.ajax({
        type: "get",
        url: "eonLoadTimerTimeStamp",
        cache: false,
        success: function (lastSavedResponse) {
            if (lastSavedResponse == null || lastSavedResponse == "") {
                var totalPaperDuration = 0;
                if (sectionObjMap != null) {
                    for (var key in sectionObjMap) {
                        totalPaperDuration = parseInt(totalPaperDuration) + parseInt(sectionObjMap[key].maximumDuration);
                    }
                }
                saveTimerTime(sectionId, secName, totalPaperDuration);
            }
            else {
                var darr = lastSavedResponse.timerTimeStamp;
                var MintSecond = darr.split(":");
                //console.log();
                var timeInSec = parseInt(MintSecond[0]) * 60 + parseInt(MintSecond[1]);
                var lastSavedSecName = secName;
                if (lastSavedResponse.sectionId != 0) {
                    lastSavedSecName = sectionObjMap[lastSavedResponse.sectionId].sectionName.trim();
                    lastSavedSecName = lastSavedSecName.replace(" ", "_");
                }

                loadQuestAfterRefresh(lastSavedResponse, lastSavedSecName, sectionId);
                startTimer(timeInSec, display);
                //	   				totalTimeOfExam = timeInSec;
            }
            unblockU();
        },
        error: function () {
            $.alert.open('Error while loading Timer');
            unblockU();
        }
    });
}

//To save the TimerTimeStamp initially only
function saveTimerTime(sectionId, secName, totalPaperDuration) {
    var timeStamp = totalPaperDuration + ":00";

    loadSectionWiseQuestion(sectionId, secName);
    startTimer(totalPaperDuration * 60, display);

    /*$.ajax({
       type : "get",
       url : "eonSaveTimerTimeStamp",
       data : {"timerTimeStamp" : timeStamp, "sectionId":sectionId},
       success : function(response){
           
       },
       error : function(){
           $.alert.open("Error while saving timer time.");
       }
           
    });*/
}

//To get the latest question for preview.
function loadQuestAfterRefresh(lastSavedQuest, lastSavedSecName, sectionId) {

    blockU();
    $.ajax({
        type: "get",
        url: "eonloadQuestFromPreview?sectionId=" + lastSavedQuest.sectionId + "&positionNo=" + lastSavedQuest.positionNo + "&questId=" + lastSavedQuest.questionId,
        cache: false,
        success: function (response) {
            $("#secTab" + sectionId).removeClass('active');
            $("#secTab" + lastSavedQuest.sectionId).addClass('active');

            viewQuestion(response);
            secQuestionPreview(lastSavedQuest.sectionId, lastSavedSecName);
            displaySummary("");
            unblockU();
        },
        error: function () {
            $.alert.open('Error while loading Section Tabs');
            unblockU();
        }
    });
}

//To save the TimerTimeStamp on every 30 second
/*function inBetwenTimeSaver(timeStamp){
    var sectionId=$("#sectionId").val();
    var positionNo=$("#positionId").val();
    var qId=$("#questionId").val();
    
    $.ajax({
       type : "get",
       url : "eonSaveTimerTimeStamp",
       data : {"timerTimeStamp" : timeStamp ,"questionId" : qId, "sectionId" : sectionId,"positionNo" : positionNo },
       success : function(response){
//			startTimer(totalPaperDuration*60, display);
       },
       error : function(){
           $.alert.open("Error while saving timer time.");
       }
           
    });
}
*/
function loadSectionWiseQuestion(paramSectionId, secName) {
    //	 saveNotViewedQuestion();
    var sectionId = $("#sectionId").val();
    var positionNo = $("#positionId").val();
    var questType = $("#questType").val();
    var qId = $("#questionId").val();
    var studentId = 1;
    var studAnsPrimaryId = $("#studentAnsId").val();

    var answerId = 0;
    var sectionName = $("#secName" + sectionId).html();


    var isMarkForRevisit = 0;
    var actionId = 4;

    var timeRemaining = $('#timerDurationLeft').text();

    blockU();
    if (studAnsPrimaryId == 0) {
        $.ajax({
            type: "get",
            url: "eonsaveQuestionAnswer?sectionId=" + sectionId + "&positionNo=" + positionNo + "&questionId=" + qId + "&answerId=" + answerId + "&actionId=" + actionId + "&timerStamp=" + timeRemaining + "&questType=" + questType,
            //data:JSON.stringify({"sectionId" : sectionId, "positionNo" : positionNo}),
            cache: false,
            //contentType: 'application/json',
            success: function (responseOne) {
                $("#studentAnsId").val(responseOne);
                secQuestionPreview(sectionId, sectionName);
                displaySummary("");
                blockU();
                $.ajax({
                    type: "get",
                    url: "eonloadSectionWiseQuestion?sectionId=" + paramSectionId,
                    cache: false,
                    success: function (response) {

                        if (response == "" || response == null) {
                            $("#questTable").html("");
                            secQuestionPreview(paramSectionId, secName);
                            $.alert.open("No Questions for this section");
                            return;
                        }
                        viewQuestion(response);
                        secQuestionPreview(paramSectionId, secName);
                        unblockU();
                    },
                    error: function () {
                        unblockU();
                        $.alert.open('Error while loading Section Tabs');
                    }
                });
                unblockU();
            },
            error: function () {
                $.alert.open('Error while loading Next Question');
                unblockU();
            }
        });

    }
    else {

        blockU();
        $.ajax({
            type: "get",
            url: "eonloadSectionWiseQuestion?sectionId=" + paramSectionId,
            cache: false,
            success: function (response) {

                if (response == "" || response == null) {
                    $("#questTable").html("");
                    secQuestionPreview(paramSectionId, secName);
                    $.alert.open("No Questions for this section");
                    return;
                }
                viewQuestion(response);
                secQuestionPreview(paramSectionId, secName);
                unblockU();
            },
            error: function () {
                unblockU();
                $.alert.open('Error while loading Section Tabs');
            }
        });
    }
}

function getNextQuestion() {
    var sectionId = $("#sectionId").val();
    var sectionName = $("#sectionName").val();
    var positionNo = $("#positionId").val();
    var qId = $("#questionId").val();
    blockU();
    $.ajax({
        type: "get",
        url: "eongetNextQuestion?sectionId=" + sectionId + "&positionNo=" + positionNo + "&questionId=" + qId,
        cache: false,
        success: function (response) {
            if (response.status == -2) {
                $("#secTab" + sectionId).removeClass('active');
                $("#secTab" + response.qpSectionObj.sectionId).addClass('active');
                viewQuestion(response);
                secQuestionPreview(response.qpSectionObj.sectionId, response.qpSectionObj.sectionName);
                return;
            }
            if (response == "") {
                secQuestionPreview(sectionId, sectionName);
                $.alert.open("You have reached at the end of question");
                return;
            }

            viewQuestion(response);
            secQuestionPreview(sectionId, sectionName);
            displaySummary("");
            unblockU();
        },
        error: function () {
            $.alert.open('Error while loading Next Question');
            unblockU();
        }
    });
}

function getPreviousQuestion() {
    var sectionId = $("#sectionId").val();
    var sectionName = $("#sectionName").val();
    var positionNo = $("#positionId").val();
    var qId = $("#questionId").val();
    blockU();
    $.ajax({
        type: "get",
        url: "eongetPreviousQuestion?sectionId=" + sectionId + "&positionNo=" + positionNo + "&questionId=" + qId,
        cache: false,
        success: function (response) {

            if (response.status == -1) {

                $("#secTab" + sectionId).removeClass('active');
                $("#secTab" + response.qpSectionObj.sectionId).addClass('active');
                viewQuestion(response);
                secQuestionPreview(response.qpSectionObj.sectionId, response.qpSectionObj.sectionName);
                unblockU();
                return;
            }
            if (response == "") {
                secQuestionPreview(sectionId, sectionName);
                $.alert.open("Previous Question Not Available");
                unblockU();
                return;
            }

            viewQuestion(response);
            secQuestionPreview(sectionId, sectionName);
            displaySummary("");
            unblockU();
        },
        error: function () {
            $.alert.open('Error while loading Next Question');
            unblockU();
        }
    });
}

function saveNotViewedQuestion() {
    var sectionId = $("#sectionId").val();
    var positionNo = $("#positionId").val();
    var questType = $("#questType").val();
    var qId = $("#questionId").val();
    var studentId = 1;
    var studAnsPrimaryId = $("#studentAnsId").val();

    var answerId = 0;
    var sectionName = $("#secName" + sectionId).html();


    var isMarkForRevisit = 0;
    var actionId = 4;

    var timeRemaining = $('#timerDurationLeft').text();

    blockU();
    if (studAnsPrimaryId == 0) {
        $.ajax({
            type: "get",
            url: "eonsaveQuestionAnswer?sectionId=" + sectionId + "&positionNo=" + positionNo + "&questionId=" + qId + "&answerId=" + answerId + "&actionId=" + actionId + "&timerStamp=" + timeRemaining + "&questType=" + questType,
            //data:JSON.stringify({"sectionId" : sectionId, "positionNo" : positionNo}),
            cache: false,
            //contentType: 'application/json',
            success: function (response) {
                $("#studentAnsId").val(response);
                secQuestionPreview(sectionId, sectionName);
                displaySummary("");
                unblockU();
            },
            error: function () {
                $.alert.open('Error while loading Next Question');
                unblockU();
            }
        });

    }
    else {
        $.alert.open('आप पहले प्रश्न पर हैं| <br> You are on the first question.');
    }
}

// Save Previous Question
function saveAndPrevious() {

    var cureentQuestionStatus = currentSrnoQid;
    cureentQuestionStatus = cureentQuestionStatus.split("_");
    //alert(cureentQuestionStatus[0] +" "+cureentQuestionStatus[1]);
    if (cureentQuestionStatus[0] != 1) {


        var answerId = $("input[name='ansOption']:checked").val();
        //	alert(answerId);
        if (answerId == undefined) {
            answerId = 0;
        }

        var isMarkForRevisit = $("#markForRevisit").val();
        var actionId = returnActionId(answerId, isMarkForRevisit);
        lastSavedAnswer = actionId;
        var timeRemaining = $('#timerDurationLeft').text();

        //		debugger;

        var ansQuesId = cureentQuestionStatus[0];

        if (masterAnswerRecord.hasOwnProperty(cureentQuestionStatus[0])) {
            masterAnswerRecord[ansQuesId] = {
                "ansId": answerId,
                "isMarkedReview": isMarkForRevisit,
                "actionId": actionId,
                "remaingTime": timeRemaining
            }

        } else {
            masterAnswerRecord[ansQuesId] = {
                "ansId": answerId,
                "isMarkedReview": isMarkForRevisit,
                "actionId": actionId,
                "remaingTime": timeRemaining
            }
            //console.log(masterAnswerRecord[ansQuesId]);
        }

        loadQuestfromPreview(parseInt(cureentQuestionStatus[0]) - 1, parseInt(cureentQuestionStatus[1]) - 1);
        showColorOnTab(masterAnswerRecord);

        showALertOnSaveMethod(lastSavedAnswer, 0);
        //$.alert.open('आपका उत्तर  सुरक्षित कर लिया गया है। <br> Your answer has been saved');
    } else {
        loadQuestfromPreview(parseInt(cureentQuestionStatus[0]), parseInt(cureentQuestionStatus[1]));
        showColorOnTab(masterAnswerRecord);
        $.alert.open('आप पहले प्रश्न पर हैं <br> You are on first question.');
    }

}

function saveQuestionAnswer() {
    var cureentQuestionStatus = currentSrnoQid;
    cureentQuestionStatus = cureentQuestionStatus.split("_");

    //debugger;
    var answerId = $("input[name='ansOption']:checked").val();
    //	alert(answerId);
    if (answerId != undefined) {
        var isMarkForRevisit = $("#markForRevisit").val();

        var actionId = returnActionId(answerId, isMarkForRevisit);
        lastSavedAnswer = actionId;

        var timeRemaining = $('#timerDurationLeft').text();

        //		debugger;

        var ansQuesId = cureentQuestionStatus[0];
        //var currentQus = parseInt(cureentQuestionStatus[0]) + 1;
        //alert(currentQus);
        //	console.log(masterAnswerRecord[ansQuesId]);

        if (masterAnswerRecord.hasOwnProperty(cureentQuestionStatus[0])) {
            masterAnswerRecord[ansQuesId] = {
                "ansId": answerId,
                "isMarkedReview": isMarkForRevisit,
                "actionId": actionId,
                "remaingTime": timeRemaining
            }
        } else {
            masterAnswerRecord[ansQuesId] = {
                "ansId": answerId,
                "isMarkedReview": isMarkForRevisit,
                "actionId": actionId,
                "remaingTime": timeRemaining
            }
        }
        //$.alert.open('आपका उत्तर  सुरक्षित कर लिया गया है। <br> Your answer has been saved');
        if (cureentQuestionStatus[0] < totalQuest) {
            showALertOnSaveMethod(lastSavedAnswer, 1);
            loadQuestfromPreview(parseInt(cureentQuestionStatus[0]) + 1, parseInt(cureentQuestionStatus[1]) + 1);
           
        } else {
            /*loadQuestfromPreview(parseInt(cureentQuestionStatus[0]), parseInt(cureentQuestionStatus[1]));
            showColorOnTab(masterAnswerRecord);*/

            $.alert.open('आप अंतिम प्रश्न पर हैं| <br> You are on last Question.');
        }
       
    }
    else {
        answerId = 0;
        $.alert.open('कृपया कोई भी विकल्प चुनें| <br> Please select any option ');
        return false;
    }
    showColorOnTab(masterAnswerRecord);
    //  console.log(masterAnswerRecord);
}

function skipQuestions() {

    var cureentQuestionStatus = currentSrnoQid;
    cureentQuestionStatus = cureentQuestionStatus.split("_");

    var answerId = $("input[name='ansOption']:checked").val();
    //	alert(answerId);
    if (answerId == undefined) {
        answerId = 0;
   

    var isMarkForRevisit = $("#markForRevisit").val();

    var actionId = returnActionId(answerId, isMarkForRevisit);
    lastSavedAnswer = actionId;

    var timeRemaining = $('#timerDurationLeft').text();

    //		debugger;

    var ansQuesId = cureentQuestionStatus[0];

    //	console.log(masterAnswerRecord[ansQuesId]);

    if (masterAnswerRecord.hasOwnProperty(cureentQuestionStatus[0])) {
        masterAnswerRecord[ansQuesId] = {
            "ansId": answerId,
            "isMarkedReview": isMarkForRevisit,
            "actionId": actionId,
            "remaingTime": timeRemaining
        }
    } else {
        masterAnswerRecord[ansQuesId] = {
            "ansId": answerId,
            "isMarkedReview": isMarkForRevisit,
            "actionId": actionId,
            "remaingTime": timeRemaining
        }
    }

    if (cureentQuestionStatus[0] < totalQuest) {
        showALertOnSaveMethod(lastSavedAnswer, 1);
        loadQuestfromPreview(parseInt(cureentQuestionStatus[0]) + 1, parseInt(cureentQuestionStatus[1]) + 1);

    } else {
        /*loadQuestfromPreview(parseInt(cureentQuestionStatus[0]), parseInt(cureentQuestionStatus[1]));
		showColorOnTab(masterAnswerRecord);*/

        $.alert.open('आप अंतिम प्रश्न पर हैं| <br> You are on last Question.');
    }
    } else {
        $.alert.open('कृपया विकल्प साफ़ करें <br> Please clear the option ');
        return false;
    }
    showColorOnTab(masterAnswerRecord);
}

function markForVisitOption(obj, uncheckVal, checkVal) {
    var cureentQuestionStatus = currentSrnoQid;
    cureentQuestionStatus = cureentQuestionStatus.split("_");
    var answerId = $("input[name='ansOption']:checked").val();
    //	alert(answerId);
    if (answerId != undefined) {
        if (obj.checked == true) {
            obj.value = checkVal;
        }
        else {

            obj.value = uncheckVal;
        }
        var isMarkForRevisit = $("#markForRevisit").val();

        var actionId = returnActionId(answerId, isMarkForRevisit);
        lastSavedAnswer = actionId;

        var timeRemaining = $('#timerDurationLeft').text();

        //		debugger;

        var ansQuesId = cureentQuestionStatus[0];

        //	console.log(masterAnswerRecord[ansQuesId]);

        if (masterAnswerRecord.hasOwnProperty(cureentQuestionStatus[0])) {
            masterAnswerRecord[ansQuesId] = {
                "ansId": answerId,
                "isMarkedReview": isMarkForRevisit,
                "actionId": actionId,
                "remaingTime": timeRemaining
            }
        } else {
            masterAnswerRecord[ansQuesId] = {
                "ansId": answerId,
                "isMarkedReview": isMarkForRevisit,
                "actionId": actionId,
                "remaingTime": timeRemaining
            }
        }
        if (cureentQuestionStatus[0] < totalQuest) {
            showALertOnSaveMethod(lastSavedAnswer, 1);
            loadQuestfromPreview(parseInt(cureentQuestionStatus[0]) + 1, parseInt(cureentQuestionStatus[1]) + 1);

        } else {
            $.alert.open('आप अंतिम प्रश्न पर हैं| <br> You are on last Question.');
        }
    }
    else {
        answerId = 0;
        $.alert.open('कृपया कोई भी विकल्प चुनें| <br> Please select any option ');
        $("#markForRevisit").prop("checked", false);
        return false;
    }
    showColorOnTab(masterAnswerRecord);
}
//markForVisitOption(this, 0, 1);
function showALertOnSaveMethod(val, mode) {
    //if (val == 3) {
    //    $.alert.open('તમે સમીક્ષા માટે પ્રશ્ન ચિહ્નિત કર્યો છે અને તમે પછીથી તેને જવાબ આપી શકો છો.<br>you have marked the question for review and you can answer it later.');
    //} else if (val == 2) {
    //    $.alert.open('તમે આ પ્રશ્નનો જવાબ આપ્યો છે અને ફરી સમીક્ષા માટે પ્રશ્ન ચિહ્નિત(માર્ક) પણ કર્યો છે.<br>You have answered this question and also selected mark for review.');
    //}

    //if (mode == 1) { //next
    //    if (val == 4) {
    //        $.alert.open('તમે આ પ્રશ્નનો જવાબ આપેલ નથી અને આગળના પ્રશ્ન તરફ વધ્યા છો.<br> You have not answer this question and going on next.');
    //    } else if (val == 1) {
    //        $.alert.open('તમે આ પ્રશ્નનો જવાબ આપ્યો છે અને આગળના પ્રશ્ન તરફ વધ્યા છો.<br> You have answered this question and going on next.');
    //    }
    //} else {   //previous
    //    if (val == 4) {
    //        $.alert.open('તમે આ પ્રશ્નનો જવાબ આપેલ નથી અને અગાઉના પ્રશ્ન પર ગયા છો.<br> You have not answer this question and going on the previous.');
    //    } else if (val == 1) {
    //        $.alert.open('તમે આ પ્રશ્નનો જવાબ આપ્યો છે અને અગાઉના પર જઈ રહ્યા છો.<br> You have answered this question and going on the previous.');
    //    }
    //}
}

function showColorOnTab(obj) {
    ansrd = 0;
    unAnsrd = 0;
    ansrdAndMark = 0;
    unAnsrdAndMark = 0;
    ntVewd = 0;
    for (var key in obj) { 
        //var num = key;
        //alert(num);
        if (obj[key].actionId == 4) {
            //$('#'+key).addClass('btn btn-circle btn-danger').removeClass('IsBestAnswer');
            $('#' + key).attr("class", "btn btn-circle btn-danger ");
            $('#' + key).attr("data-toggle", "tooltip");
            $('#' + key).attr("data-original-title", "उत्तर नहीं दिया / Unanswered!");
            $('#' + key).attr("data-placement", "bottom");
            $('#' + key).attr("title", "");
            //$('#' + key+1).attr("class", "btn btn-circle btn-primary ");
            unAnsrd = unAnsrd + 1;

        }
        else if (obj[key].actionId == 3) {
            $('#' + key).attr("class", "btn btn-circle btn-primary ");
            $('#' + key).attr("data-toggle", "tooltip");
            $('#' + key).attr("data-original-title", "उत्तर नही दिया और पुनर्विचार के लिए चिन्हित किया / Unanswered & Marked For Review!");
            $('#' + key).attr("data-placement", "bottom");
            $('#' + key).attr("title", "");
            unAnsrdAndMark = unAnsrdAndMark + 1;
        }
        else if (obj[key].actionId == 2) {
            $('#' + key).attr("class", "btn btn-circle btn-warning ");
            $('#' + key).attr("data-toggle", "tooltip");
            $('#' + key).attr("data-original-title", "उत्तर दिया और पुनर्विचार के लिए चिन्हित किया / Answered & Marked For Review!");
            $('#' + key).attr("data-placement", "bottom");
            $('#' + key).attr("title", "");
            ansrdAndMark = ansrdAndMark + 1;
        }
        else if (obj[key].actionId == 1) {
            $('#' + key).attr("class", "btn btn-circle btn-success ");
            $('#' + key).attr("data-toggle", "tooltip");
            $('#' + key).attr("data-original-title", "उत्तर दिया / Answered!");
            $('#' + key).attr("data-placement", "bottom");
            $('#' + key).attr("title", "");
            ansrd = ansrd + 1;
        }
        else if (obj[key].actionId == 0) {
            $('#' + key).attr("class", "btn btn-circle btn-default ");
            $('#' + key).attr("title", "देखा नहीं गया / Not Viewed");
        }
    }
    //	console.log("ansrd "+ansrd+" unAnsrd "+unAnsrd+" ansrdAndMark "+ansrdAndMark+" unAnsrdAndMark "+unAnsrdAndMark);
    //ClearOption();
    var vewed = ansrd + unAnsrd + unAnsrdAndMark + ansrdAndMark;
    ntVewd = totalQuest - vewed;
   
    $("#notViewedAns").html(ntVewd);
    $("#answeredAns").html(ansrd);
    $("#unansweredAns").html(unAnsrd);
    $("#unansweredAndMarkedAns").html(unAnsrdAndMark);
    $("#answeredAndMarkedAns").html(ansrdAndMark);
}

function showSummaryDetails(obj) {
    var htmlStr = "";
    htmlStr += "<tr><td style='background-color: #ECE3E3;'><b>कुल / Total</b>"
	   					+ "</td><td style='background-color: #ECE3E3;'><b>" + totalQuest

	   					+ "</b></td>"
	   					+ "</td><td style='background-color: #ECE3E3;'><b>" + ntVewd

	   					+ "</b></td>"
	        			+ "><td style='background-color: #ECE3E3;'><b>" + ansrd + "</b></td>"
	        			+ "<td style='background-color: #ECE3E3;'><b>" + unAnsrd + "</b></td>"
	        			//+ "<td style='background-color: #ECE3E3;'><b>" + unAnsrdAndMark + "</b></td>"
	        			+ "<td style='background-color: #ECE3E3;'><b>" + ansrdAndMark
	        			+ "</b></td>";

    if (obj == "summary") {
        htmlStr += "</tr>";
        $("#summaryBody").html(htmlStr);
    } if (obj == "resultSummary") {
        htmlStr += "<td style='background-color: #ECE3E3;'><b><div id ='corectAns'></div></b></td></tr>";
        $("#resultSummaryBody").html(htmlStr);
    } else {
        htmlStr += "</tr>";
        $("#submitSummaryBody").html(htmlStr);
        $("#timeleft").text($("#timerDurationLeft").text());
        $("#timeleftHindi").text($("#timerDurationLeft").text());
    }
}

function returnActionId(answerId, isMarkForRevisit) {

    if (answerId == 0 && isMarkForRevisit == 0) {
        //Not Viewed 
        return 4;
    }
    else if (answerId == 0 && isMarkForRevisit == 1) {
        //Not Answered but marked for revisit
        return 3;
    }
    else if (answerId != 0 && isMarkForRevisit == 0) {
        //answered and saved 
        return 1;
    }
    else if (answerId != 0 && isMarkForRevisit == 1) {
        // answered and marked for revisit
        return 2;
    }
}

//for loading secQuestionPreview

function secQuestionPreview(sectionId, secName) {
    var questPrevHtml = "";
    var secNameHtml = "";
    blockU();

    $.ajax({
        type: "get",
        url: "eonloadSecWiseQuestPreview?sectionId=" + sectionId,
        cache: false,
        success: function (response) {
            secNameHtml = "<center><b id='secName" + sectionId + "'>" + secName + "</b></center>"

            for (var i = 0; i < response.length; i++) {
                if (response[i].actionId == 4) {
                    questPrevHtml += "<button type='button' class='btn btn-circle btn-danger' onclick='loadQuestfromPreview(this," + sectionId + ");' id='" + response[i].positionNo + "' value='" + response[i].questionId + "'>" + response[i].positionNo + "</button>";
                }
                else if (response[i].actionId == 3) {
                    questPrevHtml += "<button type='button' class='btn btn-circle btn-primary' onclick='loadQuestfromPreview(this," + sectionId + ");'  id='" + response[i].positionNo + "' value='" + response[i].questionId + "'>" + response[i].positionNo + "</button>";
                }
                else if (response[i].actionId == 2) {
                    questPrevHtml += "<button type='button' class='btn btn-circle btn-warning' onclick='loadQuestfromPreview(this," + sectionId + ");'  id='" + response[i].positionNo + "' value='" + response[i].questionId + "'>" + response[i].positionNo + "</button>";
                }
                else if (response[i].actionId == 1) {
                    questPrevHtml += "<button type='button' class='btn btn-circle btn-success' onclick='loadQuestfromPreview(this," + sectionId + ");'  id='" + response[i].positionNo + "' value='" + response[i].questionId + "'>" + response[i].positionNo + "</button>";
                }
                else if (response[i].actionId == 0) {
                    questPrevHtml += "<button type='button' class='btn btn-circle btn-default' onclick='loadQuestfromPreview(this," + sectionId + ");'  id='" + response[i].positionNo + "' value='" + response[i].questionId + "'>" + response[i].positionNo + "</button>";
                }
            }

            $("#secName").html(secNameHtml);
            $("#questPrevDiv").html(questPrevHtml);

            //For First time loading of section wise question
            if ($("#sectionName").val() == "") {
                $("#sectionName").val(secName);
            }
            unblockU();
        },
        error: function () {
            $.alert.open('Error while loading Section Tabs');
            unblockU();
        }
    });
}

function loadQuestfromPreview(srid, qid) {
    ClearOption();
    currentSrnoQid = srid + "_" + qid;

    var optionIndex = "";
    var htmlStr = "";
    //	 $(".q_index").html("<b>Q"+srid+":</b>");
    for (var i = 0; i < masterQuestionLoad.length; i++) {
        var qWid = i == 0 ? 95 : 95;
        if (masterQuestionLoad[i].qID == qid) {
            //	 		$(".q_text").html("<b>"+masterQuestionLoad[i].questionText+"<span class='optionBreak'></span>"+masterQuestionLoad[i].secondaryQuestionText+"</b>");
            htmlStr += "<tr><td valign=top><div class='q_div'><div class='q_index' style='width:" + qWid + "px;'><b>Ques " + srid + ":</b></div><div class='q_text'><b>" + masterQuestionLoad[i].questionText + "<span class='optionBreak'></span>" + masterQuestionLoad[i].secondaryQuestionText + "</b></div></div><div class='q_index'><b>उत्तर/ Answers:</b></div></td></tr>";
            for (var j = 0; j < masterQuestionLoad[i].qPQuestionOptions.length; j++) {

                if (j == 0) {
                    optionIndex = "<b>A)</b>";
                }
                else if (j == 1) {
                    optionIndex = "<b>B)</b>";
                }
                else if (j == 2) {
                    optionIndex = "<b>C)</b>";
                }
                else if (j == 3) {
                    optionIndex = "<b>D)</b>";
                }
                else if (j == 4) {
                    optionIndex = "<b>E)</b>";
                }

                var optionTextData = masterQuestionLoad[i].qPQuestionOptions[j].optionText + "<span class='optionBreak'></span>" + masterQuestionLoad[i].qPQuestionOptions[j].secondaryOptionText;
                htmlStr += "<tr><td><label class='light_black'><div class='button_bg option_list' onclick=makeGreen('div" + masterQuestionLoad[i].qPQuestionOptions[j].oID + "'); id='div" + masterQuestionLoad[i].qPQuestionOptions[j].oID + "'><div><span class='option_num'>" + optionIndex + "</span><input type='radio' value='" + masterQuestionLoad[i].qPQuestionOptions[j].oID + "' name='ansOption' id='" + masterQuestionLoad[i].qPQuestionOptions[j].oID + "'>  <div class='option_wrap'>  " + optionTextData + "</div> </div><input type='hidden' name='optionId' value=" + masterQuestionLoad[i].qPQuestionOptions[j].oID + "></div></label></td></tr>";

            }
            //		$(".q_text").html(htmlStr);
            $("#questTable").html(htmlStr);
            //console.log(masterAnswerRecord[srid]);
            if (masterAnswerRecord[srid] != undefined) {

                var actId = masterAnswerRecord[srid].actionId;
                var ansId = masterAnswerRecord[srid].ansId;

                setTimeout(function () {
                    if (actId == 2 || actId == 3 || actId == 4) {
                        $("#markForRevisit").prop("checked", true);
                        $("#markForRevisit").val(1);
                    } else {
                        $("#markForRevisit").prop("checked", false);
                        $("#markForRevisit").val(0);
                    }

                    if (ansId != 0) {

                        $("#div" + ansId).css({ "background-color": "#5cb85c", "color": "#ffffff" });
                        $("#" + ansId).prop("checked", true);
                    }
                }, 10);
            }
        }
    }
}

function modifyQuestion(question) {
    while (question.indexOf("</img>") != -1) {
        var startIndex = question.indexOf("<img>");
        var endIndex = parseInt(question.indexOf("</img>")) + parseInt(6);
        question = question.substring(0, startIndex) + "</__>" + question.substring(endIndex, question.length);

    }
    return question;
}

function modifyOption(option) {
    while (option.indexOf("</img>") != -1) {
        var startIndex = option.indexOf("<img>");
        var endIndex = parseInt(option.indexOf("</img>")) + parseInt(6);
        option = option.substring(0, startIndex) + "</__>" + option.substring(endIndex, option.length);

    }
    return option;
}

function viewQuestion(response) {
    var sectionName = ""
    //For First time loading of section wise question
    if ($("#sectionName").val() != undefined) {
        sectionName = $("#sectionName").val();
    }
    var htmlStr = "";
    $("#questTable").html(htmlStr);
    htmlStr = "<tr><td></td><td><input type='hidden' name='questType' id='questType' value=" + response.qtype + "></td></tr>";
    htmlStr += "<tr><td></td><td><input type='hidden' name='questionId' id='questionId' value=" + response.qID + "></td></tr>";
    htmlStr += "<tr><td></td><td><input type='hidden' name='positionId' id='positionId' value=" + response.positionNo + "></td></tr>";
    //For SectionId
    htmlStr += "<tr><td></td><td><input type='hidden' name='sectionId' id='sectionId' value=" + response.qpSectionObj.sectionId + "></td></tr>";
    //For Section Name
    htmlStr += "<tr><td></td><td><input type='hidden' name='sectionName' id='sectionName' value=" + response.qpSectionObj.sectionName + "></td></tr>";

    htmlStr += "<tr><td></td><td><input type='hidden' name='studentAnsId' id='studentAnsId' value=0></td></tr>";

    if (response.qtype == 1757698986) {
        // For handling subjective type question
        /*var modifiedQuestionText=modifyQuestion( response.questionText);
         
        for(var questImgIndx=0;questImgIndx<response.qPQuestionImages.length;questImgIndx++){		
            if(response.qPQuestionImages[questImgIndx] != undefined){
                if(response.qPQuestionImages[questImgIndx].qimg!="AA=="){
                    modifiedQuestionText=modifiedQuestionText.replace("</__>","<img src=data:image/png;base64,"+response.qPQuestionImages[questImgIndx].qimg+" height=30%; width=30%;>");	
                }
            }
        }
        
        htmlStr+="<tr><td valign=top><b>Q"+response.positionNo+":</b>&nbsp;</td><td><b>"+ modifiedQuestionText +"</b></td></tr>";
        htmlStr+="<tr><td valign=top><b>Q"+response.positionNo+":</b>&nbsp;</td><td><b>"+ modifiedQuestionText +"</b></td></tr>";*/
    } else {

        var questionTextBilingual = "";
        if (response.secondaryQuestionText != null && response.secondaryQuestionText.trim() != '') {
            questionTextBilingual = response.questionText + "<span class='optionBreak'></span>" + response.secondaryQuestionText;
        } else {
            questionTextBilingual = response.questionText;
        }
        var modifiedQuestionText = modifyQuestion(questionTextBilingual);

        for (var questImgIndx = 0; questImgIndx < response.qPQuestionImages.length; questImgIndx++) {
            if (response.qPQuestionImages[questImgIndx] != undefined) {
                if (response.qPQuestionImages[questImgIndx].qimg != "AA==") {
                    modifiedQuestionText = modifiedQuestionText.replace("</__>", " <img class='questionOptionImg' src=data:image/png;base64," + response.qPQuestionImages[questImgIndx].qimg + " >");
                }
            }
        }

        htmlStr += "<tr><td valign=top><div class='q_div'><div class='q_index'><b>Q" + response.positionNo + ":</b></div><div class='q_text'><b>" + modifiedQuestionText + "</b></div></div></td></tr>";
        var optionIndex = "";
        var studAnsId = 0;
        var studAnsPrimaryId = response.studentAnsId;
        for (var i = 0; i < response.qPQuestionOptions.length; i++) {

            if (i == 0) {
                optionIndex = "<b>A)</b>";
            }
            else if (i == 1) {
                optionIndex = "<b>B)</b>";
            }
            else if (i == 2) {
                optionIndex = "<b>C)</b>";
            }
            else if (i == 3) {
                optionIndex = "<b>D)</b>";
            }
            else if (i == 4) {
                optionIndex = "<b>E)</b>";
            }

            //ON THE BASIS OF response.qtype I.E. QUESTIONTYPE THE OPTION TYPE WOULD BE CHANGED--IN SECOND PHASE---NOW ONLY SINGLE TYPE

            var optionTextBilingual = "";
            if (response.qPQuestionOptions[i].secondaryOptionText != null && response.qPQuestionOptions[i].secondaryOptionText.trim() != '') {
                optionTextBilingual = response.qPQuestionOptions[i].optionText + "<span class='optionBreak'></span>" + response.qPQuestionOptions[i].secondaryOptionText;
                //    					console.log(response.qPQuestionOptions[i].secondaryOptionText);
            } else {
                optionTextBilingual = response.qPQuestionOptions[i].optionText;
            }
            //    				console.log(optionTextBilingual);

            var optionTextData = modifyOption(optionTextBilingual);
            for (var imgCounter = 0; imgCounter < response.qPQuestionOptions[i].qPQuestionOptionsImages.length; imgCounter++) {
                if (response.qPQuestionOptions[i].qPQuestionOptionsImages[imgCounter] != undefined) {

                    if (response.qPQuestionOptions[i].qPQuestionOptionsImages[imgCounter].img != "AA==") {
                        optionTextData = optionTextData.replace("</__>", " <img class='questionOptionImg' src=data:image/png;base64," + response.qPQuestionOptions[i].qPQuestionOptionsImages[imgCounter].img + ">");
                    }
                }
            }

            if (response.qtype == 3) {
                htmlStr += "<tr><td><div><label class='light_black'><input type='checkbox' value='" + response.qPQuestionOptions[i].oID + "' name='ansOption' id='" + response.qPQuestionOptions[i].oID + "'> <div class='option_wrap'> " + optionIndex + " " + optionTextData + "</div></label><input type='hidden' name='optionId' value=" + response.qPQuestionOptions[i].oID + "></div></td></tr>";
            } else {
                htmlStr += "<tr><td><label class='light_black'><div class='button_bg' onclick=makeGreen('div" + response.qPQuestionOptions[i].oID + "'); id='div" + response.qPQuestionOptions[i].oID + "'><div style='padding-top:3px; display: inline-block;'><input type='radio' value='" + response.qPQuestionOptions[i].oID + "' name='ansOption' id='" + response.qPQuestionOptions[i].oID + "'> " + optionIndex + "</div><div class='option_wrap'>  " + optionTextData + "</div><input type='hidden' name='optionId' value=" + response.qPQuestionOptions[i].oID + "></div></label></td></tr>";
            }
        }
    }
    //For rendering the question with options
    $("#questTable").html(htmlStr);
    $("#grpTextTable").html(response.qpGroupObj.groupText);

    //Mark for revisit checkbox 
    markForRevisitHtml = "<tr><td><p><b><input type='checkbox' class='check_mark_visit' value='' id='markForRevisit' name='markForRevisit' onClick='changeCheckboxVal(this,0,1)'><label for='markForRevisit' class='mark_visit'>समीक्षा के लिए अंकित करे<br> Mark For Review</label></b></p></td></tr>";
    $("#markforCheck").html(markForRevisitHtml);
    if (response.actionId == 2 || response.actionId == 3) {
        $("#markForRevisit").prop("checked", true);
        $("#markForRevisit").val(1);
    }

    //To set the studAnsPrimaryId for updation
    studAnsPrimaryId = response.studentAnsId;
    $("#studentAnsId").val(studAnsPrimaryId);

    //for having the student answer to be checked
    for (var i = 0; i < response.qPQuestionOptions.length; i++) {
        if (response.qPQuestionOptions[i].studentAns == 1) {
            studAnsId = response.qPQuestionOptions[i].oID;
            $("#" + studAnsId).prop("checked", true);
            $("#div" + studAnsId).css({ "background-color": "#5cb85c", "color": "#ffffff" });
        }
    }
}

function displaySummary(mode) {
    var htmlStr = "";
    var sectionCount = 0;

    var totalViewedNotAnsCount = 0;
    var totalNotViewedCount = 0;
    var totalAnsweredCount = 0;
    var totalNotAnsMarkForRevisit = 0;
    var totalAnsMarkForRevistCount = 0;

    var totalPaperQuestion = 0;
    blockU();
    $.ajax({
        type: "get",
        url: "eondisplaySummary",
        cache: false,
        success: function (response) {
            for (var sectionId in response) {
                sectionCount++;
                if (response.hasOwnProperty(sectionId)) {
                    var actionCountMap = response[sectionId];

                    var viewedNotAnsCount = 0;
                    var notViewedCount = 0;
                    var answeredCount = 0;
                    var notAnsMarkForRevisit = 0;
                    var ansMarkForRevistCount = 0;

                    var totalSectionQuestion = 0;

                    if (actionCountMap.hasOwnProperty(0)) {
                        notViewedCount = actionCountMap[0];
                        totalNotViewedCount = totalNotViewedCount + notViewedCount;

                    }
                    if (actionCountMap.hasOwnProperty(1)) {
                        answeredCount = actionCountMap[1];
                        totalAnsweredCount = totalAnsweredCount + answeredCount;
                    }
                    if (actionCountMap.hasOwnProperty(2)) {
                        ansMarkForRevistCount = actionCountMap[2];
                        totalAnsMarkForRevistCount = totalAnsMarkForRevistCount + ansMarkForRevistCount;
                    }
                    if (actionCountMap.hasOwnProperty(3)) {
                        notAnsMarkForRevisit = actionCountMap[3];
                        totalNotAnsMarkForRevisit = totalNotAnsMarkForRevisit + notAnsMarkForRevisit;
                    }
                    if (actionCountMap.hasOwnProperty(4)) {
                        viewedNotAnsCount = actionCountMap[4];
                        totalViewedNotAnsCount = totalViewedNotAnsCount + viewedNotAnsCount;
                    }
                    var bothAreNotViewedCount = notViewedCount + viewedNotAnsCount;

                    totalSectionQuestion = answeredCount + notViewedCount + ansMarkForRevistCount + notAnsMarkForRevisit + viewedNotAnsCount;

                    htmlStr += "<tr><td>Section-" + sectionCount
                                + "</td><td>" + totalSectionQuestion + "</td>"
                                + "</td><td>" + notViewedCount + "</td>"
                                + "><td>" + answeredCount + "</td>"
                                + "<td>" + viewedNotAnsCount + "</td>"
                                //+ "<td>" + notAnsMarkForRevisit + "</td>"
                                + "<td>" + ansMarkForRevistCount + "</td></tr>";

                    totalPaperQuestion = totalPaperQuestion + totalSectionQuestion;
                }
            }
            $("#notViewedAns").html(totalNotViewedCount);
            $("#answeredAns").html(totalAnsweredCount);
            $("#unansweredAns").html(totalViewedNotAnsCount);
            $("#unansweredAndMarkedAns").html(totalNotAnsMarkForRevisit);
            $("#answeredAndMarkedAns").html(totalAnsMarkForRevistCount);

            htmlStr += "<tr><td style='background-color: #ECE3E3;'><b>Total</b>"
                    + "</td><td style='background-color: #ECE3E3;'><b>" + totalPaperQuestion

                    + "</b></td>"
                    + "</td><td style='background-color: #ECE3E3;'><b>" + totalNotViewedCount

                    + "</b></td>"
                    + "><td style='background-color: #ECE3E3;'><b>" + totalAnsweredCount + "</b></td>"
                    + "<td style='background-color: #ECE3E3;'><b>" + totalViewedNotAnsCount + "</b></td>"
                    //+ "<td style='background-color: #ECE3E3;'><b>" + totalNotAnsMarkForRevisit + "</b></td>"
                    + "<td style='background-color: #ECE3E3;'><b>" + totalAnsMarkForRevistCount

                    + "</b></td></tr>";

            if (mode == "submit") {
                $("#submitSummaryBody").html(htmlStr);
                $("#timeleft").text($("#timerDurationLeft").text());
            }
            else if (mode == "summary") {
                $("#summaryBody").html(htmlStr);
            }
            unblockU();
        },
        error: function () {
            $.alert.open('Error while loading Master Data');
            unblockU();
        }
    });
}

function showInstruction() {
    blockU();
    $.ajax({
        type: "get",
        url: "eontdmloadInstruction",
        cache: false,
        success: function (response) {
            var htmlstr = "<div class='panel panel-info'><div class='panel-heading'><center>Online Exam Instructions</div><div class='panel-body'>";
            htmlstr += response[0].instructionOne;
            htmlstr += "</div></div>";
            htmlstr += "<div class='panel panel-info'><div class='panel-heading'><center>Exam Paper Instruction</div><div class='panel-body'>";
            htmlstr += response[0].instructionTwo;
            htmlstr += "</div></div>";

            $("#instructionId").html(htmlstr);
            unblockU();
        },
        error: function () {
            $.alert.open('Error while loading First Instruction');
            unblockU();
        }
    });
}

function showProfile() {
    blockU();
    $.ajax({
        type: "get",
        url: "eontdmloadCandidateInfo",
        cache: false,
        success: function (response) {
            $("#nameOfExaminee").text(response[0].name);
            $("#category").text(response[0].category);
            $("#gender").text(response[0].gender);
            $("#mobileNo").text(response[0].mobileNo);
            $("#candidateEmail").text(response[0].email);
            $("#regNo").text(response[0].regNo);

            var myDate = new Date(new Date(response[0].dOB));
            var localTime = myDate.toLocaleString().split(",");
            var date = localTime[0].split("/");
            $("#candidateDOB").text(date[1] + "/" + date[0] + "/" + date[2]);

            //				$("#candidateDOB").text(date.getDate()+"-"+date.getMonth()+"-"+date.getFullYear());
            $("#rollNumber").text(response[0].applicationNo);
            if (response[0].img != null) {
                document.getElementById("candidateImg").src = "data:image/png;base64," + response[0].img;
            }
            unblockU();
        },
        error: function () {
            $.alert.open('Error Loading Profile');
            unblockU();
        }
    });
}

function ClearOption() {
    $("input:radio[name='ansOption']").each(function (i) {
        this.checked = false;
    });

    $(".button_bg").css({ "background-color": "#fff", "color": "#000000" });

    $('input[type="checkbox"]').prop('checked', false);
    $("#markForRevisit").val(0);

    loadTooltipJS();
    //$.alert.open('आपका उत्तर खाली कर दिया गया है <br> Your answer has been cleared.');
}

function ClearOptionByButton() {
    $("input:radio[name='ansOption']").each(function (i) {
        this.checked = false;
    });

    $(".button_bg").css({ "background-color": "#fff", "color": "#000000" });

    $('input[type="checkbox"]').prop('checked', false);
    $("#markForRevisit").val(0);

    loadTooltipJS();
    $.alert.open('आपका उत्तर साफ़ हो गया है <br> Your answer has been cleared.');
}

function submitExam() {

    stopTimer();

    // window.location.href = "feedbacksuccess.html";
    window.location.href = "/Exam/Engine"

}

function submitAfterResult() {
    $.ajax({
        type: "get",
        url: "eontdmSubmitExam",
        cache: false,
        success: function (response) {
            if (response == 1) {
                document.getElementById("logoutPaperSubmitForm").submit();
                //				window.location.href="tdmviewStudentResult";
                //document.getElementById("logoutPaperSubmitForm").submit();
            }
            else {
                $.alert.open('Error while submitting the exam,Please try again and if fails, please co-ordinate with your invigilator');
            }
            unblockU();
        },
        error: function () {
            $.alert.open('Error Submitting Exam');
            unblockU();
        }
    });
}

function captureEvent(eventId) {
    var timeRemaining = $('#timerDurationLeft').text();
    $.ajax({
        type: "get",
        url: "eontdmcaptureEvent?eventId=" + eventId + "&timerStamp=" + timeRemaining,
        cache: false,
        success: function (response) {
            unblockU();
        },
        error: function () {
            $.alert.open('Error While Capturing Event');
            unblockU();
        }
    });
}

function makeGreen(id) {
    $(".button_bg").css({ "background-color": "#fff", "color": "#000000" });
    $("#" + id).css({ "background-color": "#5cb85c", "color": "#ffffff" });
}


/*
function loadReplacementData(){
	$.ajax({
		type : "get",
		url : "eonLoadReplacementData",
		cache : false,
		success : function(response) {
			console.log(response);
			replaceData = response;
			unblockU();
	},
	error : function() {
		$.alert.open('Error While Capturing Event');
		unblockU();
		}
	});
}*/

/*function loadExaminationDetails(){
	
//	console.time('Testtime');
	$.ajax({
		type : "get",
		url : "tdmloadExamByExamid",
		cache : false,
		success : function(response) {
//			console.log(response);
			totalTimeOfExam =parseInt(response.examTime)*60;
			timeAfterStartExam=parseInt(response.biocallAfterStartExam)*60;
			timeBeforeEndExam=parseInt(response.biocallBeforeEndExam)*60;
			totalAllowedBiocall = response.totalAllowedBioCall;
			autoSubmit = response.autoSubmit;
//			console.log(totalTimeOfExam +" "+timeAfterStartExam+" "+timeBeforeEndExam+" "+totalAllowedBiocall+" "+autoSubmit);
	},
	error : function() {
		$.alert.open('Error While Capturing Event');
		unblockU();
		}
	});
//	console.timeEnd('Testtime');
}*/


function bioCallSubmit() {

    $.ajax({
        asyn: false,
        type: "get",
        url: "eontdmUpdateIsLogin",
        cache: false,
        success: function (response) {
            if (response == 1) {
                document.getElementById("logoutForm").submit();
            }
        },
        error: function () {
            $.alert.open('Error while loading Master Data');
        }
    });
}

function showResult() {

    correctMarks = 0;

    for (var key in masterAnswerRecord) {

        if (resultKey.hasOwnProperty(key)) {
            // console.log(resultKey[key]+"_________"+masterAnswerRecord[key].ansId);
            if (resultKey[key] == masterAnswerRecord[key].ansId) {
                //console.log("True");
                correctMarks = correctMarks + 1
            }
        }
    }
    // $( ".target" ).show();

    $('#corectAns').html(correctMarks);
    $('#submitModal').modal('hide');
    $("#mainDiv").hide();
    $("#resultDiv").show();
    //   alert("TotalMarks "+totalQuest+" Correct Marks "+correctMarks)
}