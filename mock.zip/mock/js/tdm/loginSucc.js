function chkPreRegistration(){
	
	
	$.ajax({
		url : "eontdmChkPreRegistration",
		contentType : false,
		cache : false,
		success : function(data) {
		
			if(data==1){
				document.form1.submit();
			}else{
				document.form1.action="eontdmviewCandidateProfile";
				document.form1.submit();
			}
		},
		error : function() {
			$.alert.open("error in PreRegistration");
		}
	});
}