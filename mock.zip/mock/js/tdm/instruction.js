function loadFirstInstruction(){
	$("#timeLeftLabel").hide();
	$("#timerDurationLeft").hide();
   $("#firstInst").show();
   $("#seecondInst").hide();
	$("#btnProceed").hide(); 
	$("#backBtn").hide(); 
	$("#checkInstruction").hide();
	$("#btnNext").show();
	
}

function loadSecondInstruction(){
	$("#timeLeftLabel").show();
	$("#timerDurationLeft").show();
	$("#btnNext").hide();
   $("#firstInst").hide();
   $("#seecondInst").show();
	$("#btnProceed").show();
	$("#backBtn").show(); 
	$("#checkInstruction").show();
	$("#addInstruction").html("");
	/*$.ajax({
   		type : "get",
   		url : "eontdmloadInstruction",
   		cache : false,
   		success : function(response) {
   			
   			
   			$("#addInstruction").html(response[0].instructionTwo);
   		},
   		error : function() {
   			$.alert.open('Error while loading Second Instruction');
   		}
   	});*/
}

function disableKeyboard(){
	//alert("hiii");
//	if (confirm("Are You Sure?You are going to start the Examination.")) {  
	$.ajax({
   		type : "get",
   		url : "eontdmDisableKeyboard",
   		cache : false,
   		success : function(response) {
   			
   			document.frmInstruction.submit();
   			
   		},
   		error : function() {
   			$.alert.open('Error while loading Second Instruction');
   		}
   	});
//}
}