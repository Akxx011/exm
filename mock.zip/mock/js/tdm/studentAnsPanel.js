function loadLecStudtAnsResult(){

	var lecId = $("#tdmLec :selected").val();
	var htmStr="";
	$
			.ajax({
				type : "get",
				url : "tdmStudentAnsResult?lecId=" + lecId ,						
				cache : false,
				success : function(response) {

					for (var i = 0; i < response.length; i++) {
						var srNo=i+1;
						alert(response.length);
						htmStr+="<tr><td>"+srNo+"</td>" 
								+"<td>"+response[i].name+"</td>" 
								+"<td>"+response[i].applicationNo+"</td>" 
								+"<td>"+response[i].attemptedQuestion+"</td>" 		
								+"<td>"+response[i].correctQuestion+"</td>" 
								+"<td>"+response[i].inCorrectQuestion+"</td></tr>" ;
					}
					$('#tblStudentAnswerInfoData').html(htmStr);
				},
				error : function() {
					$.alert
							.open('Error while loading Student Answer Panel');
				}
			});
}