function BioCallunlock() {
	
	 var checkArray = ["username", "password","remarks"];
	 var msgArray = [ "Please enter Login Id", "Please enter Password","Please enter remarks"];
	
	 if (validateFields(checkArray, 1, msgArray)) {
		 var loginId = $("#username").val();
		 var password = $("#password").val();
		$.ajax({
			type :"get",
			url : "checkBiocallUserAuthentication",
			data : {"loginId" : loginId, "password" : password},
			cache : false,
			success : function(response){
				if(response == 1){
					if (confirm("You are going to unlock. Are you sure ?")) {
						document.form1.submit();
					}
				}else{
					$("#errorMsg").html("Login Id or Password is invalid.")
				}
			},
			error : function(){
				alert("Something wrong. Try later!");
			}
		});
		
	}
}

