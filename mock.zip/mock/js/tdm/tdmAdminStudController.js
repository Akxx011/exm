function loadExam() {
	$("#theadSdntActive").hide();
	$("#tblStudentInfo").hide();
	var htmlstr = "<option value=-1>Select</option>";
	$.ajax({
		type : "get",
		url : "tdmloadExam",
		cache : "false",
		success : function(response) {

			for (var i = 0; i < response.length; i++) {
				htmlstr += "<option value=" + response[i].examId + ">"
						+ response[i].nameOfExam + "</option>";
			}
			$("#tdmExam").html(htmlstr);
			
		},
		error : function() {
			$.alert.open("");
		}
	});
}
function loadSlot(examId) {

	var htmlstr = "<option value=-1>Select</option>";
	$.ajax({
		type : "get",
		url : "tdmloadSlot?examId=" + examId.value,
		cache : "false",
		success : function(response) {
			for (var i = 0; i < response.length; i++) {
				htmlstr += "<option value=" + response[i].examSlotMapId + ">"
						+ response[i].examSlotStartTime + " TO "
						+ response[i].examSlotEndTime + "</option>";
			}
			$("#tdmExamSlot").html(htmlstr);
		},
		error : function() {
			$.alert.open("");
		}
	});
}


function loadExamStateCity() {
	$("#table").hide();
	var htmlStr = "<option value=-1>Select</option>";
	var htmlStr1 = "<option value=-1>Select</option>";
	var examId = $("#tdmExam :selected").val();
	var slotId = $("#tdmExamSlot :selected").val();
	var a=[];
	$.ajax({
		type : "get",
		url : "tdmloadExamCity?examId=" + examId + "&slotId=" + slotId,
		cache : false,

		success : function(response) {
             var stateId=0;
			for (var i = 0; i < response.length; i++) {
				
				
				
				if(i<(response.length-1)){
					stateId=response[i+1].stateBean.stateId;
				}
			
				
				if(i==0 || response[i].stateBean.stateId!=stateId){
					htmlStr += "<option value=" + response[i].stateBean.stateId
					+ ">" + response[i].stateBean.stateName + "</option>";
				}
				/*if(i==(response.length-1)){
					htmlStr += "<option value=" + response[i].stateBean.stateId
					+ ">" + response[i].stateBean.stateName + "</option>";
				}*/
				
				htmlStr1 += "<option value=" + response[i].cityBean.cityId
						+ ">" + response[i].cityBean.cityName + "</option>";
				
			}
			$("#tdmstate").html(htmlStr);
			$("#tdmCity").html(htmlStr1);
		},
		error : function() {
			$.alert.open('Error while load loadExamStateCity');
		}
	});
}

function loadLEC() {
	$("#table").hide();
	var htmlstr = "<option value=-1>Select</option>";
	var examId = $("#tdmExam :selected").val();
	var slotId = $("#tdmExamSlot :selected").val();
	var stateId = $("#tdmstate :selected").val();
	var cityId = $("#tdmCity :selected").val();
	$
			.ajax({
				type : "get",
				url : "tdmloadMonitorLEC?examId=" + examId + "&slotId="
						+ slotId + "&stateId=" + stateId + "&cityId=" + cityId,
				cache : false,

				success : function(response) {

					for (var i = 0; i < response.length; i++) {
						htmlstr += "<option value=" + response[i].centreId
								+ ">" + response[i].name + "</option>";

					}
					$('#tdmLec').html(htmlstr);
				},
				error : function() {
					$.alert
							.open('Error while load lec according to exam,slot,state and city');
				}
			});
}

function loadActiveStudents() {
	var examId = $("#tdmExam :selected").val();
	var slotId = $("#tdmExamSlot :selected").val();
	var slotTime=$("#tdmExamSlot :selected").text();
	slotTime=slotTime.split(" TO ");
	var slotStartTime=slotTime[0];
	var slotEndTime=slotTime[1];
	var htmlstr = "<option value=-1>Select</option>";
	$.ajax({
		type : "get",
		url : "tdmloadActiveStudents?examId=" + examId + "&slotId=" + slotId,
		cache : "false",
		success : function(response) {
			$("#theadSdntActive").show();
			$("#tblExamName").text($("#tdmExam :selected").text());
			$("#tblSlotId").text($("#tdmExamSlot :selected").val());
			$("#tblSlotStartTime").text(slotStartTime);
			$("#tblSlotEndTime").text(slotEndTime);
			$("#tblActiveStud").text(response.length);
		},
		error : function() {
			$.alert.open("");
		}
	});
}


function focusField(){
	$("#studentValue").focus();
}

function validateTextField(){
	
	if($("#studentId :selected").val()==-1){
		return false;
	}
	if($("#studentId :selected").val()==1){
		
	}
	if($("#studentId :selected").val()==2){
		
	}
}


function ProcessAction(){
	var action=$("#actionId :selected").text();
	var studentId=$("#rollNo").text();
	
	$.ajax({
		type : "get",
		url : "tdmprocessAction?action=" + action+"&studentId="+studentId,
		cache : "false",
		success : function(response) {
		
		if(response==1){
			$("#msg").text(action +" Action performed successfully ")
		}
		},
		error : function() {
			$.alert.open("");
		}
	});
}


function loadStudent(){
	if($("#studentId :selected").val()==-1){
		$("#msg").text("Please select a value first");
		$("#tblStudentInfo").hide();
		return;
	}
	if($("#studentValue").val()==""){
		$("#studentValue").focus();
		$("#tblStudentInfo").hide();
		return;
	}
	
	var field=$("#studentId :selected").text();
	var value=$("#studentValue").val();
	$.ajax({
		type : "get",
		url : "tdmloadStudent?field="+ field+"&value="+value,
		cache : "false",
		success : function(response) {
			if(response.length>0){	
				$("#msg").text("");	
			$("#tblStudentInfo").show();
			$("#studentName").text(response[0].studentName);
			$("#rollNo").text(response[0].studentId);
			$("#currentIP").text(response[0].ipAddress);
			}else{
				$("#tblStudentInfo").hide();
				$("#msg").text("Please enter the correct value");
				$("#studentValue").focus();
			}
		},
		error : function() {
			$.alert.open("");
		}
	});
}