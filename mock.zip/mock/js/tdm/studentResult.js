$(document).ready(function() {
	 window.addEventListener('popstate', function () {
	     history.pushState(null, null, '');
	 });
});

function loadStudtResult(){

	var htmStr="";
	$
			.ajax({
				type : "get",
				url : "tdmStudentResult" ,
				async: false,
				cache : false,
				timeout: 30000,
				success : function(response) {
					
					if(response!=null && response!=''){
						$("#tblStudentResultInfo").show();
						console.log(response);
							htmStr+="<tr><td><b>1</b></td>"
									+"<td><center><b>"+response.totalAttempted+"</b></center></td>" 	
									+"<td><center><b>"+response.answered+"</b></center></td>" 
									+"<td><center><b>"+response.unAnswered+"</b></center></td>" 
									+"<td><center><b>"+response.answeredAndMarkedForReview+"</b></center></td>" 
									+"<td><center><b>"+response.unAnsweredAndMarkedForReview+"</b></center></td>" 
									+"<td><center><b>"+response.correctMarks+"</b></center></td>" 
									+"<td><center><b>"+response.negativeMarks+"</b></center></td>" 
									+"<td><center><b>"+response.totalMarks+"</b></center></td></tr>" ;
							
							stName="<b>"+response.name+"</b>";
							stRoll="<b>"+response.applicationNo+"</b>";
							stGender="<b>"+response.gender+"</b>";
							stFatherName="<b>"+response.fatherName+"</b>";
							
							$('#tblStudentResultInfoData').html(htmStr);
							$('#stName').html(stName);
							$('#stFatherName').html(stFatherName);
							$('#stRoll').html(stRoll);
							$('#stGender').html(stGender);
							
							
						}
					else{
						$.alert
						.open('You have not attempted any question ,so your result is not generated.<br>Thank You');
					}
					
				
				},
				error : function() {
					$.alert
							.open('Error while loading Student Result');
				}
			});
}

function redirectToFeedBack(){
//	document.getElementById("logoutPaperSubmitForm").submit();

	$.ajax({
		type : "get",
		url : "eontdmSubmitExam",
		cache : false,
		success : function(response) {
			if(response==1){
				document.getElementById("logoutPaperSubmitForm").submit();
			}
			else{
				$.alert.open('Error while submitting the exam,Please try again and if fails, please co-ordinate with your invigilator');
			}
			unblockU();	
	},
	error : function() {
		$.alert.open('Error Submitting Exam');
		unblockU();
		}
	});

}