var gridSize=0;
function loadECB(){
	var htmlStr="<option value=-1>Select</option>";
	$.ajax({
		type : "get",
		url : "eongetEcb",
		cache : false,
		success : function(response) {
			
			for (var i = 0; i < response.length; i++) {
				
				htmlStr+="<option value="+response[i].ecbId+">"+response[i].ecbName+"</option>";
			}
			$('#ecbId').html(htmlStr);
		},
		error : function() {
			$.alert.open('Error while loading ECB');
		}
	});
}

function loadYear(){
	
	var yearStr="<option value=-1>Select</option>";
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();

	
			for (var i = 0; i < 6; i++) {
				
				var year=yyyy+i;
				yearStr+="<option value="+i+">"+year+"</option>";
			}
			loadECB();
			$('#examYear').html(yearStr);
}

function loadExam(obj){

	var examStr="<option value=-1>Select</option>";
	var htmlStr="<option value=-1>All</option>";
	var ecbId=$('#ecbId').val();
	var examYear=$('#examYear option:selected').text();
	var examYearId=$('#examYear').val();
	
	if(examYearId!=-1 && ecbId!=-1){
		blockU();
	$
	.ajax({
		type : "get",
		url : "eongetExamination?ecbId="+ecbId+"&examYear="+examYear,
		cache : false,
		success : function(response) {
			unblockU("msg");
			for (var i = 0; i < response.length; i++) {
				
				var examNo=0;
				if(i<(response.length-1)){
					examNo=response[i+1].examId;
				}
				
				if(response[i].examId!=examNo){
				
				examStr+="<option value="+response[i].examId+">"+response[i].nameOfExam+"</option>";
				}
			}
			$('#examId').html(examStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while loading exam');
		}
	});
	
	}
	
	else{
		$('#examId').html(examStr);
		$('#stateId').html(htmlStr);
		$('#cityId').html(htmlStr);
		$('#lecId').html(htmlStr);
		}
	
}

function loadExamState(obj){
	
	
	var stateStr="<option value=-1>All</option>";
	var examId=$('#examId').val();
	if(examId=="-1")
		{
		return false;
		}
	$
	.ajax({
		type : "get",
		url : "eongetExamState?examId="+examId,
		cache : false,
		success : function(response) {
			
			for (var i = 0; i < response.length; i++) {
				
				stateStr+="<option value="+response[i].stateId+">"+response[i].stateName+"</option>";
			}
			$('#stateId').html(stateStr);
		},
		error : function() {
			$.alert.open('Error while loading exam state');
		}
	});
}

	function loadExamCity(obj){
	
	var cityStr="<option value=-1>All</option>";
	var examId=$('#examId').val();
	if(examId=="-1")
	{
	return false;
	}
	$
	.ajax({
		type : "get",
		url : "eongetExamCity?examId="+examId,
		cache : false,
		success : function(response) {
			
			for (var i = 0; i < response.length; i++) {
				
				//$.alert.open(response[i].stateId+"-"+response[i].cityId);
				cityStr+="<option value="+response[i].cityId+">"+response[i].cityName+"</option>";
			}
			$('#cityId').html(cityStr);
		},
		error : function() {
			$.alert.open('Error while loading exam city');
		}
	});
}

function loadExamLec(obj){
	blockU();
	var lecStr="<option value=-1>All</option>";
	var examId=$('#examId').val();
	if(examId=="-1")
	{
	return false;
	}
	$
	.ajax({
		type : "get",
		url : "eongetExamLec?examId="+examId,
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				
				//$.alert.open(response[i].city+"-"+response[i].centreId);
				lecStr+="<option value="+response[i].centreId+">"+response[i].name+"</option>";
			}
			$('#lecId').html(lecStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while loading Lec1');
		}
	});
}

function hideLecGrid(){
	$('#lecGrid').hide();}

function checkUncheck(obj){
	
	if($('input:checkbox[name=lecCheckboxHead]').is(':checked')){
		$('input:checkbox[name=lecCheckbox]').prop('checked',true);
	}
	else{
		$('input:checkbox[name=lecCheckbox]').prop('checked',false);
		}
	
}

function loadLecGrid(){
	blockU();
	$("#lecGrid tbody").html("");
	var frm=$('#lecInExamCity');
	var values = []; //array of lecId
	var lecIdStr=""; //parameter string to be sent to the controller
	
	//this puts the lecId in an array eliminating -1
	$('#lecId option').each(function() { 
		if($(this).attr('value')!=-1){
	    values.push($(this).attr('value'));
		}
	});
	
	lecIdStr="lecId="+values;
	
	if($('#lecId').val()==-1){ 
		blockU();
//		$('#table').bootstrapTable('showLoading'); 
		$.ajax({
	        type: frm.attr('method'),
	        url: frm.attr('action'),
	        data: lecIdStr,
	        success: function (response) { 
	        	
	        	/*$('#table').bootstrapTable('hideLoading');
	 			$('#notification').hide();  
	 			$('#table').bootstrapTable('load', response);  */
	 			unblockU("");
	        	
	        gridSize=response.length;	
	        $('#lecGrid').show();
	        $('#lecGrid').append("<tbody id='lecGridBody'>"); 
	        for(var i=0;i<response.length;i++){
	        	
	        	var stateValue=response[i].state;
	        	var cityValue=response[i].city;
	        	var state=$("#stateId option[value="+stateValue+"]").text();
	        	var city=$("#cityId option[value="+cityValue+"]").text();
	        	
	        	$('#lecGrid').append("<tr><td>"+(i+1)+"</td><td>"
	        			+state+"</td><td>"
	        			+city+"</td><td>"
	        			+response[i].centreId+"</td><td>"
	        			+response[i].name+"</td><td>"
	        			+response[i].totalComputers+"</td><td>"
	        			+"<input type='checkbox' name='lecCheckbox' id='"+(i+1)+"'>"+"<input type='hidden' name='lecId' id='lecId"+(i+1)+"' value="+response[i].centreId+">"+"</td></tr>");
	        }
	        $('#lecGrid').append("</tbody>");
	 			
	        $('input:checkbox[name=lecCheckboxHead]').prop('checked',true);
	        $('input:checkbox[name=lecCheckbox]').prop('checked',true);
	      },
			error : function() {
				unblockU("");
				$.alert.open('Error while loading Grid,Data not found');
				/*$('#table').bootstrapTable('hideLoading');
	 			$('#notification').hide();  */
			}
	    });
	}
	
	else{
		blockU();
//		$('#tblData').bootstrapTable('showLoading');
//		$('#table').bootstrapTable('showLoading');
		$.ajax({
	        type: frm.attr('method'),
	        url: frm.attr('action'),
	        data: frm.serialize(),
	        success: function (response) {
	        	/*$('#table').bootstrapTable('hideLoading'); 
	 			$('#notification').hide();  
	 			$('#table').bootstrapTable('load', response);  */
	 			
	        	unblockU("");
	        	gridSize=response.length;	
	        	$('#lecGrid').show();
	 	        $('#lecGrid').append("<tbody>"); 
	 			
	 	        for(var i=0;i<response.length;i++){
	 	        	
	 	        	var stateValue=response[i].state;
		        	var cityValue=response[i].city;
		        	var state=$("#stateId option[value="+stateValue+"]").text();
		        	var city=$("#cityId option[value="+cityValue+"]").text();
		        	
	 	        	$('#lecGrid').append("<tr><td>"+(i+1)+"</td><td>"
	 	        			+state+"</td><td>"
	 	        			+city+"</td><td>"
	 	        			+response[i].centreId+"</td><td>"
	 	        			+response[i].name+"</td><td>"
	 	        			+response[i].totalComputers+"</td><td>"
	 	        			+"<input type='checkbox' name='lecCheckbox' id='"+(i+1)+"'>"+"<input type='hidden' name='lecId' id='lecId"+(i+1)+"' value="+response[i].centreId+">"+"</td></tr>");
	 	        	}
	 	        $('#lecGrid').append("</tbody>");
	 	        
	 	        $('input:checkbox[name=lecCheckboxHead]').prop('checked',true);
	 	        $('input:checkbox[name=lecCheckbox]').prop('checked',true);
	        },
			error : function() {
				unblockU("");
				$.alert.open('Error while loading Grid,Data not found');
				/*$('#table').bootstrapTable('hideLoading');
	 			$('#notification').hide();*/  
			}
	    });
	}

}
/*
 * *************************************************************
 * table 
 */
/*function runningFormatter(value, row, index) {
	index++;
    return index;
}
 function stateAction(value, row, index){
	 var val=value;
	 var state= $("#stateId option[value="+val+"]").text();
	 return state;
}
 
 function cityAction(value, row, index){
	 var val=value;
	 var city= $("#cityId option[value="+val+"]").text();
	 return city;
}
 
 function selectAction(value, row, index){
	 index++;
	 return "<input type='checkbox' name='lecCheckbox' id='"+index+"'>"+"<input type='hidden' name='lecId' id='lecId"+index+"' value="+row.centreId+">";
}*/
/*
 * *************************************************************
 */


function sendEmail(){
	var obj = document.getElementsByName("lecCheckbox");
	var cnt=0;
		 for(var i=0;i<obj.length;i++)
			 {
			 if(obj[i].checked==true)
				 {
					 cnt++;
					 break;
				 }
			 }
		 if(cnt==0)
			 {
			 $.alert.open("Please select at least one LEC");
			 return false;
			 }
	if(!confirm("Are you sure? You are going to mail the selected LEC"))
			{
		return false;
			}
			
	var j=0;
	var frm=$("#lecGridForm");
	var lecIdArray=[];
	var examName=$("#examName").text();
	var dtOfExam=$("#dtOfExam").text();
	var slotsNo=$("#noOfSlots").text();
	var examId=$('#examId').val();
	
	//$.alert.open(examName);
	//for generating array of lecId
	for(var i=0;i<gridSize;i++){
		j=i+1;
		var id= $("#"+j);
		var lecId=$("#lecId"+j);
		if(id.is(':checked')){
			lecIdArray.push(lecId.val());
		}
	}
	blockU();
	$.ajax({
        type: frm.attr('method'),
        url:"eonsendEmailForAvailability?lecIdArray="+lecIdArray+"&examName="+examName+"&dtOfExam="+dtOfExam+"&slotsNo="+slotsNo+"&examId="+examId+"",
        success: function (response) {
        	unblockU("");
        	if(response!=0){
        		$.alert.open("Mail has been sent to "+response+" LECs successfully");
        	}
        	else{
        		$.alert.open("Please select atleast one LEC to send the Mail");
        	}
        	
        },
		error : function() {
			unblockU("");
			$.alert.open('Error while sending mail,Please check the mail address');
		}
    });
}


function onStateLoadCity(obj){
	blockU();
	var cityStr="<option value=-1>All</option>";
	var examId=$('#examId').val();
	var stateId=obj.value;
	
	if(stateId!=-1){
	$
	.ajax({
		type : "get",
		url : "eongetExamCityOnState?examId="+examId+"&stateId="+stateId,
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				
				cityStr+="<option value="+response[i].cityId+">"+response[i].cityName+"</option>";
			}
			$('#cityId').html(cityStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while loading city');
		}
	});
	}
}

function onStateLoadLec(obj){
	blockU();
	var lecStr="<option value=-1>All</option>";
	var stateId=$('#stateId').val();
	var examId=$('#examId').val();
	
	if(stateId!=-1){
	$
	.ajax({
		type : "get",
		url : "eongetExamLecOnState?examId="+examId+"&stateId="+stateId,
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				
				lecStr+="<option value="+response[i].centreId+">"+response[i].name+"</option>";
			}
			$('#lecId').html(lecStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while loading Lec2');
		}
	});
	
	}
	else{
		loadExamLec(-1);
		}
}

function onCityLoadLec(obj){
	blockU();
	var lecStr="<option value=-1>All</option>";
	var cityId=obj.value;
	var examId=$('#examId').val();
	if(examId=="-1")
	{
	return false;
	}
	if(cityId!=-1){
		$
		.ajax({
			type : "get",
			url : "eongetExamLecOnCity?examId="+examId+"&cityId="+cityId,
			cache : false,
			success : function(response) {
				unblockU("");
				for (var i = 0; i < response.length; i++) {
					
					lecStr+="<option value="+response[i].centreId+">"+response[i].name+"</option>";
				}
				$('#lecId').html(lecStr);
			},
			error : function() {
				unblockU("");
				$.alert.open('Error while loading Lec3');
			}
		});
	}
	else{
		onStateLoadLec(-1);
	}
	
}

function getExamSlotDetaill(){
	blockU();
var examId=$('#examId').val();
	
		$
		.ajax({
			type : "get",
			url : "eongetExamDetl?examId="+examId,
			cache : false,
			success : function(response) {
				unblockU("");
				for (var i = 0; i < response.length; i++) {
					
					var startDt=(response[i].startDate).split(' ')[0];
					var endDt=(response[i].endDate).split(' ')[0];
					
					$("#examName").text(response[i].nameOfExam);
					$("#dtOfExam").text(startDt+" to "+endDt);
					$("#noOfSlots").text(response[i].noOfSlots);
					
					
				}
			},
			error : function() {
				unblockU("");
				$.alert.open('Error while loading Slot');
			}
		});
	}

