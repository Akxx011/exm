/*// start for next tab
$(document).ready(function() {
    $('.nexttab').click(function(){
  $('.ss-tabs > .active').next('li').find('a').trigger('click');
});
});
*/

//for tab disable
$(document).ready(function() {
	$('.ss li').not('.active').addClass('disabled');
    $('.ss li').not('.active').find('a').removeAttr("data-toggle");
  /*  $('.bt').click(function(){
        enable next tab
        $('.nav li.active').next('li').removeClass('disabled');
        $('.ss li.active').next('li').find('a').attr("data-toggle","tab")
        $('.ss-tabs > .active').next('li').find('a').trigger('click');

    });*/
});

//load allotment
function loadAllotment(){
	examId=$('#examId').val();
	loadAllotExamState();
	loadAllotExamCity();
	loadAllotExamLec();
	loadSlot();
	loadLecAllotmentGrid();
	 $('.ss li.active').next('li').removeClass('disabled');
     $('.ss li.active').next('li').find('a').attr("data-toggle","tab")
     $('.nav-tabs > .active').next('li').find('a').trigger('click');
     
    $("#ecbAllot").text($("#ecbId :selected").text());
    $("#ecbAllot2").text($("#ecbId :selected").text());
    $("#examAllot").text($("#examId :selected").text());
    $("#examAllot2").text($("#examId :selected").text());
    $("#examCodeAllot").text($("#examCode").text());  
}




//function loadTab(){
//	$.alert.open("hello");	
//	loadExamState('this');
//	loadExamCity('this');
//	loadExamLec('this');
//	
//}

/*
 * This function loads all the existing Ecb and set this ecb into the dropdown 
 * of select Ecb
 */
function loadECB(){
	
	var htmlStr="<option value=-1>Select</option>";
	
	$
	.ajax({
		type : "get",
		url : "eongetEcb",
		cache : false,
		success : function(response) {
			
			for (var i = 0; i < response.length; i++) {
				
				htmlStr+="<option value="+response[i].ecbId+">"+response[i].ecbName+"</option>";
			}
			$('#ecbId').html(htmlStr);
		},
		error : function() {
			$.alert.open('Error while load city');
		}
	});
}
/*
 * This function loads all the years and put it on the dropdown
 */
function loadYear(){
	
	var yearStr="<option value=-1>Select</option>";
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();

	
			for (var i = 0; i < 6; i++) {
				
				var year=yyyy+i;
				yearStr+="<option value="+i+">"+year+"</option>";
			}
			
			$('#examYear').html(yearStr);
}
/*
 * This function loads all the exam as per selected  Ecb and set this ecb into the dropdown 
 * of select Ecb
 */
function loadExam(obj){
	blockU();
	$("#examCode").text("");
	$("#EXAM").text("");
	$("#ECB").text("");
	$("#tblExamSAllDtl").html("");
	$("#NOSFE").text("");
	$("#TSRFE").text("");
	$("#BPR").text("");
	$("#OvrRqd").text("");
	$("#NOCFE").text("");
	$("#NOCenterFE").text("");
	$("#noOfExamSlots").text("");
	var examStr="<option value=-1>Select</option>";
	var htmlStr="<option value=-1>All</option>";
	var ecbId=$('#ecbId').val();
	var examYear=$('#examYear option:selected').text();
	var examYearId=$('#examYear').val();
	
	$
	.ajax({
		type : "get",
		url : "eongetExamination?ecbId="+ecbId+"&examYear="+examYear,
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				
				var examNo=0;
				if(i<(response.length-1)){
					examNo=response[i+1].examId;
				}
				
				if(response[i].examId!=examNo){
				
				examStr+="<option value="+response[i].examId+">"+response[i].nameOfExam+"</option>";
				}
			}
			$('#examId').html(examStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load Exam');
		}
	});
}

/*
 * This function loads all the examState for the particular exam 
 */
function loadExamState(obj){
	blockU();
	if($("#examId option:selected").text()!="Select"){
		$("#examCode").text($('#examId :selected').text()+1);
		$("#EXAM").text($('#examId :selected').text());
		$("#ECB").text($('#ecbId :selected').text());
	}else{
		$("#examCode").text("");
		$("#EXAM").text("");
		$("#ECB").text("");
	}
	var stateStr="<option value=-1>All</option>";
	var examId=$('#examId').val();
	if(examId=="-1")
		{
		return false;
		}
	$
	.ajax({
		type : "get",
		url : "eongetExamState?examId="+examId,
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				$("#NOSFE").text(response.length);
				stateStr+="<option value="+response[i].stateId+">"+response[i].stateName+"</option>";
			}
			$('#stateId').html(stateStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load State');
		}
	});
}
/*
 * This function loads all the  ExamCity
 */
	function loadExamCity(obj){
		
	var cityStr="<option value=-1>All</option>";
	var examId=$('#examId').val();
	if(examId=="-1")
	{
	return false;
	}
	$
	.ajax({
		type : "get",
		url : "eongetExamCity?examId="+examId,
		cache : false,
		success : function(response) {
			
			for (var i = 0; i < response.length; i++) {
				$("#NOCFE").text(response.length);
				
				cityStr+="<option value="+response[i].cityId+">"+response[i].cityName+"</option>";
			}
			$('#cityId').html(cityStr);
		},
		error : function() {
			$.alert.open('Error while load city');
		}
	});
}
	
	
	
	
var centerIdForExam=[];
var ttlUsableCopForExam=parseInt(0);
var ttlfilledCompForExam=0;
var remainCompForExam=0;
var slotIds=[];
var slotCapacity=[];	
var slotSize=[];
function loadExamLec(obj){
	
	$("#tblExamSAllDtl").html("");
	$("#tblSAllDtl").html("");
	ttlUsableCopForExam=parseInt(0);
	
	$("#NOSFE").text("");
	$("#TSRFE").text("");
	$("#BPR").text("");
	$("#OvrRqd").text("");
	$("#NOCFE").text("");
	$("#NOCenterFE").text("");
	$("#noOfExamSlots").text("");
	var lecStr="<option value=-1>All</option>";
	var examId=$('#examId').val();

	if(examId=="-1")
	{
	return false; 
	}
	$
	.ajax({
		type : "get",
		url : "eongetExamLec?examId="+examId,
		cache : false,
		success : function(response) {
	
			for (var i = 0; i < response.length; i++) {
				$("#NOCenterFE").text(response.length);
				centerIdForExam.push(response[i].centreId);
				ttlUsableCopForExam=ttlUsableCopForExam+parseInt(response[i].totalUsableComputers);
				lecStr+="<option value="+response[i].centreId+">"+response[i].name+"</option>";
			}
			$('#lecId').html(lecStr);
			
			getSlotCapacity();
			
		},
		error : function() {
			$.alert.open('Error while load ExamLec');
		}
	});
}


function getExamSlotDetaill(){
	
	$("#tblExamSAllDtl").html("");
	var htmlStr=null;
	
	var examId=$('#examId').val();
	var noOfSlots=0;
	
		$
		.ajax({
			type : "get",
			url : "eongetExamDetl?examId="+examId,
			cache : false,
			success : function(response) {
				
				for (var i = 0; i < response.length; i++) {
					noOfSlots=response[0].noOfSlots;
					var examinationSize=response[0].examinationSize;
					var bufferPer=response[0].bufferPer;
					var overall=parseInt(examinationSize)*parseInt(bufferPer);
					var overallPercentage=parseInt(overall)/100;
					var overallPer=parseInt(examinationSize)+parseInt(overallPercentage);
					
					$("#OvrRqd").text(overallPer);
                    
					$("#TSRFE").text(response[0].examinationSize);
					$("#noOfExamSlots").text(response[0].noOfSlots);
					$("#BPR").text(response[0].bufferPer+"%");
					var startDt=(response[i].startDate).split(' ')[0];
					var endDt=(response[i].endDate).split(' ')[0];
					
					$("#examName").text(response[i].nameOfExam);
					$("#dtOfExam").text(startDt+" to "+endDt);
					$("#noOfSlots").text(response[i].noOfSlots);
					
					
				}
				if(noOfSlots>0){
					
				for(var j=0;j<noOfSlots;j++){
					var inBufferPer=parseInt(slotSize[j])*parseInt(bufferPer);
					var Buffer=parseInt(inBufferPer)/100;
					var ttlWithBuffer=parseInt(slotSize[j])+parseInt(Buffer);
					var remainingValue=0;
					remainingValue=parseInt(ttlUsableCopForExam)-parseInt(slotCapacity[j]);
					var k=j+1;
					htmlStr="<tr><td>slot"+k+"</td><td>"+slotSize[j]+"</td><td>"+Buffer+"</td><td>"+ttlWithBuffer+"</td><td>"+ttlUsableCopForExam+"</td><td>"+slotCapacity[j]+"</td><td>"+remainingValue+"</td></tr>";
//					var htmlStrr1="<tr><td>slot"+k+"</td><td>"+slotSize[j]+"</td></tr>";
					
					$("#tblExamSAllDtl").append(htmlStr);
					$("#tblSAllDtl").append(htmlStr);
//					$("#tblAllotDtl").append(htmlstrr1);
				}
				
				}
				
			},
			error : function() {
				$.alert.open('Error while load city');
			}
		});
	}


function getSlotDetail(){
    var examId=$('#examId').val();
	$
	.ajax({
		type : "get",
		url : "eongetSlotDetl?centerId="+examId+"&SlotIds="+slotIds,
		cache : false,
		success : function(response) {
		for(var i=0;i<response.length;i++){
			slotCapacity.push(response[i]);
			
			}		
			slotIds=[];//reinitialize added by amit kumar
			getExamSlotDetaill();
	},
	error : function() {
		$.alert.open('Error while load SlotDetail');
	}
});
}

function getSlotCapacity(){
	var examId=$('#examId').val();
	
		$
		.ajax({
			type : "get",
			url : "eongetSlotcap?ExamId="+examId,
			cache : false,
			success : function(response) {
				
				
					for(var i=0;i<response.length;i++){
						
					slotIds.push(response[i].slotID);
					slotSize.push(response[i].slotCapacity);
					}
					getSlotDetail();
		},
		error : function() {
			$.alert.open('Error while load getSlotCapacity');
		}
	});
	}







