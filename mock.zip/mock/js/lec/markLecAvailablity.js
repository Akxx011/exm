var gridLength = 0;
$(document).ready(function() {
	$(".opn").click(function() {
		$("#myModal").modal('show');
	});
});

function getExamDetail(obj) {
	$("#examdetailtbl").html("");
	var examid=$("#markExam").val();
	
	if (obj.value == -1) {
		if(examid==-1){
		loadExaminationDetail(LecId,'All');
		}else{
		loadExaminationDetailAsPerExam(LecId,examid, 'All');
		}
	}
	if (obj.value == 1) {
	
		if(examid==-1){
		$("#examdetailtbl").html("");
		loadMarkedExam(LecId, 'All');
		}else{
			loadExaminationDetailAsPerExam(LecId,examid, 'marked');
			$("#markStatus").val("1");
		}
	}
	if (obj.value == 0) {
		
		$("#examdetailtbl").html("");
		if(examid==-1){
		loadNotMarkedExam(LecId, 'All');
		}else{
			loadExaminationDetailAsPerExam(LecId,examid, 'not marked');
			$("#markStatus").val("0");
		}
		}
	if (obj.value == -2) {
		$("#examdetailtbl").html("");
		loadPartiallyMarkedExam(LecId, 'All');
	}
}

function loadMarkedExam(lecId, mod) {

	var htmstr = null;
	var status = null;
	var action = null;
	var j = 0;
	var totalCapacity = 0;
	var notMarkcnt = 0;
	var markcnt = 0;
	var cnt = 0;
	$
			.ajax({
				type : "get",
				// url : "lecGetExaminationDetail?LecId="+lecId+"&Mod="+mod,
				// //commented by amit kumar
				url : "eonGetExaminationDetail?LecId=" + lecId + "&Mod=" + mod, 
				cache : false,
				success : function(response) {
					var examCounter = 1;
					var noOfSlot = 1;
					var prevExamId = "";
					var lecCapFlag = "Marked";
					var ecbAllotCapFlag = 1;
					for (var i = 0; i < response.length; i++) {
						totalCapacity = totalCapacity + response[i].eCBAllotCAP
						var k = i + 1;
						if (response[i].lECCAP == 0) {
							lecCapFlag = "Not Marked";
							if (markcnt > 0) {
								lecCapFlag = "Partially Marked";
							}
							notMarkcnt++;
						} else {

							markcnt++;
							if (notMarkcnt > 0) {
								lecCapFlag = "Partially Marked";
							}

						}

						if (response[i].eCBAllotCAP == 0) {
							ecbAllotCapFlag = 0;
						}
						if (i != response.length - 1) {
							prevExamId = response[i + 1].examRegistration.examId;
						}

						if (prevExamId != response[i].examRegistration.examId
								&& prevExamId != "") {
							if (lecCapFlag == "Marked") {
								action = "<a href='#' onclick='assignMarkAvaiblity("
										+ k
										+ ","
										+ response[i].examRegistration.examId
										+ ","
										+ lecId
										+ ")'><span class='glyphicon glyphicon-eye-open opn' aria-hidden='true'></span></a>";
								htmstr = "<tr><td>"
										+ k
										+ "</td><td><label id='nameOfExamination"
										+ k
										+ "'>"
										+ response[i].examRegistration.nameOfExamination
										+ "</label><input type='hidden' id='examId' value="
										+ response[i].examId
										+ "></td><td>"
										+ response[i].fromDate
										+ " To "
										+ response[i].toDate
										+ "</td><td>"
										+ response[i].examRegistration.noOfSlots
										+ "</td><td>" + lecCapFlag
										+ "<input type='hidden' value="
										+ lecCapFlag + " id='status" + k
										+ "'</td><td>" + action + "</td></tr>";

								$("#examdetailtbl").append(htmstr);
							}

							lecCapFlag = "Marked";
							ecbAllotCapFlag = 1;
							markcnt = 0;
							notMarkcnt = 0;

						}
						if (i == response.length - 1) {
							if (lecCapFlag == "Marked") {

								action = "<a href='#' onclick='assignMarkAvaiblity("
										+ k
										+ ","
										+ response[i].examRegistration.examId
										+ ","
										+ lecId
										+ ")'><span class='glyphicon glyphicon-eye-open opn' aria-hidden='true'></span></a>";
								htmstr = "<tr><td>"
										+ k
										+ "</td><td><label id='nameOfExamination"
										+ k
										+ "'>"
										+ response[i].examRegistration.nameOfExamination
										+ "</label><input type='hidden' id='examId' value="
										+ response[i].examId
										+ "></td><td>"
										+ response[i].fromDate
										+ " To "
										+ response[i].toDate
										+ "</td><td>"
										+ response[i].examRegistration.noOfSlots
										+ "</td><td>" + lecCapFlag
										+ "<input type='hidden' value="
										+ lecCapFlag + " id='status" + k
										+ "'</td><td>" + action + "</td></tr>";

								$("#examdetailtbl").append(htmstr);

							}
							lecCapFlag = "Marked";
							ecbAllotCapFlag = 1;
							markcnt = 0;
							notMarkcnt = 0;
						}

					}

				},
				error : function() {
					$.alert.open('Error while load ExaminationDetail');
				}
			});

}

function loadNotMarkedExam(lecId, mod) {

	var htmstr = null;
	var status = null;
	var action = null;
	var j = 0;
	var totalCapacity = 0;
	var notMarkcnt = 0;
	var markcnt = 0;
	var cnt = 0;
	$
			.ajax({
				type : "get",
				// url :
				// "lecGetExaminationDetail?LecId="+lecId+"&Mod="+mod,//commented
				// by amit kumar
				url : "eonGetExaminationDetail?LecId=" + lecId + "&Mod=" + mod,
				cache : false,
				success : function(response) {
					var examCounter = 1;
					var noOfSlot = 1;
					var prevExamId = "";
					var lecCapFlag = "Marked";
					var ecbAllotCapFlag = 1;
					for (var i = 0; i < response.length; i++) {
						totalCapacity = totalCapacity + response[i].eCBAllotCAP
						var k = i + 1;
						if (response[i].lECCAP == 0) {
							lecCapFlag = "Not Marked";
							if (markcnt > 0) {
								lecCapFlag = "Partially Marked";
							}
							notMarkcnt++;
						} else {

							markcnt++;
							if (notMarkcnt > 0) {
								lecCapFlag = "Partially Marked";
							}

						}

						if (response[i].eCBAllotCAP == 0) {
							ecbAllotCapFlag = 0;
						}
						if (i != response.length - 1) {
							prevExamId = response[i + 1].examRegistration.examId;
						}

						if (prevExamId != response[i].examRegistration.examId
								&& prevExamId != "") {
							if (lecCapFlag == "Not Marked") {
								action = "<a href='#' onclick='assignMarkAvaiblity("
										+ k
										+ ","
										+ response[i].examRegistration.examId
										+ ","
										+ lecId
										+ ")'><span class='glyphicon glyphicon-eye-open opn' aria-hidden='true'></span></a>";
								htmstr = "<tr><td>"
										+ k
										+ "</td><td><label id='nameOfExamination"
										+ k
										+ "'>"
										+ response[i].examRegistration.nameOfExamination
										+ "</label><input type='hidden' id='examId' value="
										+ response[i].examId
										+ "></td><td>"
										+ response[i].fromDate
										+ " To "
										+ response[i].toDate
										+ "</td><td>"
										+ response[i].examRegistration.noOfSlots
										+ "</td><td>" + lecCapFlag
										+ "<input type='hidden' value="
										+ lecCapFlag + " id='status" + k
										+ "'</td><td>" + action + "</td></tr>";

								$("#examdetailtbl").append(htmstr);

							}
							lecCapFlag = "Marked";
							ecbAllotCapFlag = 1;
							markcnt = 0;
							notMarkcnt = 0;
						}
						if (i == response.length - 1) {
							if (lecCapFlag == "Not Marked") {

								action = "<a href='#' onclick='assignMarkAvaiblity("
										+ k
										+ ","
										+ response[i].examRegistration.examId
										+ ","
										+ lecId
										+ ")'><span class='glyphicon glyphicon-eye-open opn' aria-hidden='true'></span></a>";
								htmstr = "<tr><td>"
										+ k
										+ "</td><td><label id='nameOfExamination"
										+ k
										+ "'>"
										+ response[i].examRegistration.nameOfExamination
										+ "</label><input type='hidden' id='examId' value="
										+ response[i].examId
										+ "></td><td>"
										+ response[i].fromDate
										+ " To "
										+ response[i].toDate
										+ "</td><td>"
										+ response[i].examRegistration.noOfSlots
										+ "</td><td>" + lecCapFlag
										+ "<input type='hidden' value="
										+ lecCapFlag + " id='status" + k
										+ "'</td><td>" + action + "</td></tr>";

								$("#examdetailtbl").append(htmstr);
							}
							lecCapFlag = "Marked";
							ecbAllotCapFlag = 1;
							markcnt = 0;
							notMarkcnt = 0;

						}

					}

				},
				error : function() {
					$.alert.open('Error while load ExaminationDetail');
				}
			});

}

function loadPartiallyMarkedExam(lecId, mod) {

	var htmstr = null;
	var status = null;
	var action = null;
	var j = 0;
	var totalCapacity = 0;
	var notMarkcnt = 0;
	var markcnt = 0;
	var cnt = 0;
	$
			.ajax({
				type : "get",
				// url :
				// "lecGetExaminationDetail?LecId="+lecId+"&Mod="+mod,//commented
				// by amit kumar
				url : "eonGetExaminationDetail?LecId=" + lecId + "&Mod=" + mod,
				cache : false,
				success : function(response) {
					var examCounter = 1;
					var noOfSlot = 1;
					var prevExamId = "";
					var lecCapFlag = "Marked";
					var ecbAllotCapFlag = 1;
					for (var i = 0; i < response.length; i++) {
						totalCapacity = totalCapacity + response[i].eCBAllotCAP
						var k = i + 1;
						if (response[i].lECCAP == 0) {
							lecCapFlag = "Not Marked";
							if (markcnt > 0) {
								lecCapFlag = "Partially Marked";
							}
							notMarkcnt++;
						} else {

							markcnt++;
							if (notMarkcnt > 0) {
								lecCapFlag = "Partially Marked";
							}

						}

						if (response[i].eCBAllotCAP == 0) {
							ecbAllotCapFlag = 0;
						}
						if (i != response.length - 1) {
							prevExamId = response[i + 1].examRegistration.examId;
						}

						if (prevExamId != response[i].examRegistration.examId
								&& prevExamId != "") {
							if (lecCapFlag == "Partially Marked") {
								action = "<a href='#' onclick='assignMarkAvaiblity("
										+ k
										+ ","
										+ response[i].examRegistration.examId
										+ ","
										+ lecId
										+ ")'><span class='glyphicon glyphicon-eye-open opn' aria-hidden='true'></span></a>";
								htmstr = "<tr><td>"
										+ k
										+ "</td><td><label id='nameOfExamination"
										+ k
										+ "'>"
										+ response[i].examRegistration.nameOfExamination
										+ "</label><input type='hidden' id='examId' value="
										+ response[i].examId
										+ "></td><td>"
										+ response[i].fromDate
										+ " To "
										+ response[i].toDate
										+ "</td><td>"
										+ response[i].examRegistration.noOfSlots
										+ "</td><td>" + lecCapFlag
										+ "<input type='hidden' value="
										+ lecCapFlag + " id='status" + k
										+ "'</td><td>" + action + "</td></tr>";

								$("#examdetailtbl").append(htmstr);
							}
							lecCapFlag = "Marked";
							ecbAllotCapFlag = 1;
							markcnt = 0;
							notMarkcnt = 0;
						}
						if (i == response.length - 1) {
							if (lecCapFlag == "Partially Marked") {

								action = "<a href='#' onclick='assignMarkAvaiblity("
										+ k
										+ ","
										+ response[i].examRegistration.examId
										+ ","
										+ lecId
										+ ")'><span class='glyphicon glyphicon-eye-open opn' aria-hidden='true'></span></a>";
								htmstr = "<tr><td>"
										+ k
										+ "</td><td><label id='nameOfExamination"
										+ k
										+ "'>"
										+ response[i].examRegistration.nameOfExamination
										+ "</label><input type='hidden' id='examId' value="
										+ response[i].examId
										+ "></td><td>"
										+ response[i].fromDate
										+ " To "
										+ response[i].toDate
										+ "</td><td>"
										+ response[i].examRegistration.noOfSlots
										+ "</td><td>" + lecCapFlag
										+ "<input type='hidden' value="
										+ lecCapFlag + " id='status" + k
										+ "'</td><td>" + action + "</td></tr>";

								$("#examdetailtbl").append(htmstr);
							}
							lecCapFlag = "Marked";
							ecbAllotCapFlag = 1;
							markcnt = 0;
							notMarkcnt = 0;

						}

					}

				},
				error : function() {
					$.alert.open('Error while load ExaminationDetail');
				}
			});

}

function loadExam(lecId){
	var mod="All";
	var htmlStrr="<option value=-1>All</option>";
	$
	.ajax({
		type : "get",
		url : "eonGetExaminationDetail?LecId=" + lecId + "&Mod="+mod ,
		cache : false,
		success : function(response) {
			for (var i = 0; i < response.length; i++) {
	var examNo=0;
	if(i<(response.length-1)){
		examNo=response[i+1].examRegistration.examId;
	}

	if(response[i].examRegistration.examId!=examNo){
		
	htmlStrr += "<option value="
			+ response[i].examRegistration.examId
			+ ">"
			+ response[i].examRegistration.nameOfExamination
			+ "</option>";
	}
			}
	$("#markExam").html(htmlStrr);
		},
		error : function() {
			$.alert.open('Error while loadExam');
		}
	});
	}
function loadExaminationDetail(lecId, mod) {

	var htmstr = null;
	var status = null;
	var action = null;
	var j = 0;
	var totalCapacity = 0;
	var notMarkcnt = 0;
	var markcnt = 0;
	var cnt = 0;
	$
			.ajax({
				type : "get",
				// url :
				// "lecGetExaminationDetail?LecId="+lecId+"&Mod="+mod,//commented
				// by amit kumar
				url : "eonGetExaminationDetail?LecId=" + lecId + "&Mod=" + mod,
				cache : false,
				success : function(response) {
					var examCounter = 1;
					var noOfSlot = 1;
					var prevExamId = "";
					var lecCapFlag = "Marked";
					var ecbAllotCapFlag = 1;
					var k = 0;
					var htmlStrr = "<option value='-1'>All</option>";
					for (var i = 0; i < response.length; i++) {
						totalCapacity = totalCapacity + response[i].eCBAllotCAP

						if (response[i].lECCAP == 0) {
							lecCapFlag = "Not Marked";
							if (markcnt > 0) {
								lecCapFlag = "Partially Marked";
							}
							notMarkcnt++;
						} else {

							markcnt++;
							if (notMarkcnt > 0) {
								lecCapFlag = "Partially Marked";
							}

						}

						if (response[i].eCBAllotCAP == 0) {
							ecbAllotCapFlag = 0;
						}
						if (i != response.length - 1) {
							prevExamId = response[i + 1].examRegistration.examId;
						}

						if (prevExamId != response[i].examRegistration.examId
								&& prevExamId != "") {
							k++;

							if (lecCapFlag == "Not Marked") {

								action = "<a href='#' onclick='assignMarkAvaiblity("
										+ k
										+ ","
										+ response[i].examRegistration.examId
										+ ","
										+ lecId
										+ ")'><span class='glyphicon glyphicon-eye-open opn' aria-hidden='true'></span></a>";
								htmstr = "<tr><td>"
										+ k
										+ "</td><td><label id='nameOfExamination"
										+ k
										+ "'>"
										+ response[i].examRegistration.nameOfExamination
										+ "</label><input type='hidden' id='examId' value="
										+ response[i].examId
										+ "></td><td>"
										+ response[i].fromDate
										+ " to "
										+ response[i].toDate
										+ "</td><td>"
										+ response[i].examRegistration.noOfSlots
										+ "</td><td>" + lecCapFlag
										+ "<input type='hidden' value="
										+ lecCapFlag + " id='status" + k
										+ "'</td><td>" + action + "</td></tr>";
							} else {

								action = "<a href='#' onclick='assignMarkAvaiblity("
										+ k
										+ ","
										+ response[i].examRegistration.examId
										+ ","
										+ lecId
										+ ")'><span class='glyphicon glyphicon-eye-open opn' aria-hidden='true'></span></a>";
								htmstr = "<tr><td>"
										+ k
										+ "</td><td><label id='nameOfExamination"
										+ k
										+ "'>"
										+ response[i].examRegistration.nameOfExamination
										+ "</label><input type='hidden' id='examId' value="
										+ response[i].examId
										+ "></td><td>"
										+ response[i].fromDate
										+ " To "
										+ response[i].toDate
										+ "</td><td>"
										+ response[i].examRegistration.noOfSlots
										+ "</td><td>" + lecCapFlag
										+ "<input type='hidden' value="
										+ lecCapFlag + " id='status" + k
										+ "'</td><td>" + action + "</td></tr>";
							}

							$("#examdetailtbl").append(htmstr);
							lecCapFlag = "Marked";
							ecbAllotCapFlag = 1;
							markcnt = 0;
							notMarkcnt = 0;
						}
						if (i == response.length - 1) {
							k++;
							if (lecCapFlag == "Not Marked") {

								action = "<a href='#' onclick='assignMarkAvaiblity("
										+ k
										+ ","
										+ response[i].examRegistration.examId
										+ ","
										+ lecId
										+ ")'><span class='glyphicon glyphicon-eye-open opn' aria-hidden='true'></span></a>";
								htmstr = "<tr><td>"
										+ k
										+ "</td><td><label id='nameOfExamination"
										+ k
										+ "'>"
										+ response[i].examRegistration.nameOfExamination
										+ "</label><input type='hidden' id='examId' value="
										+ response[i].examId
										+ "></td><td>"
										+ response[i].fromDate
										+ " to "
										+ response[i].toDate
										+ "</td><td>"
										+ response[i].examRegistration.noOfSlots
										+ "</td><td>" + lecCapFlag
										+ "<input type='hidden' value="
										+ lecCapFlag + " id='status" + k
										+ "'</td><td>" + action + "</td></tr>";
							} else {

								action = "<a href='#' onclick='assignMarkAvaiblity("
										+ k
										+ ","
										+ response[i].examRegistration.examId
										+ ","
										+ lecId
										+ ")'><span class='glyphicon glyphicon-eye-open opn' aria-hidden='true'></span></a>";
								htmstr = "<tr><td>"
										+ k
										+ "</td><td><label id='nameOfExamination"
										+ k
										+ "'>"
										+ response[i].examRegistration.nameOfExamination
										+ "</label><input type='hidden' id='examId' value="
										+ response[i].examId
										+ "></td><td>"
										+ response[i].fromDate
										+ " To "
										+ response[i].toDate
										+ "</td><td>"
										+ response[i].examRegistration.noOfSlots
										+ "</td><td>" + lecCapFlag
										+ "<input type='hidden' value="
										+ lecCapFlag + " id='status" + k
										+ "'</td><td>" + action + "</td></tr>";
							}

							$("#examdetailtbl").append(htmstr);
							lecCapFlag = "Marked";
							ecbAllotCapFlag = 1;
							markcnt = 0;
							notMarkcnt = 0;

						}

					}
					
				},
				error : function() {
					$.alert.open('Error while load ExaminationDetail');
				}
			});
}
/*function loadExaminationDetailAsPerExam(lecId,examid, mod) {
	$.alert.open("hiiiiiiiiiiiiiiiii"+lecId+"=="+examid.value);
	var htmstr = null;
	var status = null;
	var action = null;
	var j = 0;
	var totalCapacity = 0;
	var notMarkcnt = 0;
	var markcnt = 0;
	var cnt = 0;
	$
			.ajax({
				type : "get",
				url : "eonGetExaminationDetailAsPerExam?LecId=" + lecId + "&Mod=" + mod+"&examId="+examid.value,
				cache : false,
				success : function(response) {
				$.alert.open("helo"+response.length);
				},
				error : function() {
					$.alert.open('Error while load ExaminationDetail');
				}
			});	
	}*/
function loadExaminationDetailAsPerExam(lecId,examid, mod) {
	$("#examdetailtbl").html("");
	$("#markStatus").val("-1");
	if(examid==-1){
		loadExaminationDetail(lecId,'All');
	}
	else
	$("#examdetailtbl").html("");
	var htmstr = null;
	var status = null;
	var action = null;
	var j = 0;
	var totalCapacity = 0;
	var notMarkcnt = 0;
	var markcnt = 0;
	var cnt = 0;
	$
			.ajax({
				type : "get",
				url : "eonGetExaminationDetailAsPerExam?LecId=" + lecId + "&Mod=" + mod+"&examId="+examid,
				cache : false,
				success : function(response) {
					var examCounter = 1;
					var noOfSlot = 1;
					var prevExamId = "";
					var lecCapFlag = "Marked";
					var ecbAllotCapFlag = 1;
					var k = 0;
					var htmlStrr = "<option value='-1'>All</option>";
					for (var i = 0; i < response.length; i++) {

						totalCapacity = totalCapacity + response[i].eCBAllotCAP

						if (response[i].lECCAP == 0) {
							lecCapFlag = "Not Marked";
							if (markcnt > 0) {
								lecCapFlag = "Partially Marked";
							}
							notMarkcnt++;
						} else {

							markcnt++;
							if (notMarkcnt > 0) {
								lecCapFlag = "Partially Marked";
							}

						}

						if (response[i].eCBAllotCAP == 0) {
							ecbAllotCapFlag = 0;
						}
						if (i != response.length - 1) {
							prevExamId = response[i + 1].examRegistration.examId;
						}

						if (prevExamId != response[i].examRegistration.examId
								&& prevExamId != "") {
							k++;

							if (lecCapFlag == "Not Marked") {

								action = "<a href='#' onclick='assignMarkAvaiblity("
										+ k
										+ ","
										+ response[i].examRegistration.examId
										+ ","
										+ lecId
										+ ")'><span class='glyphicon glyphicon-eye-open opn' aria-hidden='true'></span></a>";
								htmstr = "<tr><td>"
										+ k
										+ "</td><td><label id='nameOfExamination"
										+ k
										+ "'>"
										+ response[i].examRegistration.nameOfExamination
										+ "</label><input type='hidden' id='examId' value="
										+ response[i].examId
										+ "></td><td>"
										+ response[i].fromDate
										+ " to "
										+ response[i].toDate
										+ "</td><td>"
										+ response[i].examRegistration.noOfSlots
										+ "</td><td>" + lecCapFlag
										+ "<input type='hidden' value="
										+ lecCapFlag + " id='status" + k
										+ "'</td><td>" + action + "</td></tr>";
							} else {

								action = "<a href='#' onclick='assignMarkAvaiblity("
										+ k
										+ ","
										+ response[i].examRegistration.examId
										+ ","
										+ lecId
										+ ")'><span class='glyphicon glyphicon-eye-open opn' aria-hidden='true'></span></a>";
								htmstr = "<tr><td>"
										+ k
										+ "</td><td><label id='nameOfExamination"
										+ k
										+ "'>"
										+ response[i].examRegistration.nameOfExamination
										+ "</label><input type='hidden' id='examId' value="
										+ response[i].examId
										+ "></td><td>"
										+ response[i].fromDate
										+ " To "
										+ response[i].toDate
										+ "</td><td>"
										+ response[i].examRegistration.noOfSlots
										+ "</td><td>" + lecCapFlag
										+ "<input type='hidden' value="
										+ lecCapFlag + " id='status" + k
										+ "'</td><td>" + action + "</td></tr>";
							}

							$("#examdetailtbl").append(htmstr);
							lecCapFlag = "Marked";
							ecbAllotCapFlag = 1;
							markcnt = 0;
							notMarkcnt = 0;
						}
						if (i == response.length - 1) {
							k++;
							if (lecCapFlag == "Not Marked") {

								action = "<a href='#' onclick='assignMarkAvaiblity("
										+ k
										+ ","
										+ response[i].examRegistration.examId
										+ ","
										+ lecId
										+ ")'><span class='glyphicon glyphicon-eye-open opn' aria-hidden='true'></span></a>";
								htmstr = "<tr><td>"
										+ k
										+ "</td><td><label id='nameOfExamination"
										+ k
										+ "'>"
										+ response[i].examRegistration.nameOfExamination
										+ "</label><input type='hidden' id='examId' value="
										+ response[i].examId
										+ "></td><td>"
										+ response[i].fromDate
										+ " to "
										+ response[i].toDate
										+ "</td><td>"
										+ response[i].examRegistration.noOfSlots
										+ "</td><td>" + lecCapFlag
										+ "<input type='hidden' value="
										+ lecCapFlag + " id='status" + k
										+ "'</td><td>" + action + "</td></tr>";
							} else {

								action = "<a href='#' onclick='assignMarkAvaiblity("
										+ k
										+ ","
										+ response[i].examRegistration.examId
										+ ","
										+ lecId
										+ ")'><span class='glyphicon glyphicon-eye-open opn' aria-hidden='true'></span></a>";
								htmstr = "<tr><td>"
										+ k
										+ "</td><td><label id='nameOfExamination"
										+ k
										+ "'>"
										+ response[i].examRegistration.nameOfExamination
										+ "</label><input type='hidden' id='examId' value="
										+ response[i].examId
										+ "></td><td>"
										+ response[i].fromDate
										+ " To "
										+ response[i].toDate
										+ "</td><td>"
										+ response[i].examRegistration.noOfSlots
										+ "</td><td>" + lecCapFlag
										+ "<input type='hidden' value="
										+ lecCapFlag + " id='status" + k
										+ "'</td><td>" + action + "</td></tr>";
							}

							$("#examdetailtbl").append(htmstr);
							lecCapFlag = "Marked";
							ecbAllotCapFlag = 1;
							markcnt = 0;
							notMarkcnt = 0;

						}

					}
					
				},
				error : function() {
					$.alert.open('Error while load ExaminationDetail');
				}
			});
}
/*
 * 
 */
function loadExaminationDetailById(examId, lecId) {
	
	var flagSave = 0;
	var htmstr = null;
	var status = null;
	var action = null;
	var j = 0;
	var allotcapacity=0;
	$
			.ajax({
				type : "get",
				url : "eonGetExaminationDetailById?ExamId=" + examId + "&LecId="
						+ lecId,
				cache : false,
				success : function(response) {
					$("#examSlotTbl").html("");
					for (var i = 0; i < response.length; i++) {
						gridLength = response.length;
						var k = i + 1;
						$("#Examination").text(
								response[i].examRegistration.nameOfExamination);
						$("#DateOfExam").text(
								response[i].fromDate + "To"
										+ response[i].toDate);
						$("#NumberOfSlots").text(
								response[i].examRegistration.noOfSlots);
						// for(j=0;j<response[i].examRegistration.noOfSlots;j++){
						var k = i + 1;
						var slotVal = response[i].lECCAP;
						var isEcbAllot=response[i].isECBAllot;
						if(isEcbAllot==1){
							allotcapacity=response[i].eCBAllotCAP;
						}
							
						
						if (response[i].isCapAssign == 0) {

							htmstr = "<tr><td>"
									+ response[i].examRegistration.startDate
									+ "<input type='hidden' name='isCapAssign' id='isAssignCap"
									+ k
									+ "' value="
									+ response[i].isCapAssign
									+ "></td><td><input type='text' size='5' name=totalCap id=totalCap readonly value='"
									+ response[0].totalUsableComputers
									+ "'></td><td>Slot"
									+ k
									+ "</td><td>"
									+ response[i].fromTime
									+ " To "
									+ response[i].toTime
									+ "</td> <td><input maxlength=4 onkeypress='return validateData(event,5)' type='text' class='form-control' name='lECCAP' id='slottxt"
									+ k
									+ "' value="
									+ slotVal
									+ " style='width: 90px;'><input type='hidden' name='lECSLOTID' id='lecslotId"
									+ k + "' value=" + response[i].lECSLOTID
									+ "></td><td>"
									+ allotcapacity
									+ "</td></tr>";

						} else {
							htmstr = "<tr><td>"
									+ response[i].examRegistration.startDate
									+ "<input type='hidden' name='isCapAssign' id='isAssignCap"
									+ k
									+ "' value="
									+ response[i].isCapAssign
									+ "></td><td><input type='text' size='5' name=totalCap id=totalCap readonly value='"
									+ response[0].totalUsableComputers
									+ "'></td><td>Slot"
									+ k
									+ "</td> <td>"
									+ response[i].fromTime
									+ " To "
									+ response[i].toTime
									+ "</td><td><input maxlength=4 onkeypress='return validateData(event,5)'  type='text' class='form-control' name='lECCAP' id='slottxt"
									+ k
									+ "'  style='width: 90px;' value="
									+ slotVal
									+ " readonly><input type='hidden' name='lECSLOTID' id='lecslotId"
									+ k
									+ "' value="
									+ response[i].lECSLOTID
									+ "></td><td>"
									+ allotcapacity
									+ "</td></tr>";

						}

						$("#examSlotTbl").append(htmstr);

						if (response[i].isCapAssign == 0 && flagSave == 0) {
							flagSave++;
							// $("#examSlotTbl").append("<tr><td
							// colspan='5'><button type='button' class='btn
							// btn-primary pull-right' id='cnfrmBtn'
							// onclick='onConfirm()'>Save</button></td></tr>");
						}

					}
					if (flagSave > 0) {
						$("#examSlotTbl")
								.append(
										"<tr><td colspan='6'><button type='button' class='btn btn-primary pull-right' id='cnfrmBtn' onclick='onConfirm()'>Save</button></td></tr>");
					}
					
				},
				error : function() {
					$.alert.open('Error while load ExaminationDetailById');
				}
			});
}
function changeCheckBoxValue(obj, CBId, TxtId) {
}
function assignMarkAvaiblity(srn, examId, lecId) {

	loadExaminationDetailById(examId, lecId);
	$("#myModal").modal('show');
}
function onConfirm() {
	if (!validateAssignCap()) {
		return false;
	}
	if (confirm("Are you sure? You want to save this")) {
		var htmlStr = "<option value=-1>All</option>";
		var frm = $("#slotInfofrm");
		$.ajax({
			type : frm.attr('method'),
			url : frm.attr('action'),
			data : frm.serialize(),
			success : function(response) {
				$("#examdetailtbl").html("");
				$("#close").click();
				$("#markStatus").val(-1);
				loadExaminationDetail(LecId, 'All');
				loadExam(LecId);

			},
			error : function() {
				$.alert.open('Error while assigning the value');
			}
		});
	}
}
function onPublish() {
	if (!validateAssignCap()) {
		return false;
	}
	var notMark = 0;
	var parMark = 0;
	for (var i = 1; i <= gridLength; i++) {
		var assignCap = "isAssignCap" + i;
		var slotCap = "slottxt" + i;
		$("#" + assignCap).val('1');

		if ($("#" + slotCap).val() == "" || $("#" + slotCap).val() == 0) {
			notMark++;
		} else {

			parMark++;
		}
	}
	if (parMark > 0 && notMark > 0) {
		if (confirm("You are trying to publish the PARTIALLY MARKED slot,Are you Sure? You want to publish it.After publish, you are not allowed to change the filled capacity")) {
			var htmlStr = "<option value=-1>All</option>";
			var frm = $("#slotInfofrm");
			/*
			 * for(var i=1;i<=gridLength;i++){ var assignCap="isAssignCap"+i;
			 * $("#"+assignCap).val('1'); }
			 */
			// $("#isAssignCap").val('1');
			$.ajax({
				type : frm.attr('method'),
				url : frm.attr('action'),
				data : frm.serialize(),
				success : function(response) {

					$("#examdetailtbl").html("");
					$("#close").click();
					$("#markStatus").val(-1);
					loadExaminationDetail(LecId, 'All');

				},
				error : function() {
					$.alert.open('Error while assigning the value');
				}
			});
		}
	} else {

		if (confirm("Are you sure to publish it? After publish, you are not allowed to change the capacity")) {
			var htmlStr = "<option value=-1>All</option>";
			var frm = $("#slotInfofrm");
			/*
			 * for(var i=1;i<=gridLength;i++){ var assignCap="isAssignCap"+i;
			 * $("#"+assignCap).val('1'); }
			 */
			// $("#isAssignCap").val('1');
			$.ajax({
				type : frm.attr('method'),
				url : frm.attr('action'),
				data : frm.serialize(),
				success : function(response) {

					$("#examdetailtbl").html("");
					$("#close").click();
					$("#markStatus").val(-1);
					loadExaminationDetail(LecId, 'All');

				},
				error : function() {
					$.alert.open('Error while assigning the value');
				}
			});
		}

	}
}
function validateAssignCap() {
	var totalCap = document.getElementsByName("totalCap");
	var lECCAP = document.getElementsByName("lECCAP");

	for (var i = 0; i < totalCap.length; i++) {
		if (parseInt(totalCap[i].value) < parseInt(lECCAP[i].value)) {
			$.alert.open("Assign Capacity cannot greater then Total Capcity.");
			return false;
		}
	}

	return true;
}

