/*// start for next tab
$(document).ready(function() {
    $('.nexttab').click(function(){
  $('.nav-tabs > .active').next('li').find('a').trigger('click');
});
});*/

var districtId = "" ;
var stateId = "";
var cityId = "";
$(document).ready(function() {
	$('.ss li').not('.active').addClass('disabled');
    $('.ss li').not('.active').find('a').removeAttr("data-toggle");
  /*  $('.bt').click(function(){
        enable next tab
        $('.nav li.active').next('li').removeClass('disabled');
        $('.nav li.active').next('li').find('a').attr("data-toggle","tab")
        $('.nav-tabs > .active').next('li').find('a').trigger('click');

    });*/
});
$(document).ready(function() {
    $('#moudate').datepicker({
            format: 'yyyy-mm-dd',
            todayHighlight: true,
            autoclose: true,
            endDate: '+0d',
        });
    $('#mouenddate').datepicker({
        format: 'yyyy-mm-dd',
        todayHighlight: true,
        autoclose: true,
        startDate: '+0d',
    });
    $('#incepectiondate').datepicker({
        format: 'yyyy-mm-dd',
        todayHighlight: true,
        autoclose: true,
        endDate: '+0d',
    });
});

//this method is used for set the of check box true when checke box selected and vice versa
function changeCheckboxVal(obj,uncheckVal,checkVal)
{
	if(obj.checked==true)
		{
		obj.value=checkVal;
		}
	else
		{
		obj.value=uncheckVal;
		}
}


function loadCountry() {
	blockU();
	var htmlStr="<option value=-1>Select</option>";
	$
	.ajax({
		type : "get",
		url : "eonlecGetCountry",
		
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr+="<option value="+response[i].countryId+">"+response[i].countryName+"</option>";
			}
			$('#country').html(htmlStr);
			if($("#centreId").val()!=""){
				
				loadLecForEdit1($("#centreId").val());
			}
// 			$('#searchState').html(htmlStr);
		
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load Country');
		}
	});
}
/*
* This function is call the controller  " lecGetState" and 
* Get the no of State and
* Set all the states in the dropDown 
*/
function loadState(obj) {
	blockU();
	var htmlStr="<option value=-1>Select</option>";
	$
	.ajax({
		type : "get",
		url : "eonlecGetStateRegistration?countryID="+obj.value,
		
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr+="<option value="+response[i].stateId+">"+response[i].stateName+"</option>";
			}
			
			$('#state').html(htmlStr);
			
			if(stateId!="")
				{
				
					document.form1.state.value=stateId;
					loadDistrict(stateId);
					loadCity(document.form1.state);
				}
			
//			$('#searchState').html(htmlStr);
			
			
		
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load State');
		}
	});
}


function loadStateEdit() {
	blockU();
	var htmlStr="<option value=-1>All</option>";
	$
	.ajax({
		type : "get",
		url : "eonlecGetStateRegistration?countryID=1",
		
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr+="<option value="+response[i].stateId+">"+response[i].stateName+"</option>";
			}
			
			$('#state').html(htmlStr);
			$('#searchState').html(htmlStr);
			
			
		
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load State, please reload the page again');
		}
	});
}


function loadEonEcbRegistration() {
	blockU();
	var htmlStr="<option value=-1>Select</option>";
	$
	.ajax({
		type : "get",
		url : "eonlecgetEonEcbRegistrationdropdown",
		
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr+="<option value="+response[i].ecbId+">"+response[i].ecbName+"</option>";
			}
			$('#ecbname').html(htmlStr);
// 			$('#searchState').html(htmlStr);
		
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load Country');
		}
	});
}







/*
* This function is call the controller  " lecGetCity" and 
* Get the no of City and
* Set all the City in the dropDown
*/
function loadCity(obj) {
	blockU();
	var htmlStr="<option value=-1>Select</option>";
	$
	.ajax({
		type : "get",
		url : "eonlecGetCityRegistration?stateId="+obj.value,
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr+="<option value="+response[i].cityId+">"+response[i].cityName+"</option>";
			}
			
			$('#city').html(htmlStr);
			document.form1.city.value=cityId;
		//	$('#cityComp').html(htmlStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load city');
		}
	});
}


function loadCityList(obj) {
	blockU();
	var htmlStr="<option value=-1>All</option>";
	$
	.ajax({
		type : "get",
		url : "eonlecGetCityRegistration?stateId="+obj.value,
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr+="<option value="+response[i].cityId+">"+response[i].cityName+"</option>";
			}
			
			$('#city').html(htmlStr);
			if(cityId!="")
				{
					document.form1.city.value=cityId;
				}
		//	$('#cityComp').html(htmlStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load city');
		}
	});
}


function loadDistrict(val) {
	blockU();
	var htmlStr="<option value=-1>Select</option>";
	$
	.ajax({
		type : "get",
		url : "eonlecgetDistrict?stateId="+val,
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
			//	$.alert.open(response[i].distId);
				//$.alert.open(response[i].districtName);
				htmlStr+="<option value="+response[i].distId+">"+response[i].districtName+"</option>";
			}
			
			$('#district').html(htmlStr);
			$('#districtComp').html(htmlStr);
			document.form1.district.value = districtId;
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load District');
		}
	});
}



function toSave()
{
	
			var checkArray=["name","headName","headEmailID"];
			var msgArray =["Please enter lec name.","Please enter head name.","Please enter email id"];
			
		if(validateFields(checkArray, 0 , msgArray) && confirm("Are you sure, you are going to save."))
		{	
			document.form1.submit();
		}
}



function toFirstTabSave(){
	blockU();
	$("#lecName").text("");
	var checkArray=["name","pin","country","state","city","totalComputers"];
	var msgArray =["Please enter lec name.","Please enter Pin","Please select country","Please select state","Please select city","Please enter no of computers"];
	
if(validateFields(checkArray, 0 , msgArray))
{	
	$("#lecName").text($("#name").val());
  var frm=$("#frm");
  $.ajax({
	        type: frm.attr('method'),
	        url: frm.attr('action'),
	        data: frm.serialize(),
	        success: function (response) {
	        	unblockU("");
	        $("#centreId").val(response);
	        },
			error : function() {
				unblockU("");
				$.alert.open('Error while assigning the value');
			}
	    });
// $('.nav-tabs > .active').next('li').find('a').trigger('click');
// 	$('.b').removeAttr('data-toggle');
  $('.ss li.active').next('li').removeClass('disabled');
  $('.ss li.active').next('li').find('a').attr("data-toggle","tab")
  $('.nav-tabs > .active').next('li').find('a').trigger('click');
 
}
}

/*$( document ).ready(function() {
	$('.b').on('click', function(){
	    var checkArray=["name","pin","totalComputers"];
		var msgArray =["Please enter lec name.","Please enter Pin","Please enter no of computers"];
		
	if(validateFields(checkArray, 0 , msgArray)){		
//		   $('.b').removeClass('active');
		    $('.a').addClass('active');
	 
	}else{

	}
	});
});*/

function toBack(){
	$('.nav-tabs > .active').prev('li').find('a').trigger('click');	
}



function toSecondTabSave(){
	blockU();
//	$("#lecName").text($("#name").val());
	var checkArray=["headName","headMobile","headPhone","headEmailID","cordinator","cordinatorMobile","cordinatorPhone","cordinatorEmail"];
	var msgArray =["Please enter head name.","Please enter head Mobile","Please enter head Phone","Please enter head EmailID","Please enter cordinator name","Please enter cordinator Mobile","Please enter cordinator Phone","Please enter cordinator Email"];
	
if(validateFields(checkArray, 0 , msgArray))
{
	var frm=$("#frm");
	  $.ajax({
		        type: frm.attr('method'),
		        url: frm.attr('action'),
		        data: frm.serialize(),
		        success: function (response) {
		        unblockU("");
		        $("#centreId").val(response);
		        },
				error : function() {
					unblockU("");
					$.alert.open('Error while assigning the value');
				}
		    });
// $('.nav-tabs > .active').next('li').find('a').trigger('click');
	  $('.ss li.active').next('li').removeClass('disabled');
	     $('.ss li.active').next('li').find('a').attr("data-toggle","tab")
	     $('.nav-tabs > .active').next('li').find('a').trigger('click');
}
}


function toThirdTabSave(){
	blockU();
	var checkArray=["noOfBuilding","noOfLabs","totalUsableComputers"];
	var msgArray =["Please enter number of building.","Please enter noOfLabs","Please enter totalUsableComputers"];
	
if(validateFields(checkArray, 0 , msgArray))
{	
	var frm=$("#frm");
	  $.ajax({
		        type: frm.attr('method'),
		        url: frm.attr('action'),
		        data: frm.serialize(),
		        success: function (response) {
		        unblockU("");
		        $("#centreId").val(response);
		        },
				error : function() {
					unblockU("");
					$.alert.open('Error while assigning the value');
				}
		    });
// $('.nav-tabs > .active').next('li').find('a').trigger('click');
	  $('.ss li.active').next('li').removeClass('disabled');
	     $('.ss li.active').next('li').find('a').attr("data-toggle","tab")
	     $('.nav-tabs > .active').next('li').find('a').trigger('click');
}
}

function loadInfra(){
	
	$("#stateId").val($("#state").val());
	$("#cityName").val($("#city option:selected").text());
	$("#cityId").val($("#city").val());
	$("#centerIdInfra").val($("#centreId").val())
	return true;
}

function checkcomputer(){
	var noOfComp= document.form1.totalComputers.value;
	var useablecomp = document.form1.totalUsableComputers.value;
	if(parseInt(noOfComp) >= parseInt(useablecomp)){
		return true;
	}
	else{
		$.alert.open("Usable Computer can't greater than No Of Computer.")
		document.form1.totalUsableComputers.value="";
		return false;
	}
}


// function is_valid_url(url) {
//     return /^(http(s)?:\/\/)?(www\.)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/.test(url);
// }

function validateWebsiteUrl(googleUrl)
{
if(/^(http(s)?:\/\/)?(www\.)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/.test(googleUrl.value)){
	}
else if(/^(HTTP(S)?:\/\/)?(WWW\.)?[A-Z0-9]+([\-\.]{1}[A-Z0-9]+)*\.[A-Z]{2,5}(:[0-9]{1,5})?(\/.*)?$/.test(googleUrl.value)){
}

else{
		$.alert.open("Invalid Website");
	    myUrl.focus();
	}
}


function checkDuplicateName(obj){
	blockU();
	if(document.form1.name.value=="" || document.form1.tempLecName.value==obj.value)
		{
		 return false;
		}
	$
	.ajax({
		type : "get",
		url : "eonleccheckDuplicateLec?name="+obj.value,
		cache : false,
		success : function(response) {
			unblockU("");
			if(response==-1){
			}
			else{
				$.alert.open("LEC Name exists");
				$('#name').val("");
			}
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while request..');
		}
	});
	
}


function checkDuplicateGoogleUrl(obj){
	blockU();
	if(document.form1.googleUrl.value=="" || document.form1.tempgoogleURL.value==obj.value)
	{
		 return false;
	}
	$
	.ajax({
		type : "get",
		url : "eonleccheckDuplicateGoogleUrl?googleUrl="+obj.value,
		cache : false,
		success : function(response) {
			unblockU("");
		if(response==-1){
			}
			else{
				
				$.alert.open("Google URL exists");
				$('#googleUrl').val("");
			}
			
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while request..');
		}
	});
	
}


// function checkCheckedValue(obj){
// 	if(obj.value==1){
// 		return True;	
// 	}else{
// 		return False;
// 	}
// }


function showPreview()
{

	 /* 	  var data = $("#frm").serialize();
	   var arr=data.split("&");
	 var strHtml="";
	 for(var i=0;i<arr.length;i++)
		 {
		var  obj = document.form1.elements[arr[i].split("=")[0]];
			type = obj.type;
			if(type=="select-one")
				{
				
				strHtml+="<tr><td>"+arr[i].split("=")[0]+":"+$("#"+arr[i].split("=")[0]+" option:selected").text()+"</td></tr>";
				
				}
			else
				{
				
				 strHtml+="<tr><td>"+arr[i].split("=")[0]+":"+arr[i].split("=")[1]+"</td></tr>";
				 
				}
		
		 
		 } 
	 */
		
		 
		
	 var strHtml="";
  strHtml +="<tr><td><h3>General </h3></td><td></td><td></td><td></td> </tr>"
	      +"<tr><td>LEC Name:</td><td>"+document.form1.name.value+"</td><td>Center ID</td><td>"+document.form1.centreId.value+"</td> </tr>"
		  +"<tr><td>Address 1:</td><td>"+document.form1.address1.value+"</td><td>Country</td><td>"+$("#country option:selected").text()+"</td> </tr>"
		  +"<tr><td>City :</td><td>"+$("#city option:selected").text()+"</td><td>State</td><td>"+$("#state option:selected").text()+"</td> </tr>"
		  +"<tr><td>Landmark :</td><td>"+document.form1.landMark.value+"</td><td>District </td><td>"+$("#district option:selected").text()+"</td> </tr>"
		  
		  +"<tr><td>Google URL:</td><td>"+document.form1.googleUrl.value+"</td><td>Pin </td><td>"+document.form1.pin.value+"</td> </tr>"
		  +"<tr><td>Nearest Railway Station:</td><td>"+document.form1.nearestRailwayStation.value+"</td><td>Distance</td><td>"+document.form1.distanceFromRailwayStation.value+"</td> </tr>"
		  +"<tr><td>Nearest Airport :</td><td>"+document.form1.nearestAirport.value+"</td><td>District</td><td>"+document.form1.distanceFromAirport.value+"</td> </tr>"
		  +"<tr><td>Nearest Bus Stop:</td><td>"+document.form1.nearestBusStop.value+"</td><td>Distance</td><td>"+document.form1.distanceFromBusStop.value+"</td> </tr>"
		  +"<tr><td>Nearest Metro:</td><td>"+document.form1.nearestMetro.value+"</td><td>Distance</td><td>"+document.form1.distanceFromMetro.value+"</td> </tr>"
		  +"<tr><td>Nearest Police Station:</td><td>"+document.form1.nearestPoliceStation.value+"</td><td>Distance</td><td>"+document.form1.distanceFromPoliceStation.value+"</td> </tr>"
		  +"<tr><td>Police Station Contact No:</td><td>"+document.form1.phoneNoPS.value+"</td><td></td><td></td> </tr>"
		  
		  +"<tr><td><h3>Contract Person</h3></td><td></td><td></td><td></td> </tr>"
		  
		  
		  +"<tr><td>Head Name:</td><td>"+document.form1.headName.value+"</td><td>Coordinator Name:</td><td>"+document.form1.cordinator.value+"</td> </tr>"
		  +"<tr><td>Designation:</td><td>"+document.form1.headDesignation.value+"</td><td>Designation</td><td>"+document.form1.cordinatorDesigntion.value+"</td> </tr>"
		  +"<tr><td>Mobile:</td><td>"+document.form1.headMobile.value+"</td><td>Mobile</td><td>"+document.form1.cordinatorMobile.value+"</td> </tr>"
		  +"<tr><td>Phone :</td><td>"+document.form1.headPhone.value+"</td><td>Phone</td><td>"+document.form1.cordinatorPhone.value+"</td> </tr>"
		  +"<tr><td>Email :</td><td>"+document.form1.headEmailID.value+"</td><td>Email</td><td>"+document.form1.cordinatorEmail.value+"</td> </tr>"
		  +"<tr><td>Fax :</td><td>"+document.form1.headFax.value+"</td><td>Fax</td><td>"+document.form1.cordinatorFAX.value+"</td> </tr>"
		 
		  +"<tr><td><h3>Other Detail</h3></td><td></td><td></td><td></td> </tr>"
		  +"<tr><td><h5>Other Detail 1</h5></td><td></td><td></td><td></td> </tr>"
		  
		  +"<tr><td>No OF Labs:</td><td>"+document.form1.noOfLabs.value+"</td><td>Number Of Building</td><td>"+document.form1.noOfBuilding.value+"</td> </tr>"
		  +"<tr><td>Total Computers:</td><td>"+document.form1.totalComputers.value+"</td><td>Number Of Floors Covered: </td><td>"+document.form1.noOfFloorsCovered.value+"</td> </tr>"
		  +"<tr><td>Total Usable Computers:</td><td>"+document.form1.totalUsableComputers.value+"</td><td>Number OF Entrance Gate:</td><td>"+document.form1.noOfEntranceGate.value+"</td> </tr>"
		  +"<tr><td>Date Of MOU:</td><td>"+document.form1.dateOfMOU.value+"</td><td>MOU Valid Till:</td><td>"+document.form1.mOUValidTill.value+"</td> </tr>"
	
		  +"<tr><td>Date Of Last Inspections:</td><td>"+document.form1.dateOfLastInspection.value+"</td><td>Approachability</td><td>"+$("#approachability option:selected").text()+"</td> </tr>"
		  +"<tr><td>No Of Web Cam Available:</td><td>"+document.form1.noOfWebCamera.value+"</td><td>No Of Biometric Device Available </td><td>"+document.form1.noOfBiometricDevice.value+"</td> </tr>"
		  +"<tr><td>No Of LAN:</td><td>"+document.form1.noOfLAN.value+"</td><td>Fuel Required Per Hour:</td><td>"+document.form1.fuelRequiredPerHour.value+"</td> </tr>"
		  +"<tr><td>Network Topology:</td><td>"+$("#networkTopology option:selected").text()+"</td><td>LAN Speed:</td><td>"+document.form1.lANspeed.value+"</td> </tr>"
		 
		  
		  
		  +"<tr><td>Network Cable Status:</td><td>"+$("#networkCableStatus option:selected").text()+"</td><td>Alert Message Status</td><td>"+document.form1.alertMessage.value+"</td> </tr>"
		  +"<tr><td>Power Supply Status:</td><td>"+$("#powerSupplyStatus option:selected").text()+"</td><td>Generator Capacity </td><td>"+document.form1.generatorCapacity.value+"</td> </tr>"
		  +"<tr><td>UPS Capacity:</td><td>"+document.form1.uPsCapacity.value+"</td><td>UPS Backup Timer</td><td>"+document.form1.uPSBackupTime.value+"</td> </tr>"
		  +"<tr><td>Center Approved By:</td><td>"+document.form1.centreApprovedBy.value+"</td><td>Center Details Updated By</td><td>"+document.form1.centreDetailUpdatedBy.value+"</td> </tr>"
		  +"<tr><td>Remarks:</td><td>"+document.form1.remarks.value+"</td><td></td><td></td> </tr>"
		  
		  +"<tr><td><h5>Other Detail 2</h5></td><td></td><td></td><td></td> </tr>"
		  
		  
		  +"<tr><td>IS Wired Internet :</td><td>"+$("#wiredInternet").prop('checked')+"</td><td>IS CCTV Available </td><td>"+$("#cCTVAvailable").prop('checked')+"</td> </tr>"
		  +"<tr><td>Is Wireless Internet :</td><td>"+$("#wirelessInternet").prop('checked')+"</td><td>Is CCTV Can Be Used</td><td>"+$("#cCTVcanBeUsed").prop('checked')+"</td> </tr>"
		  +"<tr><td>Is WiFi :</td><td>"+$("#wiFi").prop('checked')+"</td><td>Is Clock Room on Entrance </td><td>"+$("#clockRoomOnEntrance").prop('checked')+"</td> </tr>"
		  +"<tr><td>Is LAN :</td><td>"+$("#lAN").prop('checked')+"</td><td>Is Web Cam Available :</td><td>"+$("#webCameraAtCentre").prop('checked')+"</td> </tr>"
		  
		  
		  
		  +"<tr><td>Is Mobile Jammer Available  :</td><td>"+$("#mobileJammerAvailable").prop('checked')+"</td><td>Is External Biometric Device Available</td><td>"+$("#bioemetricDeviceAtCentre").prop('checked')+"</td> </tr>"
		  +"<tr><td>Is Partitioning of Computers :</td><td>"+$("#partitioningOfComputers").prop('checked')+"</td><td>Is Display Board Available</td><td>"+$("#displayBoards").prop('checked')+"</td> </tr>"
		  +"<tr><td>Is UPS Available  :</td><td>"+$("#uPSavailable").prop('checked')+"</td><td>Is Generator Available</td><td>"+$("#generatorAvailable").prop('checked')+"</td> </tr>"
		  +"<tr><td>Is Canteen Available :</td><td>"+$("#canteen").prop('checked')+"</td><td>Is Fire Extinguisher Available</td><td>"+$("#fireExtinguisher").prop('checked')+"</td> </tr>"
		  
		  +"<tr><td>Is Ready For Exam  :</td><td>"+$("#readyForExam").prop('checked')+"</td><td>Is Disable Friendly </td><td>"+$("#disableFriendly").prop('checked')+"</td> </tr>"
		  +"<tr><td>Is Sufficient Parking Space  :</td><td>"+$("#sufficientParkingSpace").prop('checked')+"</td><td>Is Sufficient Toilets </td><td>"+$("#sufficientToilets").prop('checked')+"</td> </tr>"
		  +"<tr><td>Is Waiting Area For Students :</td><td>"+$("#waitingAreaForStudents").prop('checked')+"</td><td>Is Waiting Area For Guardians</td><td>"+$("#waitingAreaForGuardian").prop('checked')+"</td> </tr>"
		  +"<tr><td>Is Management Responsive :</td><td>"+$("#managementResponsive").prop('checked')+"</td><td>Is Detailed Inspection Report Available</td><td>"+$("#detailedInspectionReportAvailable").prop('checked')+"</td> </tr>"
		  +"<tr><td>Is External Audit Report Available :</td><td>"+$("#externalAuditReportAvailable").prop('checked')+"</td><td></td><td></td> </tr>"
		  
	 		 ;
	 $("#previewId").html(strHtml);
	 
}


function loadNetworkTopology() {
	blockU();
	var htmlStr="<option value=-1>Select</option>";
	$
	.ajax({
		type : "get",
		url : "eonlecgetNetworkTopology",
		
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr+="<option value="+response[i].lookupId+">"+response[i].lookupName+"</option>";
			}
			$('#networkTopology').html(htmlStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load Network Topology');
		}
	});
}


function loadNetworkCableStatus() {
	blockU();
	var htmlStr="<option value=-1>Select</option>";
	$
	.ajax({
		type : "get",
		url : "eonlecgetNetworkCableStatus",
		
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr+="<option value="+response[i].lookupId+">"+response[i].lookupName+"</option>";
			}
			$('#networkCableStatus').html(htmlStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load Network Cable Status');
		}
	});
}


function loadPowerSupplyStatus() {
	blockU();
	var htmlStr="<option value=-1>Select</option>";
	$
	.ajax({
		type : "get",
		url : "eonlecgetPowerSupplyStatus",
		
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr+="<option value="+response[i].lookupId+">"+response[i].lookupName+"</option>";
			}
			$('#powerSupplyStatus').html(htmlStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load Power Supply Status');
		}
	});
}


function loadApprochability() {
	blockU();
	var htmlStr="<option value=-1>Select</option>";
	$
	.ajax({
		type : "get",
		url : "eonlecgetApprochability",
		
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr+="<option value="+response[i].lookupId+">"+response[i].lookupName+"</option>";
			}
			$('#approachability').html(htmlStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load Approachability');
		}
	});
}




function loadLanSpeed() {
	blockU();
	var htmlStr="<option value=-1>Select</option>";
	$
	.ajax({
		type : "get",
		url : "eonlecgetLanSpeed",
		
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr+="<option value="+response[i].lookupId+">"+response[i].lookupName+"</option>";
			}
			$('#lANspeed').html(htmlStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load Lan Speed');
		}
	});
}


function loadLecForEdit(centerId)
{
	if(centerId!="undefined" && centerId!=undefined)
	{
		blockU();
		setTimeout(function(){
			
			
			loadLecForEdit(centerId);
			
		}, 1000);	
	}
}
function loadLecForEdit1(centerId) {

	blockU();
	if(centerId!="undefined" && centerId!="")
		{
		
		var htmlStr="";
		$
		.ajax({
		type : "get",
		url : "eonlecgetLECForEdit?centerId="+centerId,
		cache : false,
		success : function(response) {
			unblockU("");
		document.form1.tempLecName.value=response.name;
		document.form1.tempgoogleURL.value=response.googleUrl;
// 	
		   
		document.form1.country.value=response.country;
//		    document.form1.state.value=response.country;
			districtId = response.district;
			stateId = response.state;
			cityId = response.city;
			
    		loadState(document.form1.country);
	//		loadState(response.country);
			
			$("input[type=checkbox]").each(function(){
				var name = this.name;
				//$.alert.open("document.forms[0]."+name+".value='"+response[0][name]+"'")
				//eval("document.forms[0]."+name+".value='"+response[0][name]+"'");
				if(response[name]=="0" || response[name]=="null" || response[name]==null)
					{
					eval("document.forms[0]."+name+".checked=false")
					}
				else
					{
					
					eval("document.forms[0]."+name+".checked=true")
					}
				})
			
			//for text
			$("input[type=text]").each(function(){
				var name = this.name;
				
				eval("document.forms[0]."+name+".value='"+response[name]+"'");
				})
				//for select
				$("select").each(function(){
	       
				var name = this.name;
				eval("document.forms[0]."+name+".value='"+response[name]+"'");
				})
				unblockU();
		},
		error : function() {
			unblockU();
			$.alert.open('Error while load LEC');
		}
	});
		}
}




// for edit page 

/*
* This function is call the controller  " lecGetLEC" and 
* Get the no of  LEC(local Examinnation Center)and
* Set all the City in the dropDown.
*/
function loadLEC(obj) {
	blockU();
	var htmlStr="<option value=-1>All</option>";
	$
	.ajax({
		type : "get",
		url : "eonlecGetLECRegistration?cityId="+obj.value,
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr+="<option value="+response[i].centreId+">"+response[i].name+"</option>";
				
			}
			
			$('#centreId').html(htmlStr);
			$('#lecComp').html(htmlStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load LEC');
		}
	});
}

function loadLabView(centreId,stateId,cityId){
	
	
	/*$
	.ajax({
		type : "get",
		url : "leclabView?cityId="+obj.value,
		cache : false,
		success : function(response) {
		
		},
		error : function() {
			$.alert.open('Error while load LEC');
		}
	});*/
}

function loadLecAll(obj){
	blockU();

	$('#table').bootstrapTable('showLoading');
	//ad by amit
	if(document.form1.state.value=="")document.form1.state.value="0";
	if(document.form1.city.value=="")document.form1.city.value="0";
	if(document.form1.centreId.value=="")document.form1.centreId.value="0";
	//ad by amit
	$.ajax({
		type : "get",
		url : "eonlecgetLECRegistrationForUpdate?centreId="+document.form1.centreId.value+"&state="+document.form1.state.value+"&city="+document.form1.city.value,
		cache : false,
		success : function(response) {	
			unblockU("");
			$('#table').bootstrapTable('hideLoading');
 			$('#notification').hide();  
 			$('#table').bootstrapTable('load', response); 
		/*var htmlval="";	
		var cnt=1;	
		for(var i=0;i<response.length;i++){
		    htmlval +="<tr><td scope='row'> "+(cnt++)+" </td>";
		    htmlval +="<td>"+response[i].centreId+"</td>";
		    htmlval +="<td>"+response[i].name+"</td>";
		    htmlval +="<td>"+response[i].totalUsableComputers+"</td>";
		    htmlval +="<td><a href='lecRegistrationView?centerId="+response[i].centreId+"' class='glyphicon glyphicon-edit' aria-hidden='true' id='edit' ></a></td>";
		    htmlval +="</tr>";*/
//		}
			
//		$("#tableId").html(htmlval);		
			
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load All LEC');
			$('#table').bootstrapTable('hideLoading');
 			$('#notification').hide();  
		}
	});
}

function checkCordinatorDetail(){
    if(document.getElementById('checkaddress').checked == true){
    document.getElementById('cordinator').value = document.getElementById('headName').value;
//  	document.getElementById('cordinator').disabled="disabled";
  	document.getElementById('cordinatorDesigntion').value = document.getElementById('headDesignation').value;
//  	document.getElementById('cordinatorDesigntion').disabled="disabled";
  	document.getElementById('cordinatorMobile').value = document.getElementById('headMobile').value;
//  	document.getElementById('cordinatorMobile').disabled="disabled";
  	document.getElementById('cordinatorPhone').value = document.getElementById('headPhone').value;
//  	document.getElementById('cordinatorPhone').disabled="disabled";	
  	document.getElementById('cordinatorEmail').value = document.getElementById('headEmailID').value;
//  	document.getElementById('cordinatorEmail').disabled="disabled";
  	document.getElementById('cordinatorFAX').value = document.getElementById('headFax').value;
//  	document.getElementById('cordinatorFAX').disabled="disabled";
  	}
  	else {
  	document.getElementById('cordinator').value = '';
//  	document.getElementById('cordinator').disabled="";
  	document.getElementById('cordinatorDesigntion').value = '';
//  	document.getElementById('cordinatorDesigntion').disabled="";
  	document.getElementById('cordinatorMobile').value = '';
//  	document.getElementById('cordinatorMobile').disabled="";
  	document.getElementById('cordinatorPhone').value = '';
//  	document.getElementById('cordinatorPhone').disabled="";	
 	document.getElementById('cordinatorEmail').value = '';
//  	document.getElementById('cordinatorEmail').disabled="";
 	document.getElementById('cordinatorFAX').value = '';
//  	document.getElementById('cordinatorFAX').disabled="";
  	}  
    
}
function validateCountry() {	
	var country = $("#country").val();
	
	  if(country == '-1'){
	    	$.alert.open("Please select Country");
	    	return false;
	    }
}
function validateState() {	
	var state = $("#state").val();
	
	  if(state == '-1'){
	    	$.alert.open("Please select State");
	    	return false;
	    }
}
function validateCity() {	
	var city = $("#city").val();
	
	  if(city == '-1'){
	    	$.alert.open("Please select City");
	    	return false;
	    }
}
function validateLecName() {	
	var name = document.form1.name.value;
	name=name.trim();	
	 if (name == null || name == "" || name == " ") 
	 {
	 $.alert.open("LEC Name must be filled out");
	 return false;
	 }
}

function validateHeadName() {	
	var headName = document.form1.headName.value;
    headName=headName.trim();
    if (headName == null || headName == "" || headName == " ") {
        $.alert.open("Head Name must be filled out");
        return false;
    }
}
function validateCoordinatorName() {
	var cordinator = document.form1.cordinator.value;
    cordinator=cordinator.trim();	
    if (cordinator == null || cordinator == "" || cordinator == " ") {
        $.alert.open("Cordinator Name must be filled out");
        return false;
}
}

