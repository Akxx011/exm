// start for next tab
$(document).ready(function() {
    $('.nexttab').click(function(){
  $('.nav-tabs > .active').next('li').find('a').trigger('click');
  
  //Computer
  
  if($('#stateComp').val()==-1 && $('#state').val()==-1){
		loadStateComp();
		}
	
	if($('#stateComp').val()==-1 && $('#state').val()!=-1){
		  
		  initialLoadStateComp();
		  
		  if($('#city').val()!=-1){
			  initialLoadCityComp(document.LabInfofrm.state);
		  }
		  if($('#centreId').val()!=-1){
			  initialLoadLecComp(document.LabInfofrm.city);
		  }
	  }
	
	//Man Power
	
	if($('#stateManPower').val()==-1 && $('#stateComp').val()==-1){
		loadStateMP();
		}
	
	if($('#stateManPower').val()==-1 && $('#stateComp').val()!=-1){
		  
		  initialLoadStateMP();
		  
		  if($('#cityComp').val()!=-1){
			  initialLoadCityMP(document.form1.stateComp);
		  }
		  if($('#compCenterId').val()!=-1){
			  initialLoadLecMP(document.form1.cityComp);
		  }
	  }
	
 /* if($('#stateManPower').val()==-1){
		loadStateMP();
		}*/
});
    $('.prevtab').click(function(){
    	  $('.nav-tabs > .active').prev('li').find('a').trigger('click');
    	});
});


/**
 * 
 */var noOfLabs =0;
$(document).ready(function() {
	$('#submitMP').click(function() {
		$('#tab-1').removeClass("active");
		$('#tab-3').addClass("active");
	});
	// $('#addManPowerRecord').style.visibility = 'hidden';
	$('#moudate').datepicker({
		format : 'yyyy-mm-dd',
	});
	$('#mouenddate').datepicker({
		format : 'yyyy-mm-dd'
	});
	$('#incepectiondate').datepicker({
		format : 'yyyy-mm-dd'
	});
});

// for show and hide div
$(document).ready(function() {

	$('input[type="radio"]').click(function() {
		if ($(this).attr("value") == "all") {
			$(".box").not(".value").hide();
			$(".all").show();
		}
		if ($(this).attr("value") == "byrow") {
			$(".box").not(".byrow").hide();
			$(".byrow").show();
		}
		if ($(this).attr("value") == "byrange") {
			$(".box").not(".byrange").hide();
			$(".byrange").show();
		}
		if ($(this).attr("value") == "ind") {
			$(".box").not(".ind").hide();
			$(".ind").show();
		}
	});
});

function onSaveOrUpdate(mode){
	if(!validateLabDtl())
		{
		return false;
		}
	if(confirm("Are you sure? Do you want to save")){
		
		initilizeValueOfBlankField(noOfLabs);
	var frm=$('#LabInfofrm');
	
	  $.ajax({
	        type: frm.attr('method'),
	        url: frm.attr('action'),
	        data: frm.serialize(),
	        success: function (response) {
	         $.alert.open("Data has been successfully saved");
	         loadNoOfLabs($("#centreId").val());
	        	
	        },
			error : function() {
				$.alert.open('Error while assigning the value');
			}
	    });
	}
}
function onStateChange(obj) {

	var htmlStr = "<option value=-1>Select</option>";

	$('#centreId').html(htmlStr);

	$("#labsInformationTable tbody").html("");
	
	$("#save").remove();
	$("#update").remove();
	$("#cancel").remove();
}

/*
 * This function is call the controller " lecGetState" and Get the no of State
 * and Set all the states in the dropDown
 */
function loadState(obj,stateId,cityName,cityId) {
	var htmlStr = "<option value=-1>Select</option>";
	$.ajax({
		type : "get",
		url : "eonlecGetState",
		cache : false,
		success : function(response) {
			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].stateId + ">"
						+ response[i].stateName + "</option>";
			}
			$('#state').html(htmlStr);
			if(stateId!=""){
			$('#state').val(stateId);
				if(cityId!=""){
					$('#city option:selected').text(cityName);
					$('#city option:selected').val(cityId);
				}
			}
			$('#stateApp').html(htmlStr);
		},
		error : function() {
			$.alert.open('Error while load State');
		}
	});
}

/*
 * This function is call the controller " lecGetCity" and Get the no of City and
 * Set all the City in the dropDown
 */
function loadCity(obj) {
	blockU();
	var htmlStr = "<option value=-1>Select</option>";
	
	if($('#state').val()!=-1){
		$.ajax({
			type : "get",
			url : "eonlecGetCity?stateId=" + obj.value,
			cache : false,
			success : function(response) {
				unblockU("");
				for (var i = 0; i < response.length; i++) {
					htmlStr += "<option value=" + response[i].cityId + ">"
							+ response[i].cityName + "</option>";
				}

				$('#city').html(htmlStr);
				
			},
			error : function() {
				unblockU("");
				$.alert.open('Error while load city');
			}
		});
		
	}
	
	
}
/*
 * This function is call the controller " lecGetLEC" and Get the no of LEC(local
 * Examinnation Center)and Set all the City in the dropDown.
 */
function loadLEC(obj) {
	blockU();
//	for lab
	$("#labsInformationTable tbody").html("");
	$("#save").remove();
	$("#update").remove();
	$("#cancel").remove();
	var htmlStr = "<option value=-1>Select</option>";
	
	if($('#city').val()!=-1){
		
	$.ajax({
		type : "get",
		url : "eonlecGetLEC?cityId=" + obj.value,
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].centreId + ">"
						+ response[i].name + "</option>";

			}
			$('#centreId').html(htmlStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load LEC');
		}
	});
	}

}
/*
 * This function is call the controller " lecGetLabs" and Get the no of labs
 * corresponding to LEC(local Examinnation Center)and populate a table having
 * row equal to list of labs and put infornation of each labs here.
 */
function loadLabs(obj) {
	blockU();
	hideComputerSysDtl(0);
	var htmlStr = "<option value=-1>Select</option>";
	var htmlStrComp = "<option value=-1>Select</option>";
	//for Computer	
	$("#compMatrixTable tbody").html("");
	if($('#compCenterId').val()!=-1){
	
	$.ajax({
		type : "get",
		url : "eonlecGetLabs?centreId=" + obj.value,
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].labId + ">"
						+ response[i].labName + "</option>";
				
				if(response[i].noOfComputerinRow>0 && response[i].noOfRows){
				htmlStrComp+= "<option value=" + response[i].labId + ">"
				+ response[i].labName + "</option>";
				}
			}
			$('#compLabId').html(htmlStrComp);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load Labs');
		}
	});
	
	}
}
// This function Set the val as per checked or unchecked the checkbox
// function changeCheckboxVal1(obj,uncheckVal,checkVal)
// {
//	
// if(obj.checked==true)
// {
// obj.value=checkVal;
//		
// }
// else if(obj.checked==false)
// {
// obj.value=uncheckVal;
// //$.alert.open("uncheck");
// }
// }

function changeCheckboxVal1(obj, uncheckVal, checkVal, i) {

	var disablefrndly = "disableFriendly" + i;
	if (obj.checked == true) {

		$("#" + disablefrndly).val("1");
	}
	if (obj.checked == false) {
		$("#" + disablefrndly).val("0");
	}
}

function EditEnable(i, labid) {
	$("#cancel").show();
	$("#update").prop('disabled', false);
	var ttlComputer = "totalComputer" + i;

	var ttlUsableComputer = "totalUsableComputer" + i;
	var blk = "block" + i;
	var flor = "floor" + i;
	var nofRows = "noOfRows" + i;
	var nOfComputerinRow = "noOfComputerinRow" + i;
	$("#" + ttlComputer).removeAttr("readonly");
	$("#" + ttlUsableComputer).removeAttr("readonly");
	$("#" + blk).removeAttr("readonly");
	$("#" + flor).removeAttr("readonly");
	$("#" + nofRows).removeAttr("readonly");
	$("#" + nOfComputerinRow).removeAttr("readonly");
};
function cancelupdateData(){
	
	var centerId=$("#centreId").val();
	loadNoOfLabs(centerId);
}
/*
 * This function is call the controller " lecGetNoOfLabs" and Get the no of labs
 * corresponding to LEC(local Examinnation Center)and populate a table having
 * row equal to list of labs and put infornation of each labs here.
 */

function loadNoOfLabs(obj) {
	
	if(obj==""){
		return;
	}
	
	$()
	var totComp=0;
	var usableComp=0;
	var lecName=$("#centreId option:selected").text();
	if(obj==-1){
		$("#labsInformationTable tbody").html("");
		$("#save").remove();
		$("#update").remove();
		$("#cancel").remove();
		$.alert.open("Please select LEC First");
		return;
	}
	else
		
		
	$("#labsInformationTable tbody").html("");
	$("#save").remove();
	$("#update").remove();
	$("#cancel").remove();
	var htmlStr = "<tr> <th>Lab No</th><th>Lab ID</th><th>Lab Name</th><th>Total Computer</th><th>Usable Computer</th><th>Block</th><th>Floor</th><th>No of Rows</th><th>No of Computer in Each Row</th> <th>Is Display Friendly</th></tr>";
	var htmlStr1 = "<tr> <th>Lab No</th><th>Lab ID</th><th>Lab Name</th><th>Total Computer</th><th>Usable Computer</th><th>Block</th><th>Floor</th><th>No of Rows</th><th>No of Computer in Each Row</th> <th>Is Display Friendly</th><th>Action</th></tr>";
	blockU();
	$
			.ajax({
				type : "get",
				url : "eonlecGetNoOfLabs?centreId=" + obj,
				cache : false,
				success : function(response) {
					unblockU("");
					$("#centreId option:selected").val(obj);
					if(lecName=='Select'){
					
					$("#centreId option:selected").text(response[0].lecName);
					}
					else{
						
						$("#centreId option:selected").text(lecName);
					}
					if (response[0].noOfLabs == null) {

						noOfLabs = response[0].noOfLabs;
						
						$("#labsInformationTable").append(htmlStr1);
						for (var i = 0; i < response.length; i++) {
							totComp+=response[i].totalComputer;
							usableComp+=response[i].totalUsableComputer;
							var disableFriendly = response[i].disableFriendly;
							if (disableFriendly == 0) {
								disableFriendly = "";
							} else {
								disableFriendly = "checked";
							}

							var htmlStrr = "<tr><td><input type='hidden' name='noOfLabs' value="
									+ noOfLabs
									+ "><input type='hidden' name='labcode' value='"
									+ response[i].labcode
									+ "'><input type='hidden' id='labId' name='labId' value="
									+ response[i].labId
									+ "><label name='labNo'>"
									+ response[i].labNo
									+ "</label><input type='hidden' name='labNo' value="
									+ response[i].labNo
									+ "> </td>"
									+ " <td><label name='labcode' >"
									+ response[i].labcode
									+ "</label></td>"
									+ "<td><input class='form-control' type='text' maxlength='20' onkeypress='return validateData(event,9)' name='labName' value='"
									+ response[i].labName
									+ "' readonly ></td>"
									+ "<td><input class='form-control' type='text' maxlength='4' onkeypress='return validateData(event,5)' name='totalComputer' id='totalComputer"
									+ i
									+ "' value="
									+ response[i].totalComputer
									+ " readonly></td>"
									+ "<td><input class='form-control' type='text' maxlength='4' onkeypress='return validateData(event,5)' name='totalUsableComputer' id='totalUsableComputer"
									+ i
									+ "'; value="
									+ response[i].totalUsableComputer
									+ " readonly></td>"
									+ "<td><input class='form-control' type='text' maxlength='2' onkeypress='return validateData(event,5)' name='block' id='block"
									+ i
									+ "' value="
									+ response[i].block
									+ " readonly></td>"
									+ "<td><input class='form-control' type='text' maxlength='2' onkeypress='return validateData(event,5)' name='floor' id='floor"
									+ i
									+ "' value="
									+ response[i].floor
									+ " readonly></td>"
									+ "<td><input class='form-control' type='text' maxlength='3' onkeypress='return validateData(event,5)' name='noOfRows' id='noOfRows"
									+ i
									+ "' value="
									+ response[i].noOfRows
									+ " readonly></td>"
									+ "<td><input class='form-control' type='text' maxlength='3' onkeypress='return validateData(event,5)' name='noOfComputerinRow' id='noOfComputerinRow"
									+ i
									+ "' value="
									+ response[i].noOfComputerinRow
									+ " readonly></td>"
									+ "<td><input type='checkbox'  onClick='changeCheckboxVal1(this,0,1,"
									+ i
									+ ")' name='disableFriendly1' "
									+ disableFriendly
									+ " value='"
									+ response[i].disableFriendly
									+ "' readonly><input type='hidden' id='disableFriendly"
									+ i
									+ "' name='disableFriendly' value='"
									+ response[i].disableFriendly
									+ "'></td>"
									+ "<td> <a href='#'class='glyphicon glyphicon-pencil' aria-hidden='true' id='edit'  onclick=EditEnable("
									+ i
									+ ","
									+ response[i].labId
									+ ")></a></td></tr>";

							$("#labsInformationTable").append(htmlStrr);
						}
						$("#hid")
								.append(
										"<div class='btn pull-left'><input  type='button' onclick='onSaveOrUpdate(1);' class='btn btn-primary' id='update' value='Update' disabled> <input  type='button'  id='cancel' class='btn btn-danger' onclick='cancelupdateData()' value='Cancel' style='display:none'> </div>");
					} else {
						var valueOfChkBox = 0;
						 noOfLabs = response[0].noOfLabs;
						var LecName = response[0].lecName;
						totComp=response[0].totalNoOfComputer;
						usableComp=response[0].totalNoOfUsableComputer;
						if (response[0].noOfLabs > 0) {
							$("#labsInformationTable").append(htmlStr);
							for (var i = 1; i <= noOfLabs; i++) {
								var htmlStrr = "<tr><td><input type='hidden' name='noOfLabs' value="
										+ noOfLabs
										+ "><label name='labNo'>"
										+ i
										+ "</label><input type='hidden' name='labNo' value="
										+ i
										+ "> </td>"
										+ "<td><label name='labcode' >"
										+ LecName
										+ ""
										+ i
										+ "</label><input type='hidden' name='labcode' value='"
										+ LecName
										+ ""
										+ i
										+ "'></td>"
										+ "<td><input class='form-control' type='text' name='labName' id='labName"
										+ i
										+ "' ></td>"
										+ "<td><input class='form-control' type='text' id='totalComputer"
										+ i
										+ "' name='totalComputer'></td>"
										+ "<td><input class='form-control' type='text' id='totalUsableComputer"
										+ i
										+ "'; name='totalUsableComputer'></td>"
										+ "<td><input class='form-control' type='text' id='block"
										+ i
										+ "' name='block' ></td>"
										+ "<td><input class='form-control' type='text' id='floor"
										+ i
										+ "' name='floor' ></td>"
										+ "<td><input class='form-control' type='text' id='noOfRows"
										+ i
										+ "' name='noOfRows'></td>"
										+ "<td><input class='form-control' type='text' id='noOfComputerinRow"
										+ i
										+ "' name='noOfComputerinRow'></td>"
										+ "<td><input type='checkbox' id='disableFriendly1"
										+ i
										+ "' name='disableFriendly1' value="
										+ valueOfChkBox
										+ " onClick='changeCheckboxVal1(this,0,1,"
										+ i
										+ ")'><input type='hidden' id='disableFriendly"
										+ i
										+ "' name='disableFriendly' value='0'></td></tr>";
								$("#labsInformationTable").append(htmlStrr);
							}
							$("#labsInformationTable")
									.append(
											"<div class='btn pull-right' id='save'><input  type='button'  class='btn btn-success' value='Save' onclick='onSaveOrUpdate(0);' > <input type='button' class='btn btn-success' id='cancel' value='cancel' onclick='cancelupdateData()'  </div>");
							
		
						}
					}
					$("#labsInformationTable").append("<input type=hidden name=tempTotalNoOfComp id=tempTotalNoOfComp value="+totComp+"><input type=hidden name=tempTotalNoOfUsable id=tempTotalNoOfUsable value="+usableComp+">");
				},
				error : function() {
					unblockU("");
					$.alert.open('Error while load NoOfLabs');
				}
			});
}
function initilizeValueOfBlankField(noOfLabs) {

	for (var i = 1; i <= noOfLabs; i++) {
		var labNme = "labName" + i;
		var ttlComputer = "totalComputer" + i;
		var ttlUsableComputer = "totalUsableComputer" + i;
		var blk = "block" + i;
		var flor = "floor" + i;
		var nofRows = "noOfRows" + i;
		var nOfComputerinRow = "noOfComputerinRow" + i;
		var disablefrndly = "disableFriendly" + i;
		// if($("#"+labNme").val()==""){
		// $.alert.open("LabName Can't blank or null");
		// return false;
		// }
		if ($("#" + ttlComputer).val() == "") {
			$("#" + ttlComputer).val("0");
		}

		if ($("#" + ttlUsableComputer).val() == "") {
			$("#" + ttlUsableComputer).val("0");
		}
		if ($("#" + blk).val() == "") {
			$("#" + blk).val("0");
		}
		if ($("#" + flor).val() == "") {
			$("#" + flor).val("0");
		}
		if ($("#" + nofRows).val() == "") {
			$("#" + nofRows).val("0");
		}
		if ($("#" + nOfComputerinRow).val() == "") {
			$("#" + nOfComputerinRow).val("0");
		}
		// if($("#"+disablefrndly).val()==""){
		// $("#"+disablefrndly).val("0");
		// }

	}
	
}
function checkLabInfoFrm() {
	var formData = JSON.stringify(jQuery('#LabInfofrm').serializeArray()); // store
	// json
	// string

	$.ajax({
		type : "post",
		url : "eonsaveLabInfo",
		contentType : "application/json",
		data : JSON.stringify({
			"id" : "" + formData
		}),
		success : function(response) {

		},
		error : function() {
			$.alert.open('Error while request..');
		}
	});
}
function validateLabDtl()
{
	var labName=document.getElementsByName("labName");
	var totalComputer=document.getElementsByName("totalComputer");
	var totalUsableComputer=document.getElementsByName("totalUsableComputer");
	var noOfRows=document.getElementsByName("noOfRows");
	var noOfComputerinRow=document.getElementsByName("noOfComputerinRow");
	var totalComp=0;
	var totalUsableCom=0;
	for(var i = 0; i<totalComputer.length;i++)
		{
		
		    if(!isNaN(totalComputer[i].value))
		    	{
		    		totalComp+=parseInt(totalComputer[i].value);
		    	}
			    if(!isNaN(totalUsableComputer[i].value))
		    	{
			    	totalUsableCom+=parseInt(totalUsableComputer[i].value);
		    	}
			if(labName[i].value.replace(/\s*/, "")=="")
			 {
				  $.alert.open("Please enter Lab Name.");
				  labName[i].focus();
				  labName[i].style.border = "1px solid #ff0000";
				  return false;
		     }
			if(totalComputer[i].value.replace(/\s*/, "")=="")
			 {
				  $.alert.open("Please enter Total Computer");
				  totalComputer[i].focus();
				  totalComputer[i].style.border = "1px solid #ff0000";
				  return false;
		     }
			if(totalUsableComputer[i].value.replace(/\s*/, "")=="")
			 {
				  $.alert.open("Please enter Total UsableComputer");
				  totalUsableComputer[i].focus();
				  totalUsableComputer[i].style.border = "1px solid #ff0000";
				  return false;
		     }
			if(noOfRows[i].value.replace(/\s*/, "")=="")
			 {
				  $.alert.open("Please enter No Of Rows");
				  noOfRows[i].focus();
				  noOfRows[i].style.border = "1px solid #ff0000";
				  return false;
		     }
			if(noOfComputerinRow[i].value.replace(/\s*/, "")=="")
			 {
				  $.alert.open("Please enter No Of Computerin Row");
				  noOfComputerinRow[i].focus();
				  noOfComputerinRow[i].style.border = "1px solid #ff0000";
				  return false;
		     }
			
			if(parseInt(totalComputer[i].value)<parseInt(totalUsableComputer[i].value))
			 {
				  $.alert.open("Total Usable Computer cannot greater then Total No Of Computer.");
				  totalUsableComputer[i].focus();
				  totalUsableComputer[i].style.border = "1px solid #ff0000";
				  return false;
			 }
			
			 if(parseInt(totalComputer[i].value)!=(parseInt(noOfRows[i].value) * parseInt(noOfComputerinRow[i].value) )  )
			 {
				  $.alert.open("The multiplication of row no. and computer no. in each row should be equal to total computer entered");
				  noOfComputerinRow[i].focus();
				  noOfComputerinRow[i].style.border = "1px solid #ff0000";
				  noOfRows[i].focus();
				  noOfRows[i].style.border = "1px solid #ff0000";
				  return false;
			 }
			 
		}

	if(parseInt($("#tempTotalNoOfComp").val())!=totalComp)
		{
		 $.alert.open("sum of computers ("+totalComp+") entered for all the labs is not equal to total no of computer ("+$("#tempTotalNoOfComp").val()+") entered while registration.");
		 return false;
		}
		if(parseInt($("#tempTotalNoOfUsable").val())!=totalUsableCom)
		{
			$.alert.open("sum of usable computers ("+totalUsableCom+") entered for the labs is not equal to total no of usable computer ("+$("#tempTotalNoOfUsable").val()+") entered while registration.");
		 return false;
		}
	
	return true;
}

