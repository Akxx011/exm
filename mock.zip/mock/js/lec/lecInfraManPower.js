/**
 * Author NysaSoft
 */

function onMPTabClick(){

	
//Man Power
	
	if($('#stateManPower').val()==-1 && $('#stateComp').val()==-1){
		loadStateMP();
		}
	
	if($('#stateManPower').val()==-1 && $('#stateComp').val()!=-1){
		  
		  initialLoadStateMP();
		  
		  if($('#cityComp').val()!=-1){
			  initialLoadCityMP(document.form1.stateComp);
		  }
		  if($('#compCenterId').val()!=-1){
			  initialLoadLecMP(document.form1.cityComp);
		  }
	  }
}
/**
 * This function is used to clear all the data from the fields and reload the
 * form again
 */
function onStateChangeMP(obj) {

	var htmlStr = "<option value=-1>Select</option>";

	$('#centreIdManPower').html(htmlStr);
	
	$("#noOfStaff").val('');
	$("#tblManPower tbody").html("");
	$("#addManPowerRecord").css("visibility","hidden");
}

function initialLoadStateMP() {

	var htmlStr = "<option value=-1>Select</option>";
	$.ajax({
		type : "get",
		url : "eonlecGetState",
		cache : false,
		success : function(response) {
			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].stateId + ">"
						+ response[i].stateName + "</option>";
			}
			$('#stateManPower').html(htmlStr);
			$('#stateManPower').val($('#stateComp').val());
		},
		error : function() {
			$.alert.open('Error while load State');
		}
	});
}

function initialLoadCityMP(obj) {
	
	var htmlStr = "<option value=-1>Select</option>";
	
		$.ajax({
			type : "get",
			url : "eonlecGetCity?stateId=" + obj.value,
			cache : false,
			success : function(response) {

				for (var i = 0; i < response.length; i++) {
					htmlStr += "<option value=" + response[i].cityId + ">"
							+ response[i].cityName + "</option>";
				}
				$('#cityManPower').html(htmlStr);
				$('#cityManPower').val($('#cityComp').val());
			},
			error : function() {
				$.alert.open('Error while load city');
			}
		});
		
	
}

function initialLoadLecMP(obj) {
	

	var htmlStr = "<option value=-1>Select</option>";
	
	$.ajax({
		type : "get",
		url : "eonlecGetLEC?cityId=" + obj.value,
		cache : false,
		success : function(response) {
			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].centreId + ">"
						+ response[i].name + "</option>";

			}
			$('#centreIdManPower').html(htmlStr);
			$('#centreIdManPower').val($('#compCenterId').val());
			loadNoOfStaffInfo($('#compCenterId').val());
		},
		error : function() {
			$.alert.open('Error while load LEC');
		}
	});

}


/*
 * This function is call the controller " lecGetState" and Get the no of State
 * and Set all the states in the dropDown
 */
function loadStateMP() {

	var htmlStr = "<option value=-1>Select</option>";
	$.ajax({
		type : "get",
		url : "eonlecGetState",
		cache : false,
		success : function(response) {
			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].stateId + ">"
						+ response[i].stateName + "</option>";
			}
			$('#stateManPower').html(htmlStr);
		},
		error : function() {
			$.alert.open('Error while load State');
		}
	});
}

/*
 * This function is call the controller " lecGetCity" and Get the no of City and
 * Set all the City in the dropDown
 */
function loadCityMP(obj) {
	blockU();
	var htmlStr = "<option value=-1>Select</option>";
	
	if($('#stateManPower').val()!=-1){
		$.ajax({
			type : "get",
			url : "eonlecGetCity?stateId=" + obj.value,
			cache : false,
			success : function(response) {
				unblockU("");
				for (var i = 0; i < response.length; i++) {
					htmlStr += "<option value=" + response[i].cityId + ">"
							+ response[i].cityName + "</option>";
				}
				$('#cityManPower').html(htmlStr);
			},
			error : function() {
				unblockU("");
				$.alert.open('Error while load city');
			}
		});
		
	}
	
	
}
/*
 * This function is call the controller " lecGetLEC" and Get the no of LEC(local
 * Examinnation Center)and Set all the City in the dropDown.
 */
function loadLECMP(obj) {
	blockU();
//	for manPower
	$("#noOfStaff").val('');
	$("#tblManPower tbody").html("");
	$("#addManPowerRecord").css("visibility","hidden");

	var htmlStr = "<option value=-1>Select</option>";
	
	if($('#cityManPower').val()!=-1){
		
	$.ajax({
		type : "get",
		url : "eonlecGetLEC?cityId=" + obj.value,
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].centreId + ">"
						+ response[i].name + "</option>";

			}
			$('#centreIdManPower').html(htmlStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load LEC');
		}
	});
	}

}


function loadManPower() {
	$("#submitMP").val("Add");
	var htmlStr = "<option value=1>Select</option>";
	$("#nameMP").val("");
	$("#mobile1MP").val("");
	$("#fatherMP").val("");
	$("#mobile2MP").val("");
	$("#roleMP").val(htmlStr);
	$("#emailMP").val("");
	$("#sourceMP").val(htmlStr);
	$("#availableMP").val("");
	$("#QualificationMP").val(htmlStr);
	$("#remarksMP").val("");
	$("#cMPIdMP").val("0");
	$("#availableMP").prop("checked", false);// function set the value is
												// unchecked in the checkBox
	var obj = $("#centreIdManPower").val();
	loadNoOfStaffInfo(obj);// obj=centerId
	loadQualification('12');
	loadSource('13');
	loadRole();

}
/**
 * this function call on each add and update of the form and add or update the
 * data
 */

function onAddOrUpdate() {

	
	
	
	
	
	
	checkArray=["name","mobile1","role","source","qualification"];
	msgArray=["Please enter name.","Please enter mobile no.","please select role.","Please select source.","Please select qualification."];
	
	
	
	if (validateFields(checkArray, 5, msgArray) && confirm("Are you sure? Do you want to add or update")) {

		var frm = $('#AddManPowerInfoFrm');

		$.ajax({
			type : frm.attr('method'),
			url : frm.attr('action'),
			data : frm.serialize(),
			success : function(response) {
				loadManPower();

				$.alert.open("Data has been successfully add or update");

			},
			error : function() {
				$.alert.open('Error while add or update');
			}
		});
	}
}
/**
 * This function is loads all the qualification from the appropriate table and
 * return all the qualification with their id in the form of list and this list
 * populates in the drop down
 */

function loadQualification(lookuptypeId) {

	var htmlStr = "<option value=-1>Select</option>";
	$.ajax({
		type : "get",
		url : "eonlecloadQualificationAndSource?lookuptypeId=" + lookuptypeId,
		cache : false,
		success : function(response) {
			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].lookupId + ">"
						+ response[i].lookupName + "</option>";
			}
			$('#QualificationMP').html(htmlStr);
		},
		error : function() {
			$.alert.open('Error while loadQualification');
		}
	});
}
/**
 * This function is used to change the value of checkbox if the checkbox is
 * checked it will set the value is 1 if the checkbox is not checked or by
 * default it als0 be 0.its by default value is set at the time of declaration
 * of checkbox
 */
function changeIsAvailableValue() {

	if ($("#availableMP").is(":checked")) {
		$("#availableMP").val("1");

	} else {
		$("#availableMP").val("0");

	}

}
/**
 * This function is loads all the Source from the appropriate table and return
 * all the Source with their id in the form of list and this list populates in
 * the drop down
 */
function loadSource(lookuptypeId) {

	// var lookuptypeId="13";
	var htmlStr = "<option value=-1>Select</option>";
	$.ajax({
		type : "get",
		url : "eonlecloadQualificationAndSource?lookuptypeId=" + lookuptypeId,
		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {

				htmlStr += "<option value=" + response[i].lookupId + ">"
						+ response[i].lookupName + "</option>";
			}
			$('#sourceMP').html(htmlStr);
		},
		error : function() {
			$.alert.open('Error while loadSource');
		}
	});
}
/**
 * This function is loads all the Role from the appropriate table and return all
 * the Role with their id in the form of list and this list populates in the
 * drop down
 */
function loadRole() {

	// var lookuptypeId="13";
	var htmlStr = "<option value=-1>Select</option>";
	$.ajax({
		type : "get",
		url : "eonlecloadRole",
		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {

				htmlStr += "<option value=" + response[i].roleId + ">"
						+ response[i].roleName + "</option>";
			}
			$('#roleMP').html(htmlStr);
		},
		error : function() {
			$.alert.open('Error while loadRole');
		}
	});
}
/**
 * This function is loads all the Respective data as per centerid if the data
 * exist populates all the data into the table and also add the a field into the
 * table it can edit this data as per id of each row and if data is not exist
 * then no data will be populate. only the add manpower div will be populates by
 * this you can add the data.
 */
function loadNoOfStaffInfo(obj) {// here obj is the centerId
	blockU();
	$("#tblManPower tbody").html('');
	var htmlStr = "<tr> <th>S.No</th><th>Name</th><th>Role</th><th>Mobile No.</th><th>Email Id</th><th>Source</th><th>Edit</th><th>Delete</th></tr>";
	$
			.ajax({
				type : "get",
				url : "eonlecGetNoOfStaffInfo?centreId=" + obj,
				cache : false,
				success : function(response) {
					unblockU("");
					if (response == "") {
						$("#noOfStaff").val(0);
						$("#addManPowerRecord").css("visibility", 'visible');
						$("#exitMP").toggle().show();

					} else if (response[0].cMPId == 0) {
						$("#addManPowerRecord").css("visibility", 'visible');

					} else {
						$("#addManPowerRecord").css("visibility", 'visible');
						$("#tblManPower").append(htmlStr);
						$("#noOfStaff").val(response.length);

						for (var i = 0; i < response.length; i++) {
							var j = i + 1;

							if (response[i].source == 1300) {
								var source = "EON";
							} else if (response[i].source == 1301) {
								source = "LEC";
							} else if (response[i].source == 1302) {
								source = "ECB";
							} else {
								source = "Select";
							}
							var htmlStrr = "<tr><td><label name='srl'>"
									+ j
									+ "</label></td><td><input type='text' name='name' value='"
									+ response[i].name
									+ "' readonly> </td> <td><input class='form-control' type='text' name='role' id='role"
									+ i
									+ "' value="
									+ response[i].role1.roleName
									+ " readonly ></td> <td><input class='form-control' type='text' name='mobile1' id='mobile1"
									+ i
									+ "'  value="
									+ response[i].mobile1
									+ " readonly ></td><td><input class='form-control' type='text' name='email' id='email"
									+ i
									+ "' value="
									+ response[i].email
									+ "  readonly ></td><td><input class='form-control' type='text' name='source' id='source"
									+ i
									+ "' value="
									+ source          
									+ " readonly ></td><td> <a href='#' class='glyphicon glyphicon-pencil' aria-hidden='true' id='edit'  onclick=EditManPower("
									+ i + "," + response[i].cMPId
									+ ")></a>" +
									"<td><a href='#' class='glyphicon glyphicon-remove-circle' aria-hidden='true' id='edit'style='color:red'  onclick=delManPower("
									+ i + "," + response[i].cMPId
									+ ")></a>" +
									"</td>" +
									"</tr>";
							$("#tblManPower").append(htmlStrr);
							$("#exitMP").toggle().show();	
						}
						
						/*if(response!="")
						{
						$("#noOfStaff").val(response.length);
						}*/
					
						
						
						
					}

				},
				error : function() {
					unblockU("");
					$.alert.open('Error while load NoOfManPowerInfo');
				}
			});

}
/**
 * 
 * @param i
 *            this is used to confirm the id of each row
 * @param cMPId
 *            this 'center man power id' parameter is unique for each row and
 *            used to get all the record respectively
 */
function EditManPower(i, cMPId) {
	$("#submitMP").val("Update");

	$.ajax({
		type : "get",
		url : "eonlecGetAManInfo?cMPId=" + cMPId,
		cache : false,
		success : function(response) {

			$("#cMPIdMP").val(cMPId);
			$("#nameMP").val(response[0].name);
			$("#mobile1MP").val(response[0].mobile1);
			$("#fatherMP").val(response[0].father);
			$("#mobile2MP").val(response[0].mobile2);
			$("#roleMP").val(response[0].role1.roleId);
			$("#emailMP").val(response[0].email);
			$("#sourceMP").val(response[0].source);
			$("#QualificationMP").val(response[0].qualification);

			if (response[0].available == 1) {
				$("#availableMP").prop("checked", true);
			}
			$("#remarksMP").val(response[0].remarks);

		},
		error : function() {
			$.alert.open('Error while EditManPower');
		}
	});

}
function delManPower(i, cMPId) {
	if(confirm("Are you sure? Do you want to delete")){
	$.ajax({
		type : "get",
		url : "eonlecDelAManInfo?cMPId=" + cMPId,
		cache : false,
		success : function(response) {
			loadManPower();
		},
		error : function() {
			$.alert.open('Error while delManPower');
		}
	});
}
}
//function exitManPower(){
//	if(confirm("Are you sure? Do you want to exit")){
//		$.ajax({
//			type : "get",
//			url : "lecEditLECRegistration",
//			cache : false,
//			success : function(response) {
//				
//			},
//			error : function() {
//				$.alert.open('Error while delManPower');
//			}
//		});
//}
//}