var data="";

$(document).ajaxComplete(function() {
	  $('[data-toggle="tooltip"]').tooltip();
	});

function onCompTabClick(){

	if($('#stateComp').val()==-1 && $('#state').val()==-1){
		loadStateComp();
		}
	
	if($('#stateComp').val()==-1 && $('#state').val()!=-1){
		  
		  initialLoadStateComp();
		  
		  if($('#city').val()!=-1){
			  initialLoadCityComp(document.LabInfofrm.state);
		  }
		  if($('#centreId').val()!=-1){
			  initialLoadLecComp(document.LabInfofrm.city);
		  }
	  }
}

function onCompStateChange(obj) {
	
	var htmlStr = "<option value=-1>Select</option>";
	$('#compCenterId').html(htmlStr);
	$('#compLabId').html(htmlStr);
	$("#compMatrixTable tbody").html("");	
	hideComputerSysDtl(0);
}


function initialLoadStateComp() {

	var htmlStr = "<option value=-1>Select</option>";
	$.ajax({
		type : "get",
		url : "eonlecGetState",
		cache : false,
		success : function(response) {
			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].stateId + ">"
						+ response[i].stateName + "</option>";
			}
			$('#stateComp').html(htmlStr);
		
			$('#stateComp').val($('#state').val());
		},
		error : function() {
			$.alert.open('Error while load State');
		}
	});
}



 
function initialLoadCityComp(obj) {
	blockU();
	
	var htmlStr = "<option value=-1>Select</option>";
	
		$.ajax({
			type : "get",
			url : "eonlecGetCity?stateId=" + obj.value,
			cache : false,
			success : function(response) {
				unblockU("");
				for (var i = 0; i < response.length; i++) {
					htmlStr += "<option value=" + response[i].cityId + ">"
							+ response[i].cityName + "</option>";
				}

				$('#cityComp').html(htmlStr);
				$('#cityComp').val($('#city').val());
			},
			error : function() {
				unblockU("");
				$.alert.open('Error while load city');
			}
		});
		
}

 
function initialLoadLecComp(obj) {
	blockU();
	var htmlStr = "<option value=-1>Select</option>";
		
	$.ajax({
		type : "get",
		url : "eonlecGetLEC?cityId=" + obj.value,
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].centreId + ">"
						+ response[i].name + "</option>";

			}
			$('#compCenterId').html(htmlStr);
			$('#compCenterId').val($('#centreId').val());
			initialLoadLabs($('#centreId').val());
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load LEC');
		}
	});
	
}

function initialLoadLabs(centerId) {
	
	var htmlStrComp = "<option value=-1>Select</option>";
	
	$.ajax({
		type : "get",
		url : "eonlecGetLabs?centreId=" + centerId,
		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {
				
				if(response[i].noOfComputerinRow>0 && response[i].noOfRows){
				htmlStrComp+= "<option value=" + response[i].labId + ">"
				+ response[i].labName + "</option>";
				}
			}
			$('#compLabId').html(htmlStrComp);
		},
		error : function() {
			$.alert.open('Error while load Labs');
		}
	});
	
}

function loadStateComp() {

	var htmlStr = "<option value=-1>Select</option>";
	$.ajax({
		type : "get",
		url : "eonlecGetState",
		cache : false,
		success : function(response) {
			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].stateId + ">"
						+ response[i].stateName + "</option>";
			}
			$('#stateComp').html(htmlStr);
		},
		error : function() {
			$.alert.open('Error while load State');
		}
	});
}

/*
 * This function is call the controller " lecGetCity" and Get the no of City and
 * Set all the City in the dropDown
 */
function loadCityComp(obj) {
	blockU();
	var htmlStr = "<option value=-1>Select</option>";
	
	if($('#stateComp').val()!=-1){
		$.ajax({
			type : "get",
			url : "eonlecGetCity?stateId=" + obj.value,
			cache : false,
			success : function(response) {
				unblockU("");
				for (var i = 0; i < response.length; i++) {
					htmlStr += "<option value=" + response[i].cityId + ">"
							+ response[i].cityName + "</option>";
				}

				$('#cityComp').html(htmlStr);
			},
			error : function() {
				unblockU("");
				$.alert.open('Error while load city');
			}
		});
		
	}
	
	
}
/*
 * This function is call the controller " lecGetLEC" and Get the no of LEC(local
 * Examinnation Center)and Set all the City in the dropDown.
 */
function loadLECComp(obj) {
	blockU();
	hideComputerSysDtl(0);
	var htmlStrComp = "<option value=-1>Select</option>";
	$('#compLabId').html(htmlStrComp);
	$("#compMatrixTable tbody").html("");
	var htmlStr = "<option value=-1>Select</option>";
	
	if($('#cityComp').val()!=-1){
		
	$.ajax({
		type : "get",
		url : "eonlecGetLEC?cityId=" + obj.value,
		cache : false,
		success : function(response) {
			unblockU("");
			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].centreId + ">"
						+ response[i].name + "</option>";

			}
			$('#compCenterId').html(htmlStr);
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while load LEC');
		}
	});
	}

}


/*
This method loads the computer matrix according the 
*/
function loadCompMatrix(obj){
	blockU();
	var htmStr="";
	var compId="";
	var osId="";
	var ramSizeGb="";
	var hddSize="";
	var processorId="";
	var upsStatus="";
	
	$
	.ajax({
		type : "get",
		url : "eonlecGetCompGrid?labId="+document.form1.compLabId.value,
		cache : false,
		success : function(response) {
			unblockU("");
			var listIndex=0;
			var totalComp=response.noOfRows*response.noOfComputerinRow;
			$('#compMatrix').html("");
			
			$('#compMatrix').append("<tr>");
			$('#compMatrix').append("<td colspan="+response.noOfComputerinRow+1+" ><table align=center><tr><th>Start Computer ID :"+response.compCodeDetailsList[0].computerCode+"</th> <th style='width:100px;'><th>" +
					"<th>End Computer ID :"+response.compCodeDetailsList[totalComp-1].computerCode+"</th></tr>" +
					"</table></td>");
			$('#compMatrix').append("</tr>");
			
			$('#compMatrix').append("<tr>");
			
		
			for (var i = 1; i <= response.noOfRows; i++) {
				
				
				$('#compMatrix').append("<tr>");
				$('#compMatrix').append("<td style='color:#2AB575'>"+"Row No:"+i+"</td>");
				
				for (var j = 0; j < response.noOfComputerinRow; j++){
					
				 compId=response.compCodeDetailsList[listIndex].computerId;
				 compCode=response.compCodeDetailsList[listIndex].computerCode;
				 if(response.compCodeDetailsList[listIndex].osId!=0 && response.compCodeDetailsList[listIndex].ramSizeGb!=0 && response.compCodeDetailsList[listIndex].hddSize!=0 && response.compCodeDetailsList[listIndex].processorId!=0){
					 
					 for(var lookupCounter=0;lookupCounter<response.lookupList.length;lookupCounter++){
							
							if(response.lookupList[lookupCounter].lookupId==response.compCodeDetailsList[listIndex].osId){
								osId=response.lookupList[lookupCounter].lookupName;
							}
							else if(response.lookupList[lookupCounter].lookupId==response.compCodeDetailsList[listIndex].ramSizeGb){
								ramSizeGb=response.lookupList[lookupCounter].lookupName;
							}
							else if(response.lookupList[lookupCounter].lookupId==response.compCodeDetailsList[listIndex].hddSize){
								hddSize=response.lookupList[lookupCounter].lookupName;
							}
							else if(response.lookupList[lookupCounter].lookupId==response.compCodeDetailsList[listIndex].processorId){
								processorId=response.lookupList[lookupCounter].lookupName;
							}
							else if(response.lookupList[lookupCounter].lookupId==response.compCodeDetailsList[listIndex].upsStatus){
								upsStatus=response.lookupList[lookupCounter].lookupName;
							}
						}	
				 }
				 else{
					 osId="NA";
					 ramSizeGb="NA";
					 hddSize="NA";
					 processorId="NA";
					 upsStatus="NA";
				 }
					
					if(response.compCodeDetailsList[listIndex].isAssigned ==1){
						
						$('#compMatrix')
						.append("<td> <input type='text'  data-toggle='tooltip' data-placement='top' data-html='true'  title='"+compCode+"<br>Processor: "+processorId+"<br>OS: "+osId+"<br>RAM: "+ramSizeGb+"<br>HDD: "+hddSize+"<br>UPS Status: "+upsStatus+"' name='"+compId+"' style='background-color: #5cb85c; width:50px; margin:2px; border:tan;color:white;'  value=" + response.compCodeDetailsList[listIndex].computerCode+" readonly>" 
										+ "</td>");
					}
					else{
						
						$('#compMatrix')
						.append("<td><input type='text'  data-toggle='tooltip' data-placement='top' data-html='true' title='"+compCode+"<br>Processor: "+processorId+"<br>OS: "+osId+"<br>RAM: "+ramSizeGb+"<br>HDD: "+hddSize+"<br>UPS Status: "+upsStatus+"' value=" + response.compCodeDetailsList[listIndex].computerCode+" style='width:50px;margin:2px;border:tan;background-color:#F39898;color:white'  readonly>" 
										+ "</td>");
					}
					
					
					
					listIndex++;
				}
				
				$('#compMatrix').append("</tr>");
				//dive show
				
			}
			$(document).ajaxStop($.unblockUI);
			if(obj=="all"){
			
			}
			hideComputerSysDtl(0);
			$("#ManageSysId").show();
			
		},
		error : function() {
			unblockU("");
			$.alert.open('Error while loading Computer Matrix');
		}
	});
}

//Populate computer data in the dropdown
function getCompConfig(obj) {

	var htmlStrOS="<option value=-1>Select</option>";
	var htmlStrHDD="<option value=-1>Select</option>";
	var htmlStrRAM="<option value=-1>Select</option>";
	var htmlStrProc="<option value=-1>Select</option>";
	var htmlStrUpsStatus="<option value=-1>Select</option>";
	
	$
	.ajax({
		type : "get",
		url : "eonlecGetCompDetails",
		cache : false,
		success : function(response) {
			
			for (var i = 0; i < response.length; i++) {
				
				if(response[i].lookupTypeId==1){
					
					htmlStrOS+="<option value="+response[i].lookupId+">"+response[i].lookupName+"</option>";
				}
				else if(response[i].lookupTypeId==2){
					
					htmlStrHDD+="<option value="+response[i].lookupId+">"+response[i].lookupName+"</option>";
				}
				else if(response[i].lookupTypeId==3){
					
					htmlStrRAM+="<option value="+response[i].lookupId+">"+response[i].lookupName+"</option>";
				}
				else if(response[i].lookupTypeId==4){
					
					htmlStrProc+="<option value="+response[i].lookupId+">"+response[i].lookupName+"</option>";
				}
				else if(response[i].lookupTypeId==5){
					
					htmlStrUpsStatus+="<option value="+response[i].lookupId+">"+response[i].lookupName+"</option>";
				}

				
			}
			
			if(obj=="all"){
				
				$('#osId').html(htmlStrOS);
				$('#ramSizeGb').html(htmlStrRAM);
				$('#hddSize').html(htmlStrHDD);
				$('#processorId').html(htmlStrProc);
				$('#upsStatus').html(htmlStrUpsStatus);
			
			}
			else if(obj=="byrow"){
			
				$('#rowOs').html(htmlStrOS);
				$('#rowRAM').html(htmlStrRAM);
				$('#rowHDD').html(htmlStrHDD);
				$('#rowProc').html(htmlStrProc);
				$('#rowUpsStatus').html(htmlStrUpsStatus);
				
			}
			else if(obj=="byrange"){
				
				$('#rangeOs').html(htmlStrOS);
				$('#rangeRAM').html(htmlStrRAM);
				$('#rangeHDD').html(htmlStrHDD);
				$('#rangeProc').html(htmlStrProc);
				$('#rangeUpsStatus').html(htmlStrUpsStatus);
				
			}
			else if(obj=="ind"){
				
				$('#indivOs').html(htmlStrOS);
				$('#indivRAM').html(htmlStrRAM);
				$('#indivHDD').html(htmlStrHDD);
				$('#indivProc').html(htmlStrProc);
				$('#indivUpsStatus').html(htmlStrUpsStatus);
				
			}
			
			
			
		},
		error : function() {
			$.alert.open('Error while load city');
		}
	});

} 

function getComputerInfo(obj){
	
	var htmlStrByRow="<option value=-1>Select</option>";
	var htmlStrIndividual="<option value=-1>Select</option>";
	var htmlStrByRange="<option value=-1>Select</option>";

	$
	.ajax({
		type : "get",
		url : "eonlecGetComputerInfo?compLabId="+document.form1.compLabId.value+"&compCenterId="+document.form1.compCenterId.value,
		cache : false,
		success : function(response) {
			
			var rowNo=0;
	
			for (var i = 0; i < response.length; i++) {
				
			
				if(obj=="byrow"){

					if(response[i].rowNo !=rowNo){
						rowNo=response[i].rowNo;
						htmlStrByRow+="<option value="+rowNo+">"+rowNo+"</option>";
						}
					}
				
				else if(obj=="ind"){
					htmlStrIndividual+="<option value="+response[i].computerId+">"+response[i].computerCode+"</option>";
				}
				
				else if(obj=="byrange"){
					data=response;
					htmlStrByRange+="<option value="+response[i].computerId+">"+response[i].computerCode+"</option>";
				}
				
				}
			
			$('#rowNo').html(htmlStrByRow);
			$('#computerId').html(htmlStrIndividual);
			$('#1stComp').html(htmlStrByRange);
				
			$(document).ajaxStop($.unblockUI);
			
		},
		
		error : function() {
			
			$(document).ajaxStop($.unblockUI);
			$.alert.open('Error while loading Computer Matrix');
		}
	});
}

function toSave(mode)
{

//By All
	 if(mode==1)
		{
		 var msgArray = ["Please select OS type.","Please select RAM size.","Please select HDD size","Please select proccessor type","Please select UPS status"];
		 var checkArray = ["osId","ramSizeGb","hddSize","processorId","upsStatus"];
		 
		 if(!validateFields(checkArray, 1, msgArray))
			{
			return false;
			}
		 else
			 {
			 if(!confirm("Are you sure? you are going to assign the selected configuration for all"))
			 {
			 return false;
			 }
			 }
	
			var frm = $('#form1');	
			
			    $.ajax({
			        type: frm.attr('method'),
			        url: frm.attr('action'),
			        data: frm.serialize(),
			        success: function (response) {
			           
			        	if(response==0){
			        		
			        		loadCompMatrix('all');
			        		getCompConfig('all');
			        		$.alert.open("You have successfully assigned the values for all");
			        	}
			        	
			        },
					error : function() {
						$.alert.open('Error while assigning the value');
					}
			    });

			   
			

		}  
	
//By Row	
	 else if(mode==2)
		{
		
		 var msgArray = ["Please select Row No.","Please select OS type.","Please select RAM size.","Please select HDD size","Please select proccessor type","Please select UPS status"];
		 var checkArray = ["rowNo","osId","ramSizeGb","hddSize","processorId","upsStatus"];
		
		 
		 if(!validateFields(checkArray, 2, msgArray))
			{
			return false;
			}
		 else
			 {
			 if(!confirm("Are you sure? you are going to assign the selected configuration for the row"))
			 {
			 return false;
			 }
			 }
			 
			document.form2.compCenterId.value=document.form1.compCenterId.value;
			document.form2.compLabId.value=document.form1.compLabId.value;
			var frm = $('#form2');	
			    $.ajax({
			        type: frm.attr('method'),
			        url: frm.attr('action'),
			        data: frm.serialize(),
			        success: function (response) {
			           
			        	if(response==0){
			        		
			        		loadCompMatrix('byrow');
			        		getComputerInfo('byrow');
			        		getCompConfig('byrow');
			        		$.alert.open("You have successfully assigned the values for the row");
			        	}
			        	
			        },
					error : function() {
						$.alert.open('Error while assigning the value');
					}
			    });

			   
			

		}  
//By Range	
	  else if(mode==3){
		  var msgArray = ["Please select start computer","Please select end computer","Please select OS type.","Please select RAM size.","Please select HDD size","Please select proccessor type","Please select UPS status"];
		  var checkArray = ["startCompRange","endCompRange","osId","ramSizeGb","hddSize","processorId","upsStatus"];
		 
		  if(!validateFields(checkArray, 3, msgArray))
			{
			return false;
			}
		 else
			 {
			 if(!confirm("Are you sure? you are going to assign the selected configuration for selected range"))
			 {
			 return false;
			 }
			 }
			
		  var frm = $('#form3');
			
		    $.ajax({
		        type: frm.attr('method'),
		        url: frm.attr('action'),
		        data: frm.serialize(),
		        success: function (response) {
		           
		        
		        		loadCompMatrix('byrange');
		        		getComputerInfo('byrange');
		        		$('#2ndComp').html("<option value=0>Select</option>");
		        		getCompConfig('byrange');
		        		$.alert.open("You have successfully assigned the values for the range");
		        	
		        },
				error : function() {
					$.alert.open('Error while assigning the value');
				}
		    });
	}
//By Individual 	 
	else if(mode==4){
		 var msgArray = ["Please select computer","Please select OS type.","Please select RAM size.","Please select HDD size","Please select proccessor type","Please select UPS status"];
		 var checkArray = ["computerId","osId","ramSizeGb","hddSize","processorId","upsStatus"];
		
		if(!validateFields(checkArray, 4, msgArray))
		{
		return false;
		}
	 else
		 {
		 if(!confirm("Are you sure? you are going to assign the selected configuration for selected computer"))
		 {
		 return false;
		 }
		 }
		
		var frm = $('#form4');	
	    $.ajax({
	        type: frm.attr('method'),
	        url: frm.attr('action'),
	        data: frm.serialize(),
	        success: function (response) {
	           
	        		loadCompMatrix('ind');
	        		getComputerInfo('ind');
	        		getCompConfig('ind');
	        		$.alert.open("You have successfully assigned the values for the selected Computer");
	        	
	        	
	        },
			error : function() {
				$.alert.open('Error while assigning the value');
			}
	    });
	}
}


 function toClearAll(){
	 
	 var msgArray = ["Please select OS type"];
	 var checkArray = ["osId"];
	 
	 if(!validateFields(checkArray, 1, msgArray))
		{
		return false;
		}
	 else
		 {
		 if(!confirm("Are you sure? you are going to delete all assigned configuration"))
		 {
		 return false;
		 }
		 }
	
	var compCenterId=document.form1.compCenterId.value;
	var compLabId=document.form1.compLabId.value;
	
	$
	.ajax({
		type : "get",
		url : "eonclearCompConfig?centreId="+compCenterId+"&compLabId="+compLabId+"",
		cache : false,
		success : function(response) {
			
			loadCompMatrix('all');
    		getCompConfig('all');
			$.alert.open("Cleared all Computer Configuration");
		},
		error : function() {
			$.alert.open('Error while load city');
		}
	});
}

 
function toClearByRow(){
	
	var msgArray = ["Please select Row No."];
	var checkArray = ["rowNo"];
	

	 if(!validateFields(checkArray, 2, msgArray))
		{
		return false;
		}
	 else
		 {
		 if(!confirm("Are you sure? you are going to delete the assigned configuration for the row"))
		 {
		 return false;
		 }
		 }
	 
	var compCenterId=document.form1.compCenterId.value;
	var compLabId=document.form1.compLabId.value;
	var rowNo = document.form2.rowNo.value;
	$
	.ajax({
		type : "get",
		url : "eonclearCompConfigByRow?centreId="+compCenterId+"&compLabId="+compLabId+"&rowNo="+rowNo+"",
		cache : false,
		success : function(response) {
			
			loadCompMatrix('byrow');
    		getComputerInfo('byrow');
    		getCompConfig('byrow');
			$.alert.open("Cleared By Row Computer Configuration");
		},
		error : function() {
			$.alert.open('Error while load city');
		}
	});
}

function toClearByRange(){
	
	var msgArray = ["Please select start computer","Please select end computer"];
	var checkArray = ["startCompRange","endCompRange"];
	 
	  if(!validateFields(checkArray, 3, msgArray))
		{
		return false;
		}
	 else
		 {
		 if(!confirm("Are you sure? you are going to delete the assigned configuration for the selected range"))
		 {
		 return false;
		 }
		 } 
	
	 
	var startRange=document.form3.startCompRange.value;
	var endRange=document.form3.endCompRange.value;
	
	$
	.ajax({
		type : "get",
		url : "eonclearCompConfigByRange?startCompRange="+startRange+"&endCompRange="+endRange+"",
		cache : false,
		success : function(response) {
			
			loadCompMatrix('byrange');
    		getComputerInfo('byrange');
    		$('#2ndComp').html("<option value=0>Select</option>");
    		getCompConfig('byrange');
			$.alert.open("Cleared By Range Computer Configuration");
		},
		error : function() {
			$.alert.open('Error while load city');
		}
	}); 
}


function toClearByIndiv(){
	
	var msgArray = ["Please select computer"];
	var checkArray = ["computerId"];
	 
	  if(!validateFields(checkArray, 4, msgArray))
		{
		return false;
		}
	 else
		 {
		 if(!confirm("Are you sure? you are going to delete the assigned configuration for the selected computer"))
		 {
		 return false;
		 }
		 } 

	
	var compId=document.form4.computerId.value;
	
	$
	.ajax({
		type : "get",
		url : "eonclearCompConfigByIndiv?compId="+compId+"",
		cache : false,
		success : function(response) {
			
			loadCompMatrix('ind');
    		getComputerInfo('ind');
    		getCompConfig('ind');
			$.alert.open("Cleared Individual Computer Configuration");
		},
		error : function() {
			$.alert.open('Error while load city');
		}
	}); 
}
 
function loadComputerRange(obj){
	
	var size=data.length;
	var j=0;
	var html2ndCompStr="<option value=-1>Select</option>";
	
	for(var i=0;i<size;i++){
		
		if(data[i].computerId==obj.value)
			{
				j=i+1;
				break;
			}
	}
	
	if(j<(size)){
		
		while(j<size){
			html2ndCompStr+="<option value="+data[j].computerId+">"+data[j].computerCode+"</option>";
			j++;
		}
		$('#2ndComp').html(html2ndCompStr);
	}
	else if(j>=(size-1)){
		
		$.alert.open("Please select Appropriate Range");
	}
	
}

function validateAll(){
	
	$
	.ajax({
		type : "get",
		url : "eonlecGetComputerInfo?compLabId="+document.form1.compLabId.value+"&compCenterId="+document.form1.compCenterId.value,
		cache : false,
		success : function(response) {
			
			var assignedCompCounter=0;
			var totalComp=response.length;
			
			for (var i = 0; i < response.length; i++) {
				
				if(response[i].isAssigned==1){
					assignedCompCounter++;
				}
			}
				if(assignedCompCounter==totalComp){
					$.alert.open("All computers are assigned already,performing this operation would update all the computers");
				}
				else if(assignedCompCounter>0){
					
					$.alert.open("Some computers are assigned already,performing this operation would update all the computers");
				}
			
		},
		error : function() {
			$.alert.open('Error while load city');
		}
	});
}

function validateRow(obj){
	
	$
	.ajax({
		type : "get",
		url : "eonlecGetCompInfoByRow?compLabId="+document.form1.compLabId.value+"&compCenterId="+document.form1.compCenterId.value+"&rowNo="+obj.value,
		cache : false,
		success : function(response) {
			
			var assignedCompCounter=0;
			var totalComp=response.length;
			
			for (var i = 0; i < response.length; i++) {
				
				if(response[i].isAssigned==1){
					assignedCompCounter++;
				}
			}
			
			if(assignedCompCounter==totalComp){
				$.alert.open("For row "+response[0].rowNo+" all computers are assigned already,performing this operation would update all the computers for the row");
			}
			else if (assignedCompCounter>0){
				
				$.alert.open("For row "+response[0].rowNo+" some computers are assigned already,performing this operation would update all the computers for the row");
			}
		
			
		},
		error : function() {
			$.alert.open('Error while load city');
		}
	});
}

function validateRange(obj){
	
	var startRange=document.form3.startCompRange.value;
	var endRange=document.form3.endCompRange.value;
	
	$
	.ajax({
		type : "get",
		url : "eonlecGetCompInfoByRange?startCompRange="+startRange+"&endCompRange="+endRange+"",
		cache : false,
		success : function(response) {
			
			var assignedCompCounter=0;
			var totalComp=response.length;
			
			for (var i = 0; i < response.length; i++) {
				
				if(response[i].isAssigned==1){
					assignedCompCounter++;
				}
			}
			
			if(assignedCompCounter==totalComp){
				$.alert.open("For the selected range All computers are assigned already,Assign and Clear button would update all the computers in the range");
			}
			else if (assignedCompCounter>0){
				
				$.alert.open("For the selected range Some computers are assigned already,Assign and Clear button would update all the computers in the range");
			}
		
			
		},
		error : function() {
			$.alert.open('Error while load city');
		}
	});
}

function validateInd(obj){
	
	
	$
	.ajax({
		type : "get",
		url : "eonlecGetCompInfoByInd?compId="+obj.value+"",
		cache : false,
		success : function(response) {
			
			var assignedCompCounter=0;
			
				if(response[0].isAssigned==1){
					assignedCompCounter++;
					$.alert.open("The selected computer is assigned already,Assign and Clear button would update the computer configuration");
					}
		},
		error : function() {
			$.alert.open('Error while load city');
		}
	});
}

function hideComputerSysDtl(mode)
{
	if(mode==0)
		{
			$("#allTabId").hide();
			$("#byRowTabId").hide();
			$("#byRangeTabId").hide();
			$("#byIndTabId").hide();
			$("#ManageSysId").hide();
		}
	else
		{
			$("#allTabId").show();
			$("#byRowTabId").show();
			$("#byRangeTabId").show();
			$("#byIndTabId").show();
			$("#ManageSysId").show();
		}
}