$(document).ready(function(){
	setTimeout(function(){$('#tblData').bootstrapTable({
		pagination: true,
// 		search: true,
		height: 500,		
	});},2000);
	
	
	
	 $('#checkAllAdd').click(function () {    
	     $('.addClass').prop('checked', this.checked);    
	 });
	 $('#checkAllUpdate').click(function () {    
	     $('.updateClass').prop('checked', this.checked);    
	 });
	 $('#checkAllRead').click(function () {    
	     $('.readClass').prop('checked', this.checked);    
	 });
	 $('#checkAllDelete').click(function () {    
	     $('.deleteClass').prop('checked', this.checked);      
	 });
});
function loadModule() {


		$.ajax({type : "get",
					url : "eonroleLoadModule",
					cache : false,
					success : function(response) {
						
						var strHtml = "<table>";
						for (var i = 0; i < response.length; i++) {
							strHtml += "<tr><td><input type=checkbox onclick=loadSubModule() name=moduleId id=moduleId value='"
									+ response[i].moduleId
									+ "'>"
									+ response[i].moduleName + "</td></tr>";
						}
						strHtml += "</table>";
						
						$("#divModuleId").html(strHtml);
					},
					error : function() {
						$.alert.open("error");
					}
				});
	}
function loadModuleForUserPermission() {
$("#divModuleIdForUserPermission").hide();
		$.ajax({
					type : "get",
					url : "eonroleLoadModule",
					cache : false,
					success : function(response) {

						var strHtml = "<table>";
						for (var i = 0; i < response.length; i++) {
							strHtml += "<tr><td><input type=checkbox onclick=loadSubModuleForUserPermission() name=moduleId11 id=moduleId11 value='"
									+ response[i].moduleId
									+ "'>"
									+ response[i].moduleName + "</td></tr>";
						}
						strHtml += "</table>";

						$("#divModuleIdForUserPermission").html(strHtml);
					},
					error : function() {
						$.alert.open("error");
					}
				});
	}
	function loadModuleAccToRoleType(obj){
		
		$.ajax({
			type : "get",
			url : "eonloadModuleAccToRoleType?roleTypeId="+obj.value,
			cache : false,
			success : function(response) {
				$("#divModuleId").show();
				var strHtml = "<table>";
				for (var i = 0; i < response.length; i++) {
					strHtml += "<tr><td><input type=checkbox onclick=loadSubModule() name=moduleId id=moduleId value='"
							+ response[i].module.moduleId
							+ "'>"
							+ response[i].module.moduleName + "</td></tr>";
				}
				strHtml += "</table>";

				$("#divModuleId").html(strHtml);
			},
			error : function() {
				unblockU("");
				$.alert.open("error loadModuleAccToRoleType");
			}
		}); 
		
	}
	function loadSubModule() {
		 $("#tblmodList").show();
		$("#bodySubModuleId").html("");
		
		var obj = document.getElementsByName("moduleId");
		var moduleIds = [];
		for (var i = 0; i < obj.length; i++) {
			if (obj[i].checked == true) {
				moduleIds.push(obj[i].value);
			}
		}
		$
				.ajax({
					type : "get",
					url : "eonroleLoadSubModule?moduleId=" + moduleIds,
					cache : false,
					success : function(response) {
                         var k=0;
						var strHtml = "";
						for (var i = 0; i < response.length; i++) {
							for (var j = 0; j < response[i].subModuleList.length; j++) {

								strHtml += "<tr>"
										+ "<td>"
										+ response[i].moduleName
										+ "</td>"
										+ "<td>"
										+ response[i].subModuleList[j].subModuleName
										+ "<input name=subModuleIdTemp type=hidden value='"+response[i].subModuleList[j].subModuleId+"'><input name=moduleIdTemp type=hidden value='"+response[i].moduleId+"'></td>"
										+ "<td><input type=checkbox  class=addClass name=addTemp1 id=add value='0'><input name=addTemp type=hidden value='0'></td>"
										+ "<td><input type=checkbox  class=updateClass name=updateTemp1 id=update value='0'><input name=updateTemp type=hidden value='0'></td>"
										+ "<td><input type=checkbox  class=readClass name=readTemp1 id=read value='0'><input name=readTemp type=hidden value='0'></td>"
										+ "<td><input type=checkbox  class=deleteClass name=deletTemp1 id=delet value='0'><input name=deletTemp type=hidden value='0'></td>"
										+ "</tr>";

							}
							k++;
							$("#bodySubModuleId").html(strHtml);
							loadSubModuleForEdit();
						}

					},
					error : function() {
						$.alert.open("error");
					}
				});
	}
	function refreshSubModuleGrid() {
		
		
		
		$.ajax({
					type : "get",
					url : "eonroleCustomeRole",
					cache : false,
					success : function(response) {
                  
					},
					error : function() {
						$.alert.open("error");
					}
				});
	}
	function loadSubModuleForUserPermission() {
		$("#bodySubModuleIdForUserPermission").html("");
		
		var obj = document.getElementsByName("moduleId11");
		var moduleIds = [];
		for (var i = 0; i < obj.length; i++) {
			if (obj[i].checked == true) {
				moduleIds.push(obj[i].value);
			}
		}
		$
				.ajax({
					type : "get",
					url : "eonroleLoadSubModule?moduleId=" + moduleIds,
					cache : false,
					success : function(response) {
                         var k=0;
						var strHtml = "";
						for (var i = 0; i < response.length; i++) {
							for (var j = 0; j < response[i].subModuleList.length; j++) {

								strHtml += "<tr>"
										+ "<td>"
										+ response[i].moduleName
										+ "</td>"
										+ "<td>"
										+ response[i].subModuleList[j].subModuleName
										+ "<input name=subModuleIdTemp11 type=hidden value='"+response[i].subModuleList[j].subModuleId+"'><input name=moduleIdTemp11 type=hidden value='"+response[i].moduleId+"'></td>"
										+ "<td><input type=checkbox class=add2Class  name=addTemp2  id=add2 value='0'><input name=addTemp11 type=hidden value='0'></td>"
										+ "<td><input type=checkbox  class=update2Class  name=updateTemp2  id=update2 value='0'><input name=updateTemp11 type=hidden value='0'></td>"
										+ "<td><input type=checkbox class=read2Class   name=readTemp2  id=read2 value='0'><input name=readTemp11 type=hidden value='0'></td>"
										+ "<td><input type=checkbox  class=delet2Class  name=deletTemp2  id=delet2 value='0'><input name=deletTemp11 type=hidden value='0'></td>"
										+ "</tr>";

							}
							k++;
							$("#bodySubModuleIdForUserPermission").html(strHtml);
							loadSubModuleForEditForUserPermission();
						}

					},
					error : function() {
						$.alert.open("error");
					}
				});
	}

	function loadUsers() {
		blockU();
		 var lUserDivObj = document.getElementById("lUserDiv");
		var rUserDivObj = document.getElementById("rUserDiv");

		//lUserDivObj.innerHTML = resArr[0];
		//rUserDivObj.innerHTML = resArr[1];
		var roleIds = [];
		roleIds.push($("#roleId").val());
	
		$.ajax({
					type : "get",
					url : "eonroleLoadUser?roleId="+roleIds,
					cache : false,
					success : function(response) {
						unblockU("");
						var strHtml = "<select name='frmUserId' size='10' multiple class = 'textarea'>";
						for (var i = 0; i < response.length; i++) {
							strHtml+="<option value='"+response[i].userId+"'>"+response[i].userName+"</option>"
						}
						strHtml+="</select>";
						lUserDivObj.innerHTML = strHtml;
					},
					error : function() {
						unblockU("");
						$.alert.open("error loadUsers");
					}
				}); 

	}
	function loadRightUsers() {
		blockU();
		var rUserDivObj = document.getElementById("rUserDiv");
		var roleIds = [];
		roleIds.push($("#roleId").val());
		$.ajax({
					type : "get",
					url : "eonroleLoadUserRight?roleId="+roleIds,
					cache : false,
					success : function(response) {
						unblockU("");
						var strHtml = "<select name='toUserId' size='10' multiple class = 'textarea'>";
						for (var i = 0; i < response.length; i++) {
							strHtml+="<option value='"+response[i].userId.userId+"'>"+response[i].userId.userName+"</option>"
						}
						strHtml+="</select>";
						rUserDivObj.innerHTML = strHtml;
					},
					error : function() {
						unblockU("");
						$.alert.open("error loadRightUsers");
					}
				}); 

	}
	function loadRole() {
		
		blockU();
		$.ajax({
					type : "get",
					url : "eonroleLoadRole",
					cache : false,
					success : function(response) {
						unblockU("");
						var strHtml = "<select class='form-control' name='roleId' id='roleId' onchange='loadUsers();loadRightUsers();loadModuleForEditForUserPermission(this);'>";
						strHtml += "<option value='-1'>select</option>"
						for (var i = 0; i < response.length; i++) {
							strHtml+="<option value='"+response[i].roleId+"'>"+response[i].roleName+"</option>"
						}
						strHtml+="</select>";
						$("#divRoleId").html(strHtml);
						
					},
					error : function() {
						unblockU("");
						$.alert.open("error loadRole");
					}
				}); 

	}
	function loadModuleForEdit(obj)
	{
		blockU();
			
		//onclick=loadSubModule() name=moduleId
	    var	moduleId = document.getElementsByName("moduleId");
	    for (var i = 0; i < moduleId.length; i++) {
					moduleId[i].checked=false;	
			}
		$.ajax({
			type : "get",
			url : "eonroleLoadRoleModuelMap?roleId="+obj.value,
			cache : false,
			success : function(response) {
				unblockU("");
				for (var i = 0; i < moduleId.length; i++) {
					

					for (var j = 0; j < response.length; j++) {
						
						if(moduleId[i].value==response[j].moduleId)
						{
							
							moduleId[i].checked=true;
							
							break;
						}
					}
				}
				loadSubModule();
			},
			error : function() {
				unblockU("");
				$.alert.open("error roleLoadRoleModuelMap");
			}
		}); 
	}
	function loadModuleForEditForUserPermission(obj)
	{
		blockU();
			
		//onclick=loadSubModule() name=moduleId
	    var	moduleId = document.getElementsByName("moduleId11");
	    for (var i = 0; i < moduleId.length; i++) {
					moduleId[i].checked=false;	
			}
		$.ajax({
			type : "get",
			url : "eonroleLoadRoleModuelMap?roleId="+obj.value,
			cache : false,
			success : function(response) {
				unblockU("");
				for (var i = 0; i < moduleId.length; i++) {
					
					for (var j = 0; j < response.length; j++) {
						
						if(moduleId[i].value==response[j].moduleId)
						{
							
							moduleId[i].checked=true;
							
							break;
						}
					}
				}
				loadSubModuleForUserPermission();
			},
			error : function() {
				unblockU("");
				$.alert.open("error roleLoadRoleModuelMap");
			}
		}); 
	}
	
// function loadSubModuleForUserPermission() {
		
// 		$("#bodySubModuleIdForUserPermission").html("");
// 		var obj = document.getElementsByName("moduleId");
// 		var moduleIds = [];
// 		for (var i = 0; i < obj.length; i++) {
// 			if (obj[i].checked == true) {
// 				moduleIds.push(obj[i].value);
// 			}
// 		}
// 		$
// 				.ajax({
// 					type : "get",
// 					url : "eonroleLoadSubModule?moduleId=" + moduleIds,
// 					cache : false,
// 					success : function(response) {
//                          var k=0;
// 						var strHtml = "";
// 						for (var i = 0; i < response.length; i++) {
// 							for (var j = 0; j < response[i].subModuleList.length; j++) {

// 								strHtml += "<tr>"
// 										+ "<td>"
// 										+ response[i].moduleName
// 										+ "</td>"
// 										+ "<td>"
// 										+ response[i].subModuleList[j].subModuleName
// 										+ "<input name=subModuleIdTemp type=hidden value='"+response[i].subModuleList[j].subModuleId+"'><input name=moduleIdTemp type=hidden value='"+response[i].moduleId+"'></td>"
// 										+ "<td><input type=checkbox   name=addTemp1 id=add value='0'><input name=addTemp type=hidden value='0'></td>"
// 										+ "<td><input type=checkbox   name=updateTemp1 id=update value='0'><input name=updateTemp type=hidden value='0'></td>"
// 										+ "<td><input type=checkbox   name=readTemp1 id=read value='0'><input name=readTemp type=hidden value='0'></td>"
// 										+ "<td><input type=checkbox   name=deletTemp1 id=delet value='0'><input name=deletTemp type=hidden value='0'></td>"
// 										+ "</tr>";

// 							}
// 							k++;
							
// 							$("#bodySubModuleIdForUserPermission").html(strHtml);
// 							loadSubModuleForEditForUserPermission();
// 						}

// 					},
// 					error : function() {
// 						$.alert.open("error");
// 					}
// 				});
// 	}
	
function loadSubModuleForEditForUserPermission()
{
	//onclick=loadSubModule() name=moduleId
    var	subModuleIdTemp = document.getElementsByName("subModuleIdTemp11");
    var addTemp = document.getElementsByName("addTemp2");
	var updateTemp = document.getElementsByName("updateTemp2");
	var readTemp = document.getElementsByName("readTemp2");
	var deletTemp = document.getElementsByName("deletTemp2");
   
	$.ajax({
		type : "get",
		url : "eonroleLoadRoleModuelMap?roleId="+$("#roleId").val(),
		cache : false,
		success : function(response) {	
			for (var i = 0; i < subModuleIdTemp.length; i++) {
				
				for (var j = 0; j < response.length; j++) {
					if(subModuleIdTemp[i].value==response[j].subModuleId)
						{
						
							if(response[j].add==1)  
							{
								addTemp[i].checked=true;
								addTemp[i].value=1;
							}

							if(response[j].update==1) 
							{
								updateTemp[i].checked=true;
								updateTemp[i].value=1;
							}
							if(response[j].delet==1)  
							{
								deletTemp[i].checked=true;
								deletTemp[i].value=1;
							}
							if(response[j].read==1)   
							{
								readTemp[i].checked=true;
								readTemp[i].value=1;
							}
							break;
						}					
				}
				if(addTemp[i].value!=1){
					addTemp[i].disabled=true;
				}
				if(updateTemp[i].value!=1){
					updateTemp[i].disabled=true;
				}
				if(readTemp[i].value!=1){
					readTemp[i].disabled=true;
				}
				if(deletTemp[i].value!=1){
					deletTemp[i].disabled=true;
				}
			}
			
			
		},
		error : function() {
			$.alert.open("error roleLoadRoleModuelMapforUserPermission");
		}
	}); 
}
	
	
	
	function loadSubModuleForEdit()
	{
		//onclick=loadSubModule() name=moduleId
	    var	subModuleIdTemp = document.getElementsByName("subModuleIdTemp");
	    var addTemp = document.getElementsByName("addTemp1");
		var updateTemp = document.getElementsByName("updateTemp1");
		var readTemp = document.getElementsByName("readTemp1");
		var deletTemp = document.getElementsByName("deletTemp1");
	   
		$.ajax({
			type : "get",
			url : "eonroleLoadRoleModuelMap?roleId="+$("#roleName").val(),
			cache : false,
			success : function(response) {	
				for (var i = 0; i < subModuleIdTemp.length; i++) {
					
					for (var j = 0; j < response.length; j++) {
						if(subModuleIdTemp[i].value==response[j].subModuleId)
							{
							
								if(response[j].add==1)  
								{
									addTemp[i].checked=true;
								}
								if(response[j].update==1) 
								{
									updateTemp[i].checked=true;
								}
								if(response[j].delet==1)  
								{
									deletTemp[i].checked=true;
								}
								if(response[j].read==1)   
								{
									readTemp[i].checked=true;
								}
								break;
							}
					}
				}
			},
			error : function() {
				$.alert.open("error roleLoadRoleModuelMap");
			}
		}); 
	}
	
	function loadRoleTabOne() {
		$("#divAbbrRoleId1").hide();
		$("#divRoleType").hide();
		$.ajax({
					type : "get",
					url : "eonroleLoadRole",
					cache : false,
					success : function(response) {

						var strHtml = "<select class='form-control' name='roleName' id='roleName' onchange='loadModuleForEdit(this);'>";
						strHtml += "<option value='-1'>select</option>"
						for (var i = 0; i < response.length; i++) {
							strHtml+="<option value='"+response[i].roleId+"'>"+response[i].roleName+"</option>"
						}
						strHtml+="</select>";
						$("#divRoleId1").html(strHtml);
						
					},
					error : function() {
						$.alert.open("error loadRole");
					}
				}); 

	}

	function toSave() {
		
		var flag = false;
		var addTemp = document.getElementsByName("addTemp1");
		var updateTemp = document.getElementsByName("updateTemp1");
		var readTemp = document.getElementsByName("readTemp1");
		var deletTemp = document.getElementsByName("deletTemp1");
		for (var i = 0; i < addTemp.length; i++) {
			if (addTemp[i].checked == true || updateTemp[i].checked == true
					|| readTemp[i].checked == true
					|| deletTemp[i].checked == true) {
				flag = true;
			}
		
				if (addTemp[i].checked == true)
				{
				document.getElementsByName("addTemp")[i].value="1";
				}
//			
				if (updateTemp[i].checked == true)
				{
				document.getElementsByName("updateTemp")[i].value="1";
				}
//				
				if (readTemp[i].checked == true)
				{
				document.getElementsByName("readTemp")[i].value="1";
				}
//				
				if (deletTemp[i].checked == true)
				{
				document.getElementsByName("deletTemp")[i].value="1";
				}
		}
		if ($("#roleName").val() == "") {
			$.alert.open("Please enter Role Name");
			flag = false;
		}
		else if($("#abbrName").val()==""){
			$.alert.open("Please enter the Abbreviation Name");
		}
		else if($("#roleType selected").val()==-1){
			$.alert.open("Please select the RoleType");
		}
		else if (!flag) {
			$.alert.open("Please checked at least one Permission");
		}
		if($("#roleType selected").val()==2){
			$("#roleType").val("1");
		}
		if($("#roleType selected").val()==3){
			$("#roleType").val("0");
		}
//		
		if (flag && confirm("You are going to create new role. Are you sure?")) {
			
			document.form1.submit();
		}
	}
	
	function saveForm2() {
		
		var flag = true;
		var addTemp = document.getElementsByName("addTemp2");
		var updateTemp = document.getElementsByName("updateTemp2");
		var readTemp = document.getElementsByName("readTemp2");
		var deletTemp = document.getElementsByName("deletTemp2");
		for (var i = 0; i < addTemp.length; i++) {
			if (addTemp[i].checked == true || updateTemp[i].checked == true
					|| readTemp[i].checked == true
					|| deletTemp[i].checked == true) {
				flag = true;
			}
				if (addTemp[i].checked == true)
				{
				document.getElementsByName("addTemp11")[i].value="1";
				}
			
				if (updateTemp[i].checked == true)
				{
				document.getElementsByName("updateTemp11")[i].value="1";
				}
				
				if (readTemp[i].checked == true)
				{
				document.getElementsByName("readTemp11")[i].value="1";
				}
				
				if (deletTemp[i].checked == true)
				{
				document.getElementsByName("deletTemp11")[i].value="1";
				}
		}
		
		var toUserId = document.getElementsByName("toUserId");
		var totCount = selectListValue(document.form2.toUserId);
		if ($("#roleId").val() == "-1") {
			$.alert.open("Please select Role Name");
			flag = false;
		}
		else if(totCount == 0)
		{
			$.alert.open("No To User to save");
			flag = false;
		}
		 else if(toUserId.length==0)
		{
			$.alert.open("Please select User");
			flag = false;
		} 
		else if (flag && confirm("All previous added user will be deleted. Are you sure?")) {
 			
			document.form2.submit();
		}
	}
	
	
	
	function checkDuplicateRole(obj)
	{
		blockU();
		$.ajax({
			type : "get",
			url : "eonroleCheckDuplicateRole?roleName="+obj.value,
			cache : false,
			success : function(response) {
				unblockU("");
			if(response=="1")
				{
				
				$.alert.open("This Role already exist.Please enter other Role");
				obj.value="";
				}
				
			},
			error : function() {
				unblockU("");
				$.alert.open("error checkDuplicateRole");
			}
		}); 
		
	}

	function showTextBox(obj)
	{
		 $("#tblmodList").hide();
		refreshSubModuleGrid();
		if(obj.checked==true)
			{
			$("#divModuleId").hide();
			$("#divRoleId1").html("<input class='form-control' type='text' name='roleName' id='roleName' onblur='checkDuplicateRole(this)'>");
			$("#divAbbrRoleId1").show();
			$("#divRoleType").show();
			$("#isnew").val("1");
			}
		else
			{
			$("#divModuleId").show();
			loadRoleTabOne();
			$("#divAbbrRoleId1").hide();
			$("#divRoleType").hide();
			$("#isnew").val("0");
			}
	}
	
	function loadRoleType(){
		
		var strhtml="<option value=-1>Select</option>";
		$.ajax({
			type : "get",
			url : "eonLoadRoleType",
			cache : false,
			success : function(response) {
				for(var i=0;i<response.length;i++){
					strhtml+="<option value="+response[i].roleTypeId+">"+response[i].roleTypeName+"</option>"
				}
				$("#roleType").html(strhtml);
			},
			error : function() {
				unblockU("");
				$.alert.open("error loadRoleType");
			}
		}); 
		
			}
