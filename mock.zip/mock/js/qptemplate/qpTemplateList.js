function loadQPTemplateRegistration(){
	document.loadQP.submit();
}
function loadEcb() {
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadEcb",
		cache : false,
		success : function(response) {
			var strHtml = "";
			jQuery.each(response, function(i, val) {
				strHtml += "<option value='" + val.ecbId + "'>" + val.ecbName
						+ "</option>";
			});
			$('#ecbId').html(strHtml);
			loadExam();
		},
		error : function() {
			$.alert.open('Error while loading loadEcb ');
		}
	});
}
function loadYear() {
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadYear",
		cache : false,
		success : function(response) {
			var strHtml = "<option value='-1'>Select Year</option>";
			jQuery.each(response, function(i, val) {
				strHtml += "<option value='" + val.yearId + "'>" + val.yearName
						+ "</option>";
			});
			$('#year').html(strHtml);
			
		},
		error : function() {
			$.alert.open('Error while loading loadYear ');
		}
	});
}
function loadExam() {
	blockU();
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadExam?ecbId=" + $("#ecbId").val(),
		cache : false,
		success : function(response) {
			unblockU();
			var strHtml = "<option value='-1'>Select Exam</option>";
			jQuery.each(response, function(i, val) {
				strHtml += "<option value='" + val.examId + "'>"
						+ val.nameOfExam + "</option>";
			});
			$('#examId').html(strHtml);
			loadSlot();
		},
		error : function() {
			unblockU();
			$.alert.open('Error while loading loadExam ');
		}
	});
}

function loadSlot() {

	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadSlot?examId=" + $("#examId").val(),
		cache : false,
		success : function(response) {
			var strHtml = "";
			jQuery.each(response, function(i, val) {
				strHtml += "<option name='slotId' value='" + val.slotID + "'>" + val.startTime.substring(0, 5)
						+ "-" + val.endTime.substring(0, 5) + "</option>";
			});
			if(strHtml!="")
			$('#slotId').html(strHtml);
			loadQPTemplateList();
		},
		error : function() {
			$.alert.open('Error while loading loadSlot ');
		}
	});
}

function runningFormatter(value, row, index) {
	index++;
    return index;
}
function langFormatter(value, row, index) {
	var data="English";
    return data;
}
function subSectionFormatter(value, row, index) {
	if(value.length > 0)
		{
		//$.alert.open(row.qptemplateSectionList[0].noOfSubsection);
		return row.qptemplateSectionList[0].noOfSubsection;
		}
	else
    return "-";
}
function groupFormatter(value, row, index) {
	if(value.length > 0)
		{
		//$.alert.open(row.qptemplateSectionList[0].noOfSubsection);
		return row.qptemplateSectionList[0].qptemplateSubSection.length;
		}
	else
    return "-";
}
function updateFormatter(value,  row, index) {
	return  "<a href='eonQPTemplateLoad?templateId="+row.templateId+"&flag=1'><div><i class='glyphicon glyphicon-pencil'></i></div><a>";
}
function viewFormatter(value, row, index) {
	return  "<a href='eonQPTemplateLoad?templateId="+row.templateId+"&flag=0'><div><i class='glyphicon glyphicon-eye-open'></i></div><a>";	
}
function downloadFormatter(value,  row, index) {
	return  "<a href='#' onclick='createTemplateExcel("+row.templateId+");' ><div><i class='glyphicon glyphicon-download-alt'></i></div><a>";
}
function publishFormatter(value, row, index) {
 	var isDisabled="";
	var publishMsg="Publish";
	if(row.isPublish == "1"){
	isDisabled="disabled";
	publishMsg="Publised";
	} 
	return  "<input class='btn btn-warning btn-xs' "+isDisabled+" alt="+publishMsg+"   type=button value='"+publishMsg+"' onclick='dispose("+row.ecbId+");'>";
} 

function loadQPTemplateList() {
	blockU();
	if($("#slotId").val()=="" || $("#slotId").val()=="null" || $("#slotId").val()==null)$("#slotId").val("-1");
	$('#table').bootstrapTable('showLoading');
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadListData?ecbId=" + $("#ecbId").val() + "&examId="
				+ $("#examId").val() + "&year=" + $("#year").val() + "&status="
				+ $("#status").val() + "&slotId=" + $("#slotId").val()
				+ "&languageId=" + $("#languageId").val(),
		cache : false,
		success : function(response) {
			unblockU();
			$('#table').bootstrapTable('hideLoading');
 			$('#notification').hide();  
 			$('#table').bootstrapTable('load', response); 
//			$.alert.open(response);
		},
		error : function() {
			unblockU();
			$('#table').bootstrapTable('hideLoading');
 			$('#notification').hide();  
			$.alert.open('Error while loading loadDataForUpdate');
		}
	});
}
function createTemplateExcel(templateId)
{
	blockU();
	/*$.alert.open(templateId);
	$.ajax({
		type : "get",
		url : "eonQPTemplateGenerate?templateId="+templateId,
		cache : false,
		success : function(response) {*/
			 window.location.href = 'eonQPTemplateGenerate?templateId='+templateId;
			 unblockU();
		/*},
		error : function() {
			$.alert.open('Error while loading createTemplateExcel ');
		}
	});*/
}