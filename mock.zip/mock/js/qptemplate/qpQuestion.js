/**
 * author:nysa
 */

$(document).ready(function() {
	$("#one, #two").hide();

	$("form#qpQuestionFrm").submit(function() {
		alert("hiii");
		var formObj = $(this);
		var formURL = formObj.attr("action");
		var formData = new FormData(this);
		$.ajax({
			url : formURL,
			type : 'POST',
			data : formData,
			mimeType : "multipart/form-data",
			contentType : false,
			cache : false,
			processData : false,
			success : function(data) {
				alert(data);
			},
			error : function() {
			}
		});
		e.preventDefault(); // Prevent Default action.
		e.unbind();
	});

});

function loadEcb() {
	var strHtml = "<option value=-1>Select Ecb</option>";
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadEcb",
		cache : false,
		success : function(response) {
			strHtml = "<option value=-1>Select Ecb</option>";
			jQuery.each(response, function(i, val) {
				strHtml += "<option value='" + val.ecbId + "'>" + val.ecbName
						+ "</option>";
			});
			$('#QPQuestionecbId').html(strHtml);
			// $('#one').hide();
			// $('#two').hide();

		},
		error : function() {
			alert('Error while loading ECB');
		}
	});
}
function clearForm() {
	$(':input').not(':button, :submit, :reset, :hidden, :checkbox, :radio')
			.val('');
	$(':checkbox, :radio').prop('checked', false);
}
function loadYear() {

	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadYear",
		cache : false,
		success : function(response) {

			var strHtml = "<option value='-1'>Select Year</option>";
			jQuery.each(response, function(i, val) {
				strHtml += "<option value='" + val.yearId + "'>" + val.yearName
						+ "</option>";
			});
			$('#QPQuestionyear').html(strHtml);
		},
		error : function() {
			alert('Error while loading Year');
		}
	});
}
function loadExam() {
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadExam?ecbId=" + $("#QPQuestionecbId").val(),
		cache : false,
		success : function(response) {
			var strHtml = "<option value='-1'>Select Exam</option>";
			jQuery.each(response, function(i, val) {
				strHtml += "<option value='" + val.examId + "'>"
						+ val.nameOfExam + "</option>";
			});
			$('#QPQuestionexamId').html(strHtml);

		},
		error : function() {
			alert('Error while loading Exam');
		}
	});
}
function loadExamDate() {
	var strHtml = "<option value='-1'>Select</option>";
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadExamDate?examId="
				+ $("#QPQuestionexamId").val(),
		cache : false,
		success : function(response) {
			strHtml = "<option value='-1'>Select Date</option>";
			jQuery.each(response, function(i, val) {
				strHtml += "<option value='" + val.examdate + "'>"
						+ val.examdate + "</option>";
			});
			$('#QPQuestionDateOfExam').html(strHtml);

		},
		error : function() {
			alert('Error while loading ExamDate');
		}
	});
}
function loadExamSlot() {

	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadExamSlot?examId="
				+ $("#QPQuestionexamId").val() + "&dateOfExam="
				+ $("#QPQuestionDateOfExam :selected").val(),
		cache : false,
		success : function(response) {

			var strHtml = "<option value='-1'>Select Slot</option>";
			jQuery.each(response, function(i, val) {
				strHtml += "<option value='" + val.slotID + "'>"
						+ val.startTime + "-" + val.endTime + "</option>";
			});
			$('#QPQuestionSlotId').html(strHtml);

		},
		error : function() {
			alert('Error while loading ExamSlot');
		}
	});
}
function loadTemplateAccDateTime() {
	// alert($("#QPQuestionDateOfExam
	// :selected").val()+"hii"+$("#QPQuestionSlotId :selected").val());
	var strHtml = "<option value=-1>Select Template</option>";
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadAccDateTime?slotDate="
				+ $("#QPQuestionDateOfExam :selected").val() + "&slotId="
				+ $("#QPQuestionSlotId :selected").val(),
		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {
				strHtml += "<option value=" + response[i].templateId + ">"
						+ response[i].templateName + "</option>";
			}
			$("#QPQuestionTemplateId").html(strHtml);

		},
		error : function() {
			alert('Error while  loadTemplateAccDateTime');
		}
	});
}

/*
 * This methosd wll load all the section for a particular template Id
 */
function loadSection() {

	if ($("#QPQuestionTemPswd").val() == "") {
		alert("please enter Template Password first");
		$("#QPQuestionTemPswd").focus();
		return;
	}
	if ($("#QPQuestionUsrPswd").val() == "") {
		alert("please enter User Password first");
		return;
	}
	$("#QPQuestionTemPswd").prop("readonly", true);
	$("#QPQuestionUsrPswd").prop("readonly", true);
	$("#one").show();
	var sectionStr = "<option value=-1>Select Section</option>";

	$.ajax({
		type : "get",
		url : "eonQPSectionLoad?templateId="
				+ $("#QPQuestionTemplateId :selected").val(),
		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {

				sectionStr += "<option value=" + response[i].sectionId + ">"
						+ response[i].sectionName + "</option>";
			}
			$('#QPQuestionSection').html(sectionStr);
			loadBatchId();

		},
		error : function() {
			alert('Error while loading Section');
		}
	});

}
/*
 * This method will load all the subsection detail for a particular SectionId
 */
function loadAllSubSecPerSection() {

	var subSectionStr = "<option value=-1>Select Section</option>";
	$('#QPQuestionGroup').html("<option value=-1>Select Group</option>");
	$('#groupQuestion').html(subSectionStr);
	$.ajax({
		type : "get",
		url : "eonloadAllSubSecPerSection?sectionId="
				+ $("#QPQuestionSection :selected").val(),
		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {

				subSectionStr += "<option value=" + response[i].subSectionId
						+ ">" + response[i].subSectionHeading + "</option>";
			}
			$('#QPQuestionSubSection').html(subSectionStr);

			loadSectionDetailForParticularSection();
		},
		error : function() {
			alert('Error while loading SubSection detail');
		}
	});
}
/*
 * This method will load all the group detail for a particular subSectionId
 */
function loadAllGroupDetailForSubSec() {

	var groupStr = "<option value=-1>Select Section</option>";

	$.ajax({
		type : "get",
		url : "eonloadAllGroupDetailForSubSec?subSectionId="
				+ $("#QPQuestionSubSection :selected").val(),
		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {

				groupStr += "<option value=" + response[i].groupId + ">"
						+ response[i].groupText + "</option>";
			}
			$('#QPQuestionGroup').html(groupStr);

		},
		error : function() {
			alert('Error while loading group detail');
		}
	});
}
function setGroupText() {
	// VED
	$("#secName").val($("#QPQuestionSection option:selected").text());
	$("#tempName").val($("#QPQuestionTemplateId option:selected").text());
	$("#subSecName").val($("#QPQuestionSubSection option:selected").text());
	$("#grpName").val($("#QPQuestionGroup option:selected").text());
	$.ajax({
		type : "get",
		url : "eonloadGroupDetailForParticularGroup?groupId="
				+ $("#QPQuestionGroup :selected").val(),
		cache : false,
		success : function(response) {

			$("#QPQuestionGroupText").val(response[0].groupText);

			$("#two").show();

		},
		error : function() {
			alert('Error while loading group detail');
		}
	});
}
function loadSectionDetailForParticularSection() {

	$("#QPQuestionSectionText").val("");
	$("#QPQuestionType").val("");

	$.ajax({
		type : "get",
		url : "eonloadSectionDetailForParticularSection?sectionId="
				+ $("#QPQuestionSection :selected").val(),

		cache : false,
		success : function(response) {
			$("#QPQuestionNoOfOption").val(response[0].optionCount);
			$("#QPQuestionSectionText").val(response[0].sectionText);
			$("#QPQuestionType").html(
					"<option value=" + response[0].questionTypeID + ">"
							+ response[0].qtypename + "</option>");
			// $("#QPQuestionType").val(response[0].qtypename);
			$("#QPQuestionmarksCorrect").val(response[0].marksForCorrect);
			$("#QPQuestionmarksWrong").val(response[0].marksForWrong);
			$("#QPQuestionmarksBlank").val(response[0].marksForBlank);
		},
		error : function() {
			alert('Error while loadSectionDetailForParticularSection');
		}
	});
}

function saveQPQuestionDetail() {

	if ($("#questionText").val() == "") {
		alert("please enter question");
		return false;
	}

	if ($("#optionText1").val() == "") {
		alert("please enter option 1");
		return false;
	}
	if ($("#optionText2").val() == "") {
		alert("please enter option 2");
		return false;
	}
	if ($("#optionText3").val() == "") {
		alert("please enter option 3");
		return false;
	}
	if ($("#optionText4").val() == "") {
		alert("please enter option 4");
		$("#optionText4").focus();
		return false;
	}

	if ($('input[name=CorrectOption]:checked').length <= 0) {
		alert("Please select a correct button ");
		return false;
	}
	if (confirm("You are going create new Template. Are you sure ?")) {

		var $form = 'form1';

		// Use Ajax to submit form data
		$.ajax({
			url : $form.attr('action'),
			type : 'POST',
			data : $form.serialize(),
			success : function(result) {
				alert("hiiiii");
			}
		});
	}
	return false;
}

// function submitFormByAjax(){
// $('#qpQuestionFrm')
// .formValidation({
// var checkArray=["questionText","optionText"];
// var msgArray =["please enter question","please enter option"];
// if($("#optionText1").val()==""){
// alert("please enter option 1");
// return;
// }
// if($("#optionText2").val()==""){
// alert("please enter option 2");
// return;
// }
// if($("#optionText3").val()==""){
// alert("please enter option 3");
// return;
// }
// if($("#optionText4").val()==""){
// alert("please enter option 4");
// return;
// }
// if(validateFields(checkArray, 1 , msgArray) )
// {
// }
// })
// .on('success.form.fv', function(e) {
// // Prevent form submission
// e.preventDefault();
//
// var $form = $(e.target);
// $form.ajaxSubmit({
// // You can change the url option to desired target
// url: $form.attr('action'),
// dataType: 'json',
// success: function(responseText, statusText, xhr, $form) {
// // Process the response returned by the server ...
// // console.log(responseText);
// }
// });
// });
//	
//
// }
function loadTemplatePerExistTemplate() {
	if ($("#QPQuestionTemplateId :selected").val() == -1) {
		alert("please select the template first");
		$("#QPQuestionTemPswd").val("");
		return;
	}
	if ($("#QPQuestionTemPswd").val() == "") {
		alert("please enter the template password");
		return;
	}
	$.ajax({
		type : "get",
		url : "eonloadTemplatePerExistTemplate?templateId="
				+ $("#QPQuestionTemplateId :selected").val(),
		cache : false,
		success : function(response) {
			if ($("#QPQuestionTemPswd").val() != response[0].templatePassword) {
				alert("Please enter the correct template password");
				$("#QPQuestionTemPswd").val("").focus();
				return;
			} else {

				$("#QPQuestiondifficutyLevel").val(
						response[0].qpDifficultyLevel)
				$("#QPQuestionUsrPswd").focus();
			}

		},
		error : function() {
			alert('Error while loadTemplatePerExistTemplate');
		}
	});
}

function validateUserPassword() {
	if ($("#QPQuestionUsrPswd").val() == "") {
		alert("please enter user password");

		return;
	}
	$
			.ajax({
				type : "get",
				url : "validateUserPassword?username="
						+ $("#QPQuestionusername").val(),
				cache : false,
				success : function(response) {

					if ($("#QPQuestionUsrPswd").val() != response) {
						alert("please enter the correct User Password");
						$("#QPQuestionUsrPswd").val("").focus();
					}

				},
				error : function() {
					alert('Error while validateUserPassword');
				}
			});
}
function assignValuetoRadioButton(id) {

	if ($("#" + id).prop("checked", true)) {
		$("#" + id + "Hidden").val("true");
	} else {
		$("#" + id + "Hidden").val("false");
	}

}
function getAllQuestionDetail() {
	$.ajax({
		type : "get",
		url : "getAllQuestionDeatil?templateId="
				+ $("#QPQuestionTemplateId").val() + "&sectionId="
				+ $("#QPQuestionSection").val() + "&subSectionId="
				+ $("#QPQuestionSubSection").val() + "&groupId="
				+ $("#QPQuestionGroup").val(),
		cache : false,
		success : function(response) {

		},
		error : function() {
			alert('Error while getAllQuestionDetail');
		}
	});
}
function onPreviousClick() {

	$.ajax({
		type : "get",
		url : "getPreviousValue?templateId=" + $("#QPQuestionTemplateId").val()
				+ "&sectionId=" + $("#QPQuestionSection").val()
				+ "&subSectionId=" + $("#QPQuestionSubSection").val()
				+ "&groupId=" + $("#QPQuestionGroup").val() + "&userId="
				+ $("#createdBy").val() + "&questionId="
				+ $("#questionId").val(),
		cache : false,
		success : function(response) {
			var a = [];
			a.push(response[0].qPQuestionOptions[0].oID);
			a.push(response[0].qPQuestionOptions[1].oID);
			a.push(response[0].qPQuestionOptions[2].oID);
			a.push(response[0].qPQuestionOptions[3].oID);

			$("#optionIdUpdate").val(a);
			$("#questionId").val(response[0].qID);
			$("#questionText").val(response[0].questionText);
			$("#optionText1").val(response[0].qPQuestionOptions[0].optionText);
			$("#optionText2").val(response[0].qPQuestionOptions[1].optionText);
			$("#optionText3").val(response[0].qPQuestionOptions[2].optionText);
			$("#optionText4").val(response[0].qPQuestionOptions[3].optionText);
			if (response[0].qPQuestionOptions[0].isItCorrectOption == 1) {
				$("#correctOption1").prop("checked", true);
				$("#correctOption1Hidden").val(true);

			}
			if (response[0].qPQuestionOptions[1].isItCorrectOption == 1) {
				$("#correctOption2").prop("checked", true);
				$("#correctOption2Hidden").val(true);

			}
			if (response[0].qPQuestionOptions[2].isItCorrectOption == 1) {
				$("#correctOption3").prop("checked", true);
				$("#correctOption2Hidden").val(true);

			}
			if (response[0].qPQuestionOptions[3].isItCorrectOption == 1) {
				$("#correctOption4").prop("checked", true);
				$("#correctOption4Hidden").val(true);

			}
			document.getElementById("qimg").src = "data:image/png;base64,"
					+ response[0].qPQuestionImages[0].qimg;
			document.getElementById("image1").src = "data:image/png;base64,"
					+ response[0].qPQuestionOptionsImages[0].img;
			document.getElementById("image2").src = "data:image/png;base64,"
					+ response[0].qPQuestionOptionsImages[1].img;
			document.getElementById("image3").src = "data:image/png;base64,"
					+ response[0].qPQuestionOptionsImages[2].img;
			document.getElementById("image4").src = "data:image/png;base64,"
					+ response[0].qPQuestionOptionsImages[3].img;
			// $("#correctOption2").val(response[0].qPQuestionOptions[1].isItCorrectOption);
			// $("#correctOption3").val(response[0].qPQuestionOptions[2].isItCorrectOption);
			// $("#correctOption4").val(response[0].qPQuestionOptions[3].isItCorrectOption);
			// $('input[type="radio"][value="1"]').val();
		},
		error : function() {
			alert('Error while getAllQuestionDetail');
		}
	});
}
/*
 * 
 */
function onNextClick() {

	$
			.ajax({
				type : "get",
				url : "getNextValue?templateId="
						+ $("#QPQuestionTemplateId").val() + "&sectionId="
						+ $("#QPQuestionSection").val() + "&subSectionId="
						+ $("#QPQuestionSubSection").val() + "&groupId="
						+ $("#QPQuestionGroup").val() + "&userId="
						+ $("#createdBy").val() + "&questionId="
						+ $("#questionId").val(),
				cache : false,
				success : function(response) {

					if (response.length > 0) {
						$("#questionId").val(response[0].qID);
						$("#questionText").val(response[0].questionText);
						$("#optionText1").val(
								response[0].qPQuestionOptions[0].optionText);
						$("#optionText2").val(
								response[0].qPQuestionOptions[1].optionText);
						$("#optionText3").val(
								response[0].qPQuestionOptions[2].optionText);
						$("#optionText4").val(
								response[0].qPQuestionOptions[3].optionText);
						if (response[0].qPQuestionOptions[0].isItCorrectOption == 1) {
							$("#correctOption1").prop("checked", true);
						}
						if (response[0].qPQuestionOptions[1].isItCorrectOption == 1) {
							$("#correctOption2").prop("checked", true);
						}
						if (response[0].qPQuestionOptions[2].isItCorrectOption == 1) {
							$("#correctOption3").prop("checked", true);
						}
						if (response[0].qPQuestionOptions[3].isItCorrectOption == 1) {
							$("#correctOption4").prop("checked", true);
						}
						document.getElementById("qimg").src = "data:image/png;base64,"
								+ response[0].qPQuestionImages[0].qimg;
						document.getElementById("image1").src = "data:image/png;base64,"
								+ response[0].qPQuestionOptionsImages[0].img;
						document.getElementById("image2").src = "data:image/png;base64,"
								+ response[0].qPQuestionOptionsImages[1].img;
						document.getElementById("image3").src = "data:image/png;base64,"
								+ response[0].qPQuestionOptionsImages[2].img;
						document.getElementById("image4").src = "data:image/png;base64,"
								+ response[0].qPQuestionOptionsImages[3].img;
					} else {
						clearQuestionAllField();
					}
				},
				error : function() {
					alert('Error while getAllQuestionDetail');
				}
			});
}

function clearQuestionAllField() {
	$("#questionId").val('0');
	$("#questionText").val("");
	$("#optionText1").val("");
	$("#optionText2").val("");
	$("#optionText3").val("");
	$("#optionText4").val("");
	jQuery('#qimg').removeAttr('src');
	jQuery('#image1').removeAttr('src');
	jQuery('#image2').removeAttr('src');
	jQuery('#image3').removeAttr('src');
	jQuery('#image4').removeAttr('src');
	jQuery("#correctOption1").attr('checked', false);
	jQuery("#correctOption2").attr('checked', false);
	jQuery("#correctOption3").attr('checked', false);
	jQuery("#correctOption4").attr('checked', false);
}
// logo upload start
$(document).ready(function() {
	var e1;
	function readURL(input) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();
			reader.onload = function(e) {
				e1 = e;

			}

			reader.readAsDataURL(input.files[0]);
		}
	}

	function imgChange() {

	}

	$("#img1").change(function() {
		readURL(this);
		$('#image1').attr('src', e1.target.result);
	});
	$("#img2").change(function() {
		readURL(this);
		$('#image2').attr('src', e1.target.result);
	});
	$("#img3").change(function() {
		readURL(this);
		$('#image3').attr('src', e1.target.result);
	});
	$("#img4").change(function() {
		readURL(this);
		$('#image4').attr('src', e1.target.result);
	});
	$("#qimage").change(function() {
		readURL(this);
		$('#qimg').attr('src', e1.target.result);
	});

});
// logo upload end

// iamge big

function bigImg(x) {
	x.style.height = "80px";
	x.style.width = "80px";
}

function normalImg(x) {
	x.style.height = "20px";
	x.style.width = "20px";
}
function toSubmit(url) {
	document.form1.action = url;
	document.form1.submit();
}
function addedQuestionPreviewInPDF() {
	var templateId = $("#QPQuestionTemplateId").val();
	blockU();
	window.location.href = 'allAddedQuestionReport?templateId=' + templateId;
	unblockU();
}
function loadBatchId() {

	var strHtml = "<option value=-1>Select Batch Id</option>";
	$.ajax({
		type : "get",
		url : "eonAddQuestionLoadBatchId?templateId="
				+ $("#QPQuestionTemplateId").val(),
		cache : false,
		success : function(response) {
			alert(response);
			strHtml = "<option value=-1>Select Batch Id</option>";
			jQuery.each(response, function(i, val) {
				strHtml += "<option value='" + val + "'>" + val + "</option>";
			});
			$('#batchId').html(strHtml);
			// $('#one').hide();
			// $('#two').hide();

		},
		error : function() {
			alert('Error while loading loadBatchId');
		}
	});
}
