var tempName="";
function loadEcb() {
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadEcb",
		cache : false,
		success : function(response) {
			var strHtml="";
			jQuery.each(response, function(i, val) {
				strHtml+="<option value='"+val.ecbId+"'>"+val.ecbName+"</option>";
			    });
			$('#ecbId').html(strHtml);
			var templateId = $("#primTemplateId").val();
			var flag = $("#flagUpdate").val();
			if (templateId > 0 && templateId != "") {

				loadTemplatePerExistTemplate(templateId,flag);
			}
			if (templateId == "") {
				loadExam();
			}
		},
		error : function() {
			$.alert.open('Error while loading ECB');
		}
	});
}
function loadYear() {
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadYear",
		cache : false,
		success : function(response) {
			var strHtml="<option value='-1'>Select Year</option>";
			jQuery.each(response, function(i, val) {
				strHtml+="<option value='"+val.yearId+"'>"+val.yearName+"</option>";
			    });
			$('#year').html(strHtml);
		},
		error : function() {
			$.alert.open('Error while loading ECB');
		}
	});
}
function loadExam() {
	
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadExam?ecbId="+$("#ecbId").val(),
		cache : false,
		success : function(response) {
			
			var strHtml="<option value='-1'>Select Exam</option>";
			jQuery.each(response, function(i, val) {
				strHtml+="<option value='"+val.examId+"'>"+val.nameOfExam+"</option>";
			    });
			$('#examId').html(strHtml);
			loadExamDate();
		},
		error : function() {
			
			$.alert.open('Error while loading ECB');
		}
	});
}

//*************************************************************************
var selected = [];
var slotselect=[];
subjectselect=[];
$(document).ready(function() {
	$('#optionTypeId').multiselect({
	    includeSelectAllOption: true,
	    enableFiltering: true,
	    buttonWidth: '250px',
	});
$('#divDateOfExam').multiselect({
    includeSelectAllOption: true,
    enableFiltering: true,
    buttonWidth: '180px',
    onChange: function(element, checked) {    	
        var brands = $('#divDateOfExam option:selected');       
        $(brands).each(function(index, brand){
            selected.push([$(this).val()]);
        });
        loadExamSlot();
        console.log(selected);
    },
   
});
$('#divSlotId').multiselect({
    includeSelectAllOption: true,
    enableFiltering: true,
    buttonWidth: '220px',
    onChange: function(element, checked) {
        var brands = $('#divSlotId option:selected');
        
        $(brands).each(function(index, brand){
        	slotselect.push([$(this).val()]);
        });	
        console.log(slotselect);
    },
});
$('#subjectId').multiselect({
    includeSelectAllOption: true,
    enableFiltering: true,
    buttonWidth: '250px',
    onChange: function(element, checked) {
        var brands = $('#subjectId option:selected');
        
        $(brands).each(function(index, brand){
        	subjectselect.push([$(this).val()]);
        });	
    },
});
});
function loadEcbSubject() {
	blockU();
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadEcbSubject",
		cache : false,
		success : function(response) {
			unblockU();
			var dropdata=[];
//			var strHtml="<option value='-1'>Select ECB Subject</option>";
			jQuery.each(response, function(i, val) {
//				strHtml+="<option value='"+val.lookupId+"'>"+val.lookupName+"</option>";
				dropdata.push({
                    'label': [val.lookupName],
                    'value': [val.lookupId]
                })
			    });
//			$('#subjectId').html(strHtml);
			$('#subjectId').multiselect('dataprovider', dropdata);
            $('#subjectId').multiselect({
                includeSelectAllOption: true,
                enableFiltering: true,
                buttonWidth: '250px',
            });
            
		},
		error : function() {
			unblockU();
			$.alert.open('Error while loading loadEcbSubject');
		}
	});
}
function loadExamDate() {

	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadExamDate?examId="+$("#examId").val(),
		cache : false,
		success : function(response) {
				
				var dropdata=[];
                jQuery.each(response, function(i, val) {
                	dropdata.push({
                        'label': [val.examdate],
                        'value': [val.examdate]
                    })

                });
                $('#divDateOfExam').multiselect();
                $('#divDateOfExam').multiselect('dataprovider', dropdata); 
                $('#divDateOfExam').multiselect({           
                    includeSelectAllOption: true,
                    enableFiltering: true,
                    buttonWidth: '180px',
                   
                });
			loadExamSlot();
		},
		error : function() {
			
			$.alert.open('Error while loading ECB');
		}
	});
}

function loadExamSlot() {
	
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadExamSlot?examId="+$("#examId").val()+"&dateOfExam="+getDateOfExam(),
		cache : false,
		success : function(response) {
			
			var dropdata=[];
            jQuery.each(response, function(i, val) {
            	dropdata.push({
                    'label': [val.startTime.substring(0,5)+"-"+val.endTime.substring(0,5)],
                    'value': [val.slotID+"::"+val.examdate]
                })
            });
            $('#divSlotId').multiselect('dataprovider', dropdata);
            $('#divSlotId').multiselect({
                includeSelectAllOption: true,
                enableFiltering: true,
                buttonWidth: '250px',
            });
			loadEcbSubject();
		},
		error : function() {
		
			$.alert.open('Error while loading ECB');
		}
	});
}
function getDateOfExam()
{
	var arr = ["1990-12-12"];
	 var brands = $('#divDateOfExam option:selected');       
     $(brands).each(function(index, brand){
    	 arr.push([$(this).val()]);
     });
	return arr;
}
//*************************************************************************
/*function loadExamDate() {
	var strHtml="";
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadExamDate?examId="+$("#examId").val(),
		cache : false,
		success : function(response) {
			strHtml="";
			jQuery.each(response, function(i, val) {
				strHtml+="<input type=checkbox onclick='loadExamSlot()' name='dateOfExam' id='dateOfExam' value='"+val.examdate+"'>"+val.examdate+"";
			    });
			$('#divDateOfExam').html(strHtml);
			loadExamSlot();
		},
		error : function() {
			$.alert.open('Error while loading ECB');
		}
	});
}
function loadExamSlot() {
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadExamSlot?examId="+$("#examId").val()+"&dateOfExam="+getDateOfExam(),
		cache : false,
		success : function(response) {
			var strHtml="";
			jQuery.each(response, function(i, val) {
				strHtml+="<input type=checkbox name='slotId' value='"+val.slotID+"::"+val.examdate+"'>"+val.startTime.substring(0,5)+"-"+val.endTime.substring(0,5);
			    });
			$('#divSlotId').html(strHtml);
			loadEcbSubject();
		},
		error : function() {
			$.alert.open('Error while loading ECB');
		}
	});
}
function getDateOfExam()
{
	var arr = ["1990-12-12"];
	var dateOfExam = document.getElementsByName("dateOfExam");
	for(var i=0;i<dateOfExam.length;i++){
		if(dateOfExam[i].checked==true)
			{
				arr.push(dateOfExam[i].value);
			}
	}
	return arr;
}*/
/*function loadEcbSubject() {
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadEcbSubject",
		cache : false,
		success : function(response) {
//			var strHtml="<option value='-1'>Select ECB Subject</option>";
			jQuery.each(response, function(i, val) {
//				strHtml+="<option value='"+val.lookupId+"'>"+val.lookupName+"</option>";
			    });
//			$('#subjectId').html(strHtml);
		},
		error : function() {
			$.alert.open('Error while loading loadEcbSubject');
		}
	});
}*/
function validateTemplateName() {
	
	$.ajax({
		type : "get",
		url : "eonQPTemplateValidateTempName?templateName="+$("#templateName").val()+"&updateTemplateName="+$("#updateTemplateName").val(),
		cache : false,
		success : function(response) {
			var flagName=0;
			if(response!="")
			{
				if($("#primTemplateId").val()> 0 && $("#primTemplateId").val() != "")
				 {
					if($("#templateName").val()==tempName)
						{
						flagName=1;
						}
					
				 }
				if(flagName!=1){
					 $('#templateName').val("");
					 $.alert.open(response);
				}
			
			}
		},
		error : function() {
			$.alert.open('Error while loading validateTemplateName');
		}
	});
}
function validateTemplateDuration() {
	$.ajax({
		type : "get",
		url : "eonQPTemplateValidateDuration?duration="+$("#duration").val()+"&examId="+$("#examId").val(),
		cache : false,
		success : function(response) {
			if(response!="")
				{
				 $('#duration').val("");
				 $.alert.open(response);
				}
		},
		error : function() {
			$.alert.open('Error while loading validateTemplateDuration');
		}
	});
}
function validateMaxDuration()
{
	if($("#duration").val()=="" || $("#duration").val()=="0")
		{
			$.alert.open("Please enter duration first.");
			$("#maximumDuration").val("");
			return false;
		}
	if(parseInt($("#maximumDuration").val()) > parseInt($("#duration").val()))
		{
			$.alert.open("Maximum duration cannot greater then duration");
			$("#maximumDuration").val("");
		}
}
function validateMinDuration()
{
	if($("#duration").val()=="" || $("#duration").val()=="0")
		{
			$.alert.open("Please enter duration first.");
			$("#maximumDuration").val("");
			return false;
		}
	if($("#maximumDuration").val()=="" || $("#maximumDuration").val()=="0")
		{
			$.alert.open("Please enter maximum duration first.");
			$("#minimumDuration").val("");
			return false;
		}
	if(parseInt($("#minimumDuration").val()) > parseInt($("#maximumDuration").val()))
		{
			$.alert.open("Minimum duration cannot greater then Maximum duration");
			$("#minimumDuration").val("");
		}
}
function toFirstTabSave(){
	
	
	var checkArray=["ecbId","year","examId","templateName","duration","subjectId","noOfSets","noOfSection","noOfOptionalSectionToAttempt"
	               , "noOfQuestions","totalMarks","questionTypeId","qpDifficultyLevel","difficultyDeviation","maximumDuration","minimumDuration","templatePassword","templatePasswordConfirm"];

	var msgArray =["Please select ECB Name.","Please select Year", "Please select Exam Name","Please enter Template Name","Please enter Duration"
	               ,"Please selectb ECB Subject","Please enter No of Sets","Please enter No of Section","Please enter No of Optional Sections To Attempt"
	               ,"Please enter No of Questions","Please enter No of Total Marks","Please select Question Type"
	               ,"Please select Difficulty Level","Please enter Difficulty Deviation","Please enter Maximun Duration","Please enter Minimum Duration","Please enter Template Password","Please enter Template Confirm Password"];
	
	if(validateFields(checkArray, 0 , msgArray) && validatePassword())
	{
	var noZeroFields=checkZeroFields();
	if(noZeroFields){
	if(confirm("You are going create new Template. Are you sure ?"))
		{
	$("#isRevisitAllowedView").prop("disabled",false);	
	var frm=$("#frm");
	  $.ajax({
		        type: frm.attr('method'),
		        url: frm.attr('action'),
		        data: frm.serialize(),
		        success: function (response) {
		        //$.alert.open(response);
		        $("#primTemplateId").val(response);
		        $.alert.open($("#templateName").val()+" has been successfully created");
		       // loadSectiontab();
		         $('.nav li.active').next('li').removeClass('disabled');
			     $('.nav li.active').next('li').find('a').attr("data-toggle","tab")
			     $('.nav-tabs > .active').next('li').find('a').trigger('click');
		        },
				error : function() {
					$.alert.open('Error while assigning the value');
				}
		    });
		}
	 
		}
	
}
}
function validatePassword()
{
	var flag=true;
	var templateId = document.form1.templateId.value;
	
	if(templateId=="" || templateId==0)
		{
			var obj =$('#divDateOfExam option:selected');       
			if(obj.length==0)
				{
				$.alert.open("Please select Date Of Exam");
				flag = false;
				}
			
			var obj =$('#divSlotId option:selected');       
			if(obj.length==0)
				{
				$.alert.open("Please select Slot");
				flag = false;
				}
			
			var obj =$('#subjectId option:selected');       
			if(obj.length==0)
				{
				$.alert.open("Please select Subject");
				flag = false;
				}
			
			var obj =$('#optionTypeId option:selected');       
			if(obj.length==0)
				{
				$.alert.open("Please select Option Type");
				flag = false;
				}
		}
	if($("#templatePassword").val()!=$("#templatePasswordConfirm").val())
	{
		$.alert.open("Password not matched");
		flag = false;
	}
	
	return flag;
}

/*var gblExamId="";
var gblYearId="";
var gblDate = [];
var gblSlot = [];
var gblEcbSubjectId = [];*/

//function loadDataForUpdate()
//{
	/*$.ajax({
		type : "get",
		url : "eonQPTemplateLoadUpdate?templateId="+templateId,
		cache : false,
		success : function(response) {
			$('#ecbId').val(response[0].ecbId);
			$('#subjectId').val(response[0].subjectId);
			$("input[type=checkbox]").each(function(){
				var name = this.name;
				if(response[0][name]==1)
					{
						eval("document.form1."+name+".checked=true");
					}
				})
				$("input[type=text]").each(function(){
				var name = this.name;
						eval("document.form1."+name+".value='"+response[0][name]+"'");
				})
				$("select").each(function(){
						var name = this.name;
						eval("document.form1."+name+".value='"+response[0][name]+"'");
				})
		},
		error : function() {
			$.alert.open('Error while loading loadDataForUpdate');
		}
	});*/
//}
function validateSectionAttempt()
{
	if($("#noOfSection").val()=="" || $("#noOfSection").val()=="0")
	{
		$.alert.open("Please enter No of Optional Section");
		$("#noOfOptionalSectionToAttempt").val("");
		return false;
	}
	if(parseInt($("#noOfOptionalSectionToAttempt").val()) > parseInt($("#noOfSection").val()))
		{
			$.alert.open("No of Optional Section To Attempt cannot greater then No of Optional Section");
			$("#noOfOptionalSectionToAttempt").val("");
		}
}

function checkZeroFields(){
	var flag=true;
		$("#frm input[type=text],#frm input[type=textarea]").each(
					function() {
						var name = this.name;
						if(name==""){
							flag=true;
							return false;
						}
						var x=eval("document.form1." + name+".value");
		                if(x==0){
		                	eval("document.form1." + name + ".value=''");
		                	$.alert.open(name.toUpperCase()+" cannot be zero,Please enter valid value");
		                	eval("document.form1." + name + ".focus()");
		                	flag=false;
		                	return false;
		                }
		               
					});
		return flag;
	}

function changeCheckboxValue(obj,uncheckVal,checkVal)
{
	if(obj.checked==true)
		{
		obj.value=checkVal;
		$("#isRevisitAllowedView").prop("checked",true);
		document.getElementById('isRevisitAllowedView').value =1;
		$("#isRevisitAllowedView").prop("disabled",true);
		}
	else
		{
		
		obj.value=uncheckVal;
		$("#isRevisitAllowedView").prop("disabled",false);
		}
}

function loadExamForView(examId, subjectId,flag) {

	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadExam?ecbId=" + $("#ecbId").val(),
		cache : false,
		success : function(response) {
			var strHtml = "<option value='-1'>Select Exam</option>";
			jQuery.each(response, function(i, val) {
				strHtml += "<option value='" + val.examId + "'>"
						+ val.nameOfExam + "</option>";
			});
			$('#examId').html(strHtml);
			$("#examId").val(examId);
			if(flag==0 || flag==1){
				$("#examId").prop("disabled",true);
			}
			loadEcbSubjectForView(subjectId,examId,flag);
			loadExamDateForView(examId,flag)
		},
		error : function() {
			$.alert.open('Error while loading ExamForView');
		}
	});
}

function loadEcbSubjectForView(subjectId,examId,flag) {
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadEcbSubject",
		cache : false,
		success : function(response) {
			var dropdata=[];
			jQuery.each(response, function(i, val) {
				dropdata.push({
                    'label': [val.lookupName],
                    'value': [val.lookupId]
                })
			    });
			$('#subjectId').multiselect('dataprovider', dropdata);
            $('#subjectId').multiselect({
                includeSelectAllOption: true,
                enableFiltering: true,
                buttonWidth: '250px',
            });
            var sId = [];
            jQuery.each(subjectId, function(j, val1) {
            	sId.push(val1.subjectId);
            });
           
            $('#subjectId').multiselect('select',sId);
		},
		error : function() {
			$.alert.open('Error while loading loadEcbSubject');
		}
	});
}
function loadExamDateForView(examId,flag) {
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadExamDate?examId="+$("#examId").val(),
		cache : false,
		success : function(response) {
				var dropdata=[];
                jQuery.each(response, function(i, val) {
                	dropdata.push({
                        'label': [val.examdate],
                        'value': [val.examdate]
                    })

                });
                $('#divDateOfExam').multiselect();
                $('#divDateOfExam').multiselect('dataprovider', dropdata); 
                $('#divDateOfExam').multiselect({           
                    includeSelectAllOption: true,
                    enableFiltering: true,
                    buttonWidth: '180px',
                   
                });
              
                $('#divDateOfExam').multiselect('select',arrDataOfExam);
                loadExamSlotForView();    
		},
		error : function() {
			$.alert.open('Error while loading ECB');
		}
	});
}

function getDateOfExamForView()
{
	var arr = ["1990-12-12"];
	var dateOfExam = document.getElementsByName("dateOfExam");
	for(var i=0;i<dateOfExam.length;i++){
		if(dateOfExam[i].checked==true)
			{
				arr.push(dateOfExam[i].value);
			}
	}
	return arr;
}
function loadExamSlotForView() {
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadExamSlot?examId="+$("#examId").val()+"&dateOfExam="+getDateOfExam(),
		cache : false,
		success : function(response) {
			var dropdata=[];
            jQuery.each(response, function(i, val) {
            	dropdata.push({
                    'label': [val.startTime.substring(0,5)+"-"+val.endTime.substring(0,5)],
                    'value': [val.slotID+"::"+val.examdate]
                })
            });
            $('#divSlotId').multiselect('dataprovider', dropdata);
            $('#divSlotId').multiselect({
                includeSelectAllOption: true,
                enableFiltering: true,
                buttonWidth: '250px',
            });
            $('#divSlotId').multiselect('select',arrDataOfExamSlot);
		},
		error : function() {
			$.alert.open('Error while loading ECB');
		}
	});
	
}
var arrDataOfExam = [];
var arrDataOfExamSlot = [];
function loadTemplatePerExistTemplate(templateId,flag) {

	$.ajax({
		type : "get",
		url : "eonloadTemplatePerExistTemplate?templateId=" + templateId,
		cache : false,
		success : function(response) {

//			$("#examId").val(response[0].examIdObj.examId);
//			$('#subjectId').val(response[0].subjectId);
			$("#frm input[type=checkbox]").each(function() {
				var name = this.name;
				if(name!="" )
					{
						if (response[0][name] == 1) {
							eval("document.form1." + name + ".checked=true");
						}
						eval("document.form1." + name + ".disabled=true");
					}
			})
			if($("#isRevisitAllowedEdit").is(":checked")){
				$("#isRevisitAllowedView").prop("checked",true);
				document.getElementById('isRevisitAllowedView').value =1;
				$("#isRevisitAllowedView").prop("disabled",true);
			}
			$("#frm input[type=text]").each(
					function() {
						var name = this.name;
						if(name!="")
							{
						eval("document.form1." + name + ".value='"
								+ response[0][name] + "'");
							eval("document.form1." + name + ".readOnly=true");
							}
					
					})
			
			$("#frm input[type=number]").each(
					function() {
						var name = this.name;

						eval("document.form1." + name + ".value='"
								+ response[0][name] + "'");
							eval("document.form1." + name + ".readOnly=true");
					})
			$("#frm input[type=password]").each(
					function() {
						var name = this.name;
						
						eval("document.form1." + name + ".value='"
								+ response[0][name] + "'");
						if(flag==0){
							eval("document.form1." + name + ".readOnly=true");
						}
					})
					
					$("#templatePasswordConfirm").val($("#templatePassword").val());
			
			$("#frm select").each(
					function() {
						var name = this.name;
						eval("document.form1." + name + ".value='"+ response[0][name] + "'");
					})
			$("#ecbId").val(response[0].ecbIdObj.ecbId);
			$("#year").val(response[0].year);
			$("#optionTypeId").val(response[0].questionTypeList[0].questionTypeId);
			if(flag==0){
				$("#year").prop("disabled",true);
				$("#ecbId").prop("disabled",true);
				$("#optionTypeId").prop("disabled",true);
				$("#qpDifficultyLevel").prop("disabled",true);
				$("#next1").hide();
				$("#tempCancel").hide();
				$("#backToTempList").prop('value', 'Exit');
			}
		
			if(flag==1){
				
				document.form1.templateName.readOnly=false;
				document.form1.difficultyDeviation.readOnly=false;
				$("#year").prop("disabled",true);
				$("#ecbId").prop("disabled",true);
				$("#optionTypeId").prop("disabled",true);
				tempName=$("#templateName").val();
			}
			loadExamForView(response[0].examIdObj.examId,response[0].subjectIdList,flag);
			var questionTypeId = [];
            jQuery.each(response[0].questionTypeList, function(j, val1) {
            	questionTypeId.push(val1.questionTypeId);
            });
            
            $('#optionTypeId').multiselect('select',questionTypeId);
            
            jQuery.each(response[0].qptemplateSlotMapList, function(j, val1) {
            	arrDataOfExam.push(val1.dateOfExam.substring(0,10));
            });
            jQuery.each(response[0].qptemplateSlotMapList, function(j, val1) {
            	arrDataOfExamSlot.push(val1.slotId+"::"+val1.dateOfExam.substring(0,10));
            });
            
			
		},
		error : function() {
			$.alert.open('Error while loading validateTemplateDuration');
		}
	});
}

