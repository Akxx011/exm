var templateId=1;
function loadQuesPreview(){
	
	
	loadTemplateDetailForPreview();
}
function loadTemplateDetailForPreview() {
	
	$.ajax({
		type : "get",
		url : "eonQPLoadTemplate?templateId=" + templateId,

		cache : false,
		success : function(response) {

		
			$("#templateNamePreview").text(response[0].templateName);
			$("#ExamPreview").text(response[0].examIdObj.nameOfExam);
			previewQuestion();
		},
		error : function() {
			$.alert.open('Error while loadTemplateDetail');
		}
	});
}
function previewQuestion() {
	
	var strHtml="";
	var subSecFlag=0;
	var groupFlag=0;

	$.ajax({
		type : "get",
		url : "eonQPSectionLoad?templateId=" + templateId,
		cache : false,
		success : function(response) {
			$('#quesPreviewGrid').append("<tbody id='quesPreviewId'>");
			for (var i = 0; i < response.length; i++) {
				if(response.isMandatory==1){
					strHtml+="<tr align='center' text='bold'><td colspan='5'>Section-"+(i+1)+"  ("+response[i].sectionName+")</td><td>(Compulsory)</td></tr>";
				}
				else{
					strHtml+="<tr align='center' text='bold'><td colspan='5'>Section-"+(i+1)+"  ("+response[i].sectionName+")</td></tr>";
				}
				
				strHtml+="<tr rowspan='"+response[i].qptemplateSubSection.length+"'>";
				for(var j=0;j<response[i].qptemplateSubSection.length;j++){
					subSecFlag=1;
					strHtml+="<tr><td>Sub Section-"+(j+1)+"  ("+response[i].qptemplateSubSection[j].subSectionHeading+")</td></tr>";
					strHtml+="<tr>";
					for(var k=0;k<response[i].qptemplateSubSection[j].qptemplateGroup.length;k++)
					{
					  groupFlag=1;	
					  var groupQuestCount=response[i].qptemplateSubSection[j].qptemplateGroup[k].noOfQuestions;
					  var question=1;
					  strHtml+="<tr align='center'><td colspan='5'>Group-"+(k+1)+"  ("+response[i].qptemplateSubSection[j].qptemplateGroup[k].groupText+") Total No. Of Questions:"+response[i].qptemplateSubSection[j].qptemplateGroup[k].noOfQuestions+"</td></tr>";
					  strHtml+="<tr>";
	
					  for(var qCount=1;qCount<=groupQuestCount;qCount++){
						 
						  strHtml+="<td><input type='text' value='Q"+question+"' readonly size=4px></td>";
						  if(qCount==5){
							  strHtml+="</tr>";
							  qCount=0;
							  groupQuestCount=groupQuestCount-5;
							  
							  if(groupQuestCount!=0){
							   strHtml+="<tr>";
							  }
							  
						  }
						  question++;
					  }
					  		strHtml+="</tr>";
					  		
					}
					strHtml+="</tr>";
					if(groupFlag!=1){
						strHtml+="<tr><td>No Group for the SubSection</td></tr>";
					}
			}
				
				strHtml+="</tr>";
				if(subSecFlag!=1){
					strHtml+="<tr bgcolor='#FF0000' align='center'><td colspan='5'>No SubSection for the Section</td></tr>";
				}
			}
			 $("#quesPreviewGrid").append(strHtml);
			 $('#quesPreviewGrid').append("</tbody>");
			 loadTemplateDetailForQuestion(templateId);
		},
		error : function() {
			$.alert.open('Error while loading Section');
		}
	});
}
 
 
 
 

