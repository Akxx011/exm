	/**
 * author nysa
 */
//var templateId =  $("#primTemplateId").val();
var templateId =0;


function loadNexttab() {
	
	templateId = $("#primTemplateId").val();
	
	checkAlreadyChekedCB();

	loadSubjectForParticularTemplate(templateId);
	

}

function checkAlreadyChekedCB(){
	
	if($("#isRevisitAllowedEdit").is(":checked")){
		$("#isRevisitAllowedEditSec").prop("checked",true);
		$("#isRevisitAllowedViewSec").prop("checked",true);
		document.getElementById('isRevisitAllowedEditSec').value =1;
		document.getElementById('isRevisitAllowedViewSec').value =1;
		$("#isRevisitAllowedEditSec").prop("disabled",true);
		$("#isRevisitAllowedViewSec").prop("disabled",true);
		}
	
	if($("#isQuestionShuffle").is(":checked")){
		$("#isQuestionShuffleSec").prop("checked",true);
		document.getElementById('isQuestionShuffleSec').value =1;
		$("#isQuestionShuffleSec").prop("disabled",true);
	}
	
	if($("#isOptionShuffle").is(":checked")){
		$("#isOptionShuffleSec").prop("checked",true);
		document.getElementById('isOptionShuffleSec').value =1;
		$("#isOptionShuffleSec").prop("disabled",true);
	}
	
	if(!$("#isRevisitAllowedEdit").is(":checked") && $("#isRevisitAllowedView").is(":checked")){
		$("#isRevisitAllowedViewSec").prop("checked",true);
		document.getElementById('isRevisitAllowedViewSec').value =1;
		document.getElementById('isQuestionShuffleSec').value =1;
		$("#isRevisitAllowedEditSec").prop("disabled",true);
		$("#isRevisitAllowedViewSec").prop("disabled",true);
	}
}
/*
 * This method will Load all the subject respective to the template Id and Set
 * all this data unto the table corresponding to this
 */
function loadSubjectForParticularTemplate(templateId) {

	var htmlStr = "<option value=-1>Select</option>";
	$.ajax({
		type : "get",
		url : "eonloadAllSubjectForParticularTemplate?templateId=" + templateId,

		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {
				htmlStr += "<option value=" + response[i].lookupId + ">"
						+ response[i].lookupName + "</option>";

			}

			$('#subjectIdSection').html(htmlStr);

			loadQuestionTypeForParticularTemplate(templateId);

		},

		error : function() {
			$.alert.open('Error while loadSubjectForParticularTemplate');
		}
	});
}

/*
 * This method will Load all the subject respective to the template Id and Set
 * all this data unto the table corresponding to this
 */

function loadQuestionTypeForParticularTemplate(templateId) {
	var htmlStr = "<option value=-1>Select</option>";
	$.ajax({
		type : "get",
		url : "eonloadQuestionTypeForParticularTemplate?templateId=" + templateId,

		cache : false,
		success : function(response) {
			for (var i = 0; i < response.length; i++) {

				htmlStr += "<option value=" + response[i].lookupId + ">"
						+ response[i].lookupName + "</option>";
			}
			$('#questionTypeID').html(htmlStr);

			loadSectionDetailForParticularTemplate(templateId);
		},
		error : function() {
			$.alert.open('Error while loadQuestionTypeForParticularTemplate');
		}
	});
}

/*
 * 
 */
function runningFormatter(value, row, index) {
	index++;
	return index;
}
function checkFormatter(value) {
	if (value == "1")
		value = 'Active';
	else
		value = 'Inactive';
	return value;
}
function editFormatter(value) {

	return value;
}
function deleteSectionFormatter(value, row, index) {

	return "<a href=#><span onclick=deleteSection('"+row.sectionId+"');><i class='glyphicon glyphicon-remove-sign' style='color: red;'></i></span><a>";
}
function setSubNameFormatter(value) {

	var subName = $("#subjectIdSection option[value=" + value + "]").text();
	return subName;
}
function actionFormatter(value) {

	return "<a href='#' onclick='loadSectionDetailForParticularSection("
			+ value
			+ ")'><div><i class='glyphicon glyphicon-pencil' ></i></div></a>";
}

/*
 * This method will Load all the data respective to the template Id and Set all
 * this data unto the table corresponding to this
 */
function loadSectionDetailForParticularTemplate(templateId) {
	$('#table').bootstrapTable('showLoading');
	var htmlStr = "";
	$
			.ajax({
				type : "get",
				url : "eonloadSectionDetailForParticularTemplate?templateId="
						+ templateId,

				cache : false,
				success : function(response) {
					$('#table').bootstrapTable('hideLoading');
					$('#notification').hide();
					$('#table').bootstrapTable('load', response);
					loadTemplateDetail(templateId);

				},
				error : function() {
					$.alert.open('Error while loadSectionDetailForParticularTemplate');
				}
			});
}
/*
 * 
 */

function loadTemplateDetail(templateId) {

	$.ajax({
		type : "get",
		url : "eonQPLoadTemplate?templateId=" + templateId,

		cache : false,
		success : function(response) {

			// $.alert.open(response[0].examIdObj.nameOfExam);
			$("#templateNameSection").text(response[0].templateName);
			$("#ExamSection").text(response[0].examIdObj.nameOfExam);
		},
		error : function() {
			$.alert.open('Error while loadTemplateDetail');
		}
	});
}
/*
 * This method will Load all the data respective to the sectionId and Set all
 * this data into the table corresponding to this.
 */

function loadSectionDetailForParticularSection(sectionId) {

	$("#sectionId").val(sectionId);
	$("#noOfQuestionsSection").prop("readonly", true);
	$('#noOfQuestionsSection').removeAttr('onblur');
	
	$.ajax({
		type : "get",
		url : "eonloadSectionDetailForParticularSection?sectionId=" + sectionId,

		cache : false,
		success : function(response) {

			$("#sectionfrm input[type=checkbox]").each(function() {
				var name = this.name;

				if (response[0][name] == 1) {
					eval("document.form2." + name + ".checked=true");
					eval("document.form2." + name + ".value=1");
				}
			})
			
			checkAlreadyChekedCB();

			$("#sectionfrm input[type=text],#sectionfrm input[type=textarea]")
					.each(
							function() {
								var name = this.name;

								eval("document.form2." + name + ".value='"
										+ response[0][name] + "'");
							})
			$("#sectionfrm select").each(
					function() {
						var name = this.name;
						// $.alert.open(name);
						eval("document.form2." + name + ".value='"
								+ response[0][name] + "'");

					})
			// eval("document.form2." + name + ".value='"
			// + response[0][name] + "'");

		},
		error : function() {
			$.alert.open('Error while loadSectionDetailForParticularSection');
		}
	});
}
/*
 * This method will save or update all the data into the section table
 */
function saveorUpdateSectionDeatil(sectionId) {
	var checkArray = [ "language", "sectionName", "maximumDuration",
			"minimumDuration", "subjectId", "sectionTotalMarks",
			"noOfSubsection", "noOfQuestions", "noOfQuestionsNeedToAttempt",
			"questionTypeID", "marksForCorrect",
			"marksForWrong", "marksForBlank" ];

	var msgArray = [ "Please select language", "please enter sectionName",
			"please enter maximumDuration", "please enter minimumDuration",
			"please enter subjectname", "please enter sectionTotalMarks",
			"please enter noOfSubsection", "please enter noOfQuestions",
			"please enter noOfQuestionsNeedToAttempt",
			"please enter questionType",
			"please enter marksForCorrect", "please enter marksForWrong",
			"please enter marksForBlank" ];
	if (validateFields(checkArray, 2, msgArray)) {
		$("#secTemplateId").val(templateId);
		var frm = $('#sectionfrm');
		if (confirm("Are you sure? Do you want to add or update")) {
			
			var noZeroField=checkSectionZeroFields();
			if(noZeroField){
			$("#isRevisitAllowedEditSec").prop("disabled",false);
			$("#isRevisitAllowedViewSec").prop("disabled",false);	
			$("#isQuestionShuffleSec").prop("disabled",false);
			$("#isOptionShuffleSec").prop("disabled",false);
			$.ajax({
				type : frm.attr('method'),
				url : frm.attr('action'),
				data : frm.serialize(),
				success : function(response) {
					$.alert.open("Successfully saved");
					CancelSectionDeatil();
				},
				error : function() {
					$.alert.open('Error while saveorUpdateSectionDeatil');
				}
			});
		}
		}
	}
}
/*
 * This method will CancelSectionDeatil all the data into the section table
 */
function CancelSectionDeatil() {
	var htmlstr = "<option value=-1>Select</option>";
	htmlstr += "<option value=1>English</option>";
	$("#language").html(htmlstr);

	loadSubjectForParticularTemplate(templateId);

	$("#sectionfrm input[type=checkbox]").each(function() {
		var name = this.name;

		eval("document.form2." + name + ".checked=false");
		eval("document.form2." + name + ".value=0");

	})

	$("#sectionfrm input[type=text],#sectionfrm input[type=textarea]").each(
			function() {
				var name = this.name;

				eval("document.form2." + name + ".value=''");
			})

}
/*
 * This method will set the value of all the checkboxes .if the checkbox is
 * checked the value will be 1 else the value will be 0.
 */
function setCheckBoxVal(obj, id) {
	if(id=='isRevisitAllowedEditSec'){
		if (obj.checked == true) {
		obj.value = 1;
		$("#isRevisitAllowedViewSec").prop("checked",true);
		document.getElementById('isRevisitAllowedViewSec').value =1;
		$("#isRevisitAllowedViewSec").prop("disabled",true);
		// $('#' + id).val("1");
		} else {
			obj.value = 0;
			$("#isRevisitAllowedViewSec").prop("disabled",false);
			// $('#' + id).val("0");

		}
	}
	else{
		if (obj.checked == true) {
			obj.value = 1;
			} else {
				obj.value = 0;
			}
	}
	

}
/*
 * This method will chk the number of question enter by user.the Sum of Question
 * for All section has been exceeded to the Question enter for this template
 */
function chkNoOfQuestion() {
	$("#marksForCorrect").val("");
	$("#marksForWrong").val("");
	$("#marksForBlank").val("");
	if($("#sectionTotalMarks").val()==""){
		$.alert.open("Please enter Total Marks First");
		$("#noOfQuestionsSection").val("");
		return;
	}
	var marksForCorrect=parseInt($("#sectionTotalMarks").val())/parseInt($("#noOfQuestionsSection").val());
	if(marksForCorrect>0){
	$("#marksForCorrect").val(marksForCorrect);
	$("#marksForWrong").val(marksForCorrect);
	$("#marksForBlank").val(marksForCorrect);
	$("#marksForCorrect").prop("readonly",true);
	}
	if( parseInt($("#noOfQuestionsSection").val()) > parseInt($("#noOfQuestions").val())){
		$.alert.open("No. of questions cannot be greater than no. of questions entered for the template");
		$("#noOfQuestionsSection").val(" ").focus();
		return;
	}
	$
			.ajax({
				type : "get",
				url : "eonchkNoOfQuestion?templateId=" + templateId,

				cache : false,
				success : function(response) {
					
					var noOfQuestionSection = parseInt($(
							"#noOfQuestionsSection").val());
//					if(noOfQuestionSection==""){
//						$.alert.open("hiiii");
//						$("#startQSrlNoSection").val("");
//						$("#lastQSrlNoSection").val("");
//						return;
//					}
					var noOfQuestionTemp = parseInt(response.noOfQuestionTemp);
					var sumOfQustion = parseInt(response.lastSrlNo)
							+ noOfQuestionSection;
					
					if (sumOfQustion > noOfQuestionTemp) {
						$.alert.open("Sum of Question for All section has been exceeded to the Question enter for this template");
						$("#noOfQuestionsSection").val("").focus();
						$("#startQSrlNoSection").val("");
						return;
					}
					
					if (response.lastSrlNo == undefined) {
						
						if(noOfQuestionSection==""){
							$("#startQSrlNoSection").val("");
							$("#lastQSrlNoSection").val("");
							return;
						}
						$("#startQSrlNoSection").val(1);
						$("#lastQSrlNoSection").val(noOfQuestionSection);
						
						return;
					}
					$("#startQSrlNoSection").val(
							parseInt(response.lastSrlNo) + 1);
					$("#lastQSrlNoSection").val(sumOfQustion);
					
				},
				error : function() {
					$.alert.open('Error while saveorUpdateSectionDeatil');
				}
			});
}



function chkTime() {

	if(parseInt($("#maximumDurationSection").val()) > parseInt($("#maximumDuration").val())){
		$.alert.open("Maximum duration cannot be greater than maximum duration entered for the template");
		$("#maximumDurationSection").val("");
		$("#maximumDurationSection").focus();
		return;
	}
	
	if (parseInt($("#minimumDurationSection").val()) >parseInt( $("#minimumDuration").val())) {
		$.alert.open("Minimum duration cannot be greater than minimum duration entered for the template");
		$("#minimumDurationSection").val("").focus();
		return;
	}
	if ($("#maximumDurationSection").val() == "") {
		$.alert.open("Please enter maximum duration");
		$("#minimumDurationSection").val("");
		// $("#maximumDurationSection").focus();
		return;
	}
	if (parseInt($("#maximumDurationSection").val()) == 0) {
		$.alert.open("Please enter the valid time");
		$("#maximumDurationSection").val("");
		$("#maximumDurationSection").focus();
		return;
	}
	if ($("#minimumDurationSection").val() == "") {
		return;
	}
	if (parseInt($("#minimumDurationSection").val()) == 0) {
		$.alert.open("Please enter the valid time");
		$("#minimumDurationSection").val("").focus();
		return;
	}
	if (parseInt($("#minimumDurationSection").val()) >parseInt($("#maximumDurationSection").val())) {
		$.alert.open("Minimum duration can't be greater than maimum duration");
		$("#minimumDurationSection").val("").focus();
		return;
	}
}
/*
 * 
 */
function chkQuestion() {
	if ($("#noOfQuestionsSection").val() == "") {
		$.alert.open("please First enter noOfQuestions");
		$("#noOfQuestionsNeedToAttempt").val("");
		$("#noOfQuestionsSection").focus();
		return;
	}
	if (parseInt($("#noOfQuestionsNeedToAttempt").val()) > parseInt($("#noOfQuestionsSection")
			.val())) {
		$.alert.open("noOfQuestionsNeedToAttempt can't be greater than noOfQuestionsSection");
		$("#noOfQuestionsNeedToAttempt").val("").focus();
		return;
	}
}

function checkTotalMarks(){
	sectionTotalMarks
	if(parseInt($("#sectionTotalMarks").val()) >parseInt($("#totalMarks").val())){
		$.alert.open("Section Total Marks can't be greater than Template Total Marks");
		$("#sectionTotalMarks").val("").focus();
		return;
	}
}

function checkSectionZeroFields(){
	var flag=true;
		$("#sectionfrm input[type=text],#sectionfrm input[type=textarea]").each(
					function() {
						var name = this.name;
						if(name=="marksForWrong" || name=="marksForBlank"){
							return true;
						}
						if(name==""){
							flag=true;
							return false;
						}
						var x=eval("document.form2." + name+".value");
						var y=document.form3.noOfQuestions.value;
						
		                if(x==0){
		                	eval("document.form2." + name + ".value=''");
		                	if(y==0){
			                	document.form3.startQSrlNo.value='';
			                	document.form3.lastQSrlNo.value='';	
			                }
		                	$.alert.open(name.toUpperCase()+" cannot be zero,Please enter valid value");
		                	eval("document.form2." + name + ".focus()");
		                	flag=false;
		                	return false;
		                }
		                
		               
					});
		return flag;
	}




