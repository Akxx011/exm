function loadEcb() {
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadEcb",
		cache : false,
		success : function(response) {
			var strHtml = "";
			jQuery.each(response, function(i, val) {
				strHtml += "<option value='" + val.ecbId + "'>" + val.ecbName
						+ "</option>";
			});
			$('#ecbId').html(strHtml);
			loadExam();
		},
		error : function() {
			$.alert.open('Error while loading loadEcb ');
		}
	});
}
function loadYear() {
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadYear",
		cache : false,
		success : function(response) {
			var strHtml = "<option value='-1'>Select Year</option>";
			jQuery.each(response, function(i, val) {
				strHtml += "<option value='" + val.yearId + "'>" + val.yearName
						+ "</option>";
			});
			$('#year').html(strHtml);
			
		},
		error : function() {
			$.alert.open('Error while loading loadYear ');
		}
	});
}
function loadExam() {
	blockU();
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadExam?ecbId=" + $("#ecbId").val(),
		cache : false,
		success : function(response) {
			unblockU();
			var strHtml = "<option value='-1'>Select Exam</option>";
			jQuery.each(response, function(i, val) {
				strHtml += "<option value='" + val.examId + "'>"
						+ val.nameOfExam + "</option>";
			});
			$('#examId').html(strHtml);
			loadSlot();
		},
		error : function() {
			unblockU();
			$.alert.open('Error while loading loadExam ');
		}
	});
}

function loadSlot() {

	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadSlot?examId=" + $("#examId").val(),
		cache : false,
		success : function(response) {
			var strHtml = "";
			jQuery.each(response, function(i, val) {
				strHtml += "<option name='slotId' value='" + val.slotID + "'>" + val.startTime.substring(0, 5)
						+ "-" + val.endTime.substring(0, 5) + "</option>";
			});
			if(strHtml!="")
			$('#slotId').html(strHtml);
			loadQPTemplateList();
		},
		error : function() {
			$.alert.open('Error while loading loadSlot ');
		}
	});
}

function runningFormatter(value, row, index) {
	index++;
    return index;
}
function langFormatter(value, row, index) {
	var data="English";
    return data;
}
function publishFormatter(value, row, index) {
 	var isDisabled="";
	var publishMsg="Publish";
	if(row.isPublish == "1"){
	isDisabled="disabled";
	publishMsg="Publised";
	} 
	return  "<input class='btn btn-warning btn-xs' "+isDisabled+" alt="+publishMsg+"   type=button value='"+publishMsg+"' onclick='dispose("+row.ecbId+");'>";
} 
function prepareFormatter(value, row, index) {
 	var isDisabled="";
	var publishMsg="Prepare";
	if(row.isPublish == "1"){
	isDisabled="disabled";
	publishMsg="Prepared";
	} 
	return  "<input class='btn btn-warning btn-xs' "+isDisabled+" alt="+publishMsg+"   type=button value='"+publishMsg+"' onclick='prepareMstCopy("+row.templateId+");'>";
} 
function viewFormatter(value, row, index) {
	return  "<a href='#' onclick='masterCopyReport("+row.templateId+");' ><div><i class='glyphicon glyphicon-eye-open'></i></div><a>";	
}
function loadQPTemplateList() {
	
	blockU();
	if($("#slotId").val()=="" || $("#slotId").val()=="null" || $("#slotId").val()==null)$("#slotId").val("-1");
	$('#table').bootstrapTable('showLoading');
	$.ajax({
		type : "get",
		url : "eonQPTemplateLoadListData?ecbId=" + $("#ecbId").val() + "&examId="
				+ $("#examId").val() + "&year=" + $("#year").val() + "&status="
				+ $("#status").val() + "&slotId=" + $("#slotId").val()
				+ "&languageId=" + $("#languageId").val(),
		cache : false,
		success : function(response) {
			unblockU();
			$('#table').bootstrapTable('hideLoading');
 			$('#notification').hide();  
 			$('#table').bootstrapTable('load', response); 
//			$.alert.open(response);
		},
		error : function() {
			unblockU();
			$('#table').bootstrapTable('hideLoading');
 			$('#notification').hide();  
			$.alert.open('Error while loading loadDataForUpdate');
		}
	});
}
function prepareMstCopy(templateId)
{
	blockU();
	$.ajax({
		type : "get",
		url : "eonqpTemplatePrepare?templateId=" + templateId,
		cache : false,
		success : function(response) {
			unblockU();
			alert(response);
		},
		error : function() {
			unblockU();
			alert("Error while preparing master copy.");
		}
	});
}
function masterCopyReport(templateId){
	blockU();
	window.location.href = 'eonQPTemplateMasterCopyReport?templateId='+templateId;
	unblockU();
}
