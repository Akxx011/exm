var templateId = 1;/* $("#primTemplateId").val(); */
function loadQuestion() {

	
	// loadQuestionList();
	loadTemplateDetailForQuestion(templateId);
}
function loadTemplateDetailForQuestion(templateId) {

	$.ajax({
		type : "get",
		url : "eonQPLoadTemplate?templateId=" + templateId,

		cache : false,
		success : function(response) {

		
			$("#templateNameQuestion").text(response[0].templateName);
			$("#ExamQuestion").text(response[0].examIdObj.nameOfExam);
			loadSection();
		},
		error : function() {
			$.alert.open('Error while loadTemplateDetail');
		}
	});
}

function loadQuestionList() {

	$("#table1").bootstrapTable('showLoading');
	$.ajax({
		type : "get",
		url : "eonQPSectionLoad?templateId=" + templateId,
		cache : false,
		success : function(response) {

			$('#table1').bootstrapTable('hideLoading');
			$('#notification').hide();
			$('#table1').bootstrapTable('load', response);
			// $.alert.open(response);
		},
		error : function() {
			$.alert.open('Error while loading Question List');
		}
	});
}
/*
 * This methosd wll load all the section for a particular template Id
 */
function loadSection() {

	var sectionStr = "<option value=-1>Select Section</option>";

	$.ajax({
		type : "get",
		url : "eonQPSectionLoad?templateId=" + templateId,
		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {

				sectionStr += "<option value=" + response[i].sectionId + ">"
						+ response[i].sectionName + "</option>";
			}
			$('#sectionQuestion').html(sectionStr);
		},
		error : function() {
			$.alert.open('Error while loading Section');
		}
	});
}

function loadSubSecDetailForParticularSectionCode() {

	$.ajax({
		type : "get",
		url : "eonQPSubSecDetailLoad?sectionId=" + $("#subSecSectionId").val()
				+ "&subSectionCodeId=" + $("#subSectionCodeId").val(),
		cache : false,
		success : function(response) {
			$.alert.open(response.subSectionId);
			$('#table1').bootstrapTable('hideLoading');
			$('#notification').hide();
			$('#table1').bootstrapTable('load', response);

			/*
			 * if(response!=null) {
			 * $("#SubSectionHeading").text(response.subSectionHeading);
			 * if(response.isSectionQuestionShuffle==1){
			 * $("#isSubSecQuestionShuffle").prop('checked',true); }
			 * 
			 * if(response.isSectionOptionShuffle==1){
			 * $("#isSubSecOptionShuffle").prop('checked',true); }
			 * 
			 * 
			 * $('#table').bootstrapTable('load', response);
			 *  }
			 */

		},
		error : function() {
			$.alert.open('Error while loading SubSection detail');
		}
	});
}
/*
 * This method will load all the subsection detail for a particular SectionId
 */
function loadAllSubSecPerSection() {
	
	var subSectionStr = "<option value=-1>Select Section</option>";
	$('#groupQuestion').html(subSectionStr);
	$.ajax({
		type : "get",
		url : "eonloadAllSubSecPerSection?sectionId="
				+ $("#sectionQuestion :selected").val(),
		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {

				subSectionStr += "<option value=" + response[i].subSectionId
						+ ">" + response[i].subSectionHeading + "</option>";
			}
			$('#subSecQuestion').html(subSectionStr);

		},
		error : function() {
			$.alert.open('Error while loading SubSection detail');
		}
	});
}
/*
 * this method will load all the group detail for a particular subsection id
 */
function loadAllGroupDetailForSubSec() {

	var groupStr = "<option value=-1>Select Section</option>";
	
	$.ajax({
		type : "get",
		url : "eonloadAllGroupDetailForSubSec?subSectionId="
				+ $("#subSecQuestion :selected").val(),
		cache : false,
		success : function(response) {
			
			for (var i = 0; i < response.length; i++) {

				groupStr += "<option value=" + response[i].groupId + ">"
						+ response[i].groupText + "</option>";
			}
			$('#groupQuestion').html(groupStr);

			

		},
		error : function() {
			$.alert.open('Error while loading group detail');
		}
	});
}
function loadGroupDetailForParticularGroup() {

	var groupStr = "<option value=-1>Select Section</option>";
	
	$.ajax({
		type : "get",
		url : "eonloadGroupDetailForParticularGroup?groupId="
				+ $("#groupQuestion :selected").val(),
		cache : false,
		success : function(response) {
			
			for (var i = 0; i < response.length; i++) {

				groupStr += "<option value=" + response[i].groupId + ">"
						+ response[i].groupText + "</option>";
			}
			$('#groupQuestion').html(groupStr);

			

		},
		error : function() {
			$.alert.open('Error while loading group detail');
		}
	});
}

/*
 * This method will Load all the data respective to the sectionId and Set all
 * this data into the table corresponding to this.
 */
function runningFormatter1(value, row, index) {
	index++;
    return index;
}
function subSectionFormatterforQP(value, row, index) {
	var data = eval(row);
	return data.qptemplateSubSection[index].subSectionHeading;
    //return row.qptemplateSubSection.subSectionId;
}
function groupFormatterforQP(value, row, index) {
	var data = eval(row);
	var toReturn = data.qptemplateSubSection[index].qptemplateGroup[index].groupText;
	return toReturn;

}




function loadSectionDetailForParticularSectionForQuestion() {
	
	$('#qpQuestionTbl').bootstrapTable('showLoading');
	$
	.ajax({
		type : "get",
		url : "eonloadSectionDetailForParticularSection?sectionId="
				+ $("#sectionQuestion :selected").val(),

		cache : false,
		success : function(response) {
			
			$('#qpQuestionTbl').bootstrapTable('hideLoading');
			$('#notification').hide();
			$('#qpQuestionTbl').bootstrapTable('load', response);
				

		},
		error : function() {
			$.alert.open('Error while loadSectionDetailForParticularSection');
			$('#qpQuestionTbl').bootstrapTable('hideLoading');
 			$('#notification').hide();  
		}
	});
}

