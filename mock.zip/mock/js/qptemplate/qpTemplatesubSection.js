//var templateId = $("#primTemplateId").val();
var templateId = 0;
var noOfSectionQuestion=0;
function loadSubSectionPage() {
	templateId = $("#primTemplateId").val();
	/*if($("#isQuestionShuffleSec").is(":checked")){
		$("#isSubSecQuestionShuffle").prop("checked",true);
		document.getElementById('isSubSecQuestionShuffle').value =1;
		$("#isSubSecQuestionShuffle").prop("disabled",true);
		
		$("#isQuestionShuffleGroup").prop("checked",true);
		document.getElementById('isQuestionShuffleGroup').value =1;
		$("#isQuestionShuffleGroup").prop("disabled",true);
	}
	
	if($("#isOptionShuffleSec").is(":checked")){
		$("#isSubSecOptionShuffle").prop("checked",true);
		document.getElementById('isSubSecOptionShuffle').value =1;
		$("#isSubSecOptionShuffle").prop("disabled",true);
		
		$("#isOptionShuffleGroup").prop("checked",true);
		document.getElementById('isOptionShuffleGroup').value =1;
		$("#isOptionShuffleGroup").prop("disabled",true);
	}*/
	loadTemplateDetailForSubSection(templateId);
	populateSubSecList(templateId);
	}

function loadTemplateDetailForSubSection(templateId) {

	$.ajax({
		type : "get",
		url : "eonQPLoadTemplate?templateId=" + templateId,

		cache : false,
		success : function(response) {
			
			$("#templateNameSubSection").text(response[0].templateName);
			$("#ExamSubSection").text(response[0].examIdObj.nameOfExam);
			loadSectionForSubSec();
		},
		error : function() {
			$.alert.open('Error while loadTemplateDetail');
		}
	});
}
function loadSectionForSubSec() {

	var sectionStr = "<option value=-1>Select Section</option>";

	$.ajax({
		type : "get",
		url : "eonQPSectionLoad?templateId=" + templateId,
		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {

				sectionStr += "<option value=" + response[i].sectionId + ">"
						+ response[i].sectionName.toUpperCase() + "</option>";
			}
			$('#subSecSectionId').html(sectionStr);
			loadGroupType();
		},
		error : function() {
			$.alert.open('Error while loading Section');
		}
	});
}

function loadSubSection(obj) {

	var subSectionStr = "<option value=-1>Select SubSection</option>";

	if (obj.value != -1) {

		$.ajax({
			type : "get",
			url : "eonQPSubSectionLoad?sectionId=" + obj.value,
			cache : false,
			success : function(response) {

				var noOfSubSection = response.noOfSubsection;
				noOfSectionQuestion=response.noOfQuestions;
					
				if (response.isQuestionShuffle == 1) {
					$("#isSubSecQuestionShuffle").prop('checked',true);
					document.getElementById('isSubSecQuestionShuffle').value =1;
					$("#isSubSecQuestionShuffle").prop("disabled",true);
					
					$("#isQuestionShuffleGroup").prop("checked",true);
					document.getElementById('isQuestionShuffleGroup').value =1;
					$("#isQuestionShuffleGroup").prop("disabled",true);
				}

				if (response.isOptionShuffle == 1) {
					$("#isSubSecOptionShuffle").prop('checked',true);
					document.getElementById('isSubSecOptionShuffle').value =1;
					$("#isSubSecOptionShuffle").prop("disabled",true);
					
					$("#isOptionShuffleGroup").prop("checked",true);
					document.getElementById('isOptionShuffleGroup').value =1;
					$("#isOptionShuffleGroup").prop("disabled",true);
				}
				
				for (i = 1; i <= noOfSubSection; i++) {
					subSectionStr += "<option value=" + i + ">SubSection-" + i
							+ "</option>";
				}

				$('#subSectionCodeId').html(subSectionStr);
				$('#subSecToAdd').text(noOfSubSection);
			},
			error : function() {
				$.alert.open('Error while loading SubSection');
			}
		});
	}

	else {
		$('#subSectionCodeId').html(subSectionStr);
	}

}

function loadGroupType() {

	var groupTypeStr = "<option value=-1>Select Group Type</option>";

	$.ajax({
		type : "get",
		url : "eonQPGroupTypeLoad",
		cache : false,
		success : function(response) {

			for (var i = 0; i < response.length; i++) {

				groupTypeStr += "<option value=" + response[i].lookupId
						+ ">" + response[i].lookupName.toUpperCase() + "</option>";
			}
			$('#groupType').html(groupTypeStr);
		},
		error : function() {
			$.alert.open('Error while loading Group Type');
		}
	});
}

function onSaveSubSection() {
	var checkArray = [ "SectionId", "subSectionCode", "SubSectionHeading",
			"groupText", "groupType", "noOfQuestions" ];

	var msgArray = [ "Please select Section", "please enter subSection",
			"please enter SubSectionHeading", "please enter groupText",
			"please enter groupType", "please enter noOfQuestions",
			"please enter noOfSubsection", "please enter noOfQuestions" ];
	if (validateFields(checkArray, 3, msgArray)) {

		var frm = $('#subSectionfrm');
		$("#subSecTemplateId").val(templateId);
		if (confirm("Are you sure? Do you want to add the Group")) {
		
		var noZeroField=checkZero();
		if(noZeroField){
			$("#isSubSecQuestionShuffle").prop("disabled",false);
			$("#isSubSecOptionShuffle").prop("disabled",false);
			$("#isQuestionShuffleGroup").prop("disabled",false);
			$("#isOptionShuffleGroup").prop("disabled",false);
			$.alert.open(frm.serialize());
			$
			.ajax({
				type : frm.attr('method'),
				url : frm.attr('action'),
				data : frm.serialize(),
				success : function(response) {
					if (response == 1) {
						$.alert.open("SubSection and Group data has been saved successfully");
//						 populateSubSecList();
					} else {
						$.alert.open("SubSection and Group data has not been saved");
					}
					CancelSubSectionDeatil();
				},
				error : function() {
					$.alert.open('Error while Saving the SubSection data');
				}
			});
		}	
		
		}
				
	}

}
function CancelSubSectionDeatil() {
	var htmlstr = "<option value=-1>Select</option>";
	

	

	$("#subSectionfrm input[type=checkbox]").each(function() {
		var name = this.name;

		eval("document.form3." + name + ".checked=false");
		eval("document.form3." + name + ".value=0");

	})
	$("#subSectionfrm input[type=select]").each(function() {
		var name = this.name;

		eval("document.form3." + name + ".html=htmlstr");
		

	})
	$("#subSectionfrm input[type=text],#subSectionfrm input[type=textarea]").each(
			function() {
				var name = this.name;

				eval("document.form3." + name + ".value=''");
			})

}

function checkZero(){
var flag=true;
	$("#subSectionfrm input[type=text],#subSectionfrm input[type=textarea]").each(
				function() {
					var name = this.name;
					if(name==""){
						flag=true;
						return false;
					}
					var x=eval("document.form3." + name+".value");
	                if(x==0){
	                	eval("document.form3." + name + ".value=''");
	                	document.form3.startQSrlNo.value='';
	                	document.form3.lastQSrlNo.value='';	
	                	$.alert.open(name.toUpperCase()+" cannot be zero,Please enter valid value");
	                	eval("document.form3." + name + ".focus()");
	                	flag=false;
	                	return false;
	                }
	               
				});
	return flag;
}

function chkNoOfQuestionForSubSection() {
 var sectionId=$("#subSecSectionId").val();
 if( parseInt($("#noOfQuestionsSubSec").val())>noOfSectionQuestion){
		$.alert.open("No. of questions cannot be greater than no. of questions entered for the Section");
		$("#noOfQuestionsSubSec").val(" ").focus();
		return;
	}
 if($("#noOfQuestionsSubSec").val()==""){
	 return;
 }
	$
			.ajax({
				type : "get",
				url : "eonchkNoOfQuestionForSubSection?sectionId=" + sectionId,

				cache : false,
				success : function(response) {
					var noOfQuestionSubSection = parseInt($(
							"#noOfQuestionsSubSec").val());
					if (response.lastSrlNo == undefined) {
						$("#startQSrlNoSubSec").val(1);
						$("#lastQSrlNoSubSec").val(noOfQuestionSubSection);
						return;
					}

					var noOfQuestionForSection = parseInt(response.noOfQuestionTemp);

					var sumOfQustion = parseInt(response.lastSrlNo)
							+ noOfQuestionSubSection;

					if (sumOfQustion > noOfQuestionForSection) {
						$.alert.open("Sum of Question for All sub section has been exceeded to the Question enter for this Section");
						$("#noOfQuestionsSubSec").val("").focus();
						$("#startQSrlNoSubSec").val("");
						$("#lastQSrlNoSubSec").val("");
						return;
					}
					$("#startQSrlNoSubSec").val(
							parseInt(response.lastSrlNo) + 1);
					$("#lastQSrlNoSubSec").val(sumOfQustion);
				},
				error : function() {
					$.alert.open('Error while saveorUpdateSectionDeatil');
				}
			});
}

function loadSubSectionDetail() {
	if ($("#subSecSectionId").val()!=-1 && $("#subSectionCodeId").val() != -1) {

		$
				.ajax({
					type : "get",
					url : "eonQPSubSecDetailLoad?sectionId="
							+ $("#subSecSectionId").val()
							+ "&subSectionCodeId="
							+ $("#subSectionCodeId").val(),
					cache : false,
					success : function(response) {
						
						if (response != null && response != "") {
							$("#SubSectionHeading").text(
									response.subSectionHeading);
							
							if (response.isSectionQuestionShuffle == 1) {
								if(!$("#isSubSecQuestionShuffle").is("checked")){
									
									$("#isSubSecQuestionShuffle").prop('checked',true);
									document.getElementById('isSubSecQuestionShuffle').value =1;
									
									$("#isQuestionShuffleGroup").prop("checked",true);
									document.getElementById('isQuestionShuffleGroup').value =1;
									$("#isQuestionShuffleGroup").prop("disabled",true);
								}
								
							}

							if (response.isSectionOptionShuffle == 1) {
								if(!$("#isSubSecOptionShuffle").is("checked")){
								$("#isSubSecOptionShuffle").prop('checked',true);
								document.getElementById('isSubSecOptionShuffle').value =1;
								
								$("#isOptionShuffleGroup").prop("checked",true);
								document.getElementById('isOptionShuffleGroup').value =1;
								$("#isOptionShuffleGroup").prop("disabled",true);
								}
							}

						} else {
							$.alert.open("For the selected Sub Section no data has been added");
							$("#SubSectionHeading").val("");
							//$("#isSubSecQuestionShuffle").prop("checked",false);
							//$("#isSubSecOptionShuffle").prop("checked",false);
								
						}

					},
					error : function() {
						$.alert.open('Error while loading SubSection detail');
					}
				});
	}
}




/*function responseHandler(res) {
    var flatArray = [];
    $.each(res, function(i, element) { 
        flatArray.push(JSON.flatten(element));
    });
    return flatArray;
}*/

function populateSubSecList(templateId) {

$('#subSectionTbl').bootstrapTable('showLoading');
$.ajax({
	type : "get",
	url : "eonQPSectionLoad?templateId="+templateId,
	cache : false,
	success : function(response) {
		debugger;
		$('#subSectionTbl').bootstrapTable('hideLoading');
		$('#notification').hide();
		$('#subSectionTbl').bootstrapTable('load', eval(response));
	},
	error : function() {
		$.alert.open('Error while loading SubSection detail');
		$('#subSectionTbl').bootstrapTable('hideLoading');
		$('#notification').hide();  
	}
});
}

//****************************************

var groupIndex = 0;
function runningFormatter(value, row, index) {
	index++;	
	return index;
}

function sectionFormatter(value, row, index) {
	var data = eval(row);
	return data.sectionName;
    //return row.qptemplateSubSection.subSectionId;
}
function subSectionFormatter(value, row, index) {
	var data = eval(row);
	return data.qptemplateSubSection[index].subSectionHeading;
    //return row.qptemplateSubSection.subSectionId;
}
function groupFormatter(value, row, index) {
	var data = eval(row);
	var toReturn = data.qptemplateSubSection[index].qptemplateGroup[index].groupText;
//	groupIndex++;
	return toReturn;
    //return row.qptemplateSubSection.subSectionId;
}

function noOfQuestionsFormatter(value, row, index) {
	var data = eval(row);
	var toReturn = data.qptemplateSubSection[index].qptemplateGroup[index].noOfQuestions;
	groupIndex++;
	return toReturn;
}
function startQSrlNoFormatter(value, row, index) {
	var data = eval(row);
	var toReturn = data.qptemplateSubSection[index].qptemplateGroup[index].startQSrlNo;
	groupIndex++;
	return toReturn;
}
function lastQSrlNoFormatter(value, row, index) {
	var data = eval(row);
	var toReturn = data.qptemplateSubSection[index].qptemplateGroup[index].lastQSrlNo;
	groupIndex++;
	return toReturn;
}
function isQuestionShuffleFormatter(value, row, index) {
	var data = eval(row);
	var toReturn = data.qptemplateSubSection[index].qptemplateGroup[index].isQuestionShuffle;
	groupIndex++;
	return toReturn;
}
function isOptionShuffleFormatter(value, row, index) {
	var data = eval(row);
	var toReturn = data.qptemplateSubSection[index].qptemplateGroup[index].isOptionShuffle;
	groupIndex++;
	return toReturn;
}

function editSubSectionFormatter(value, row, index){
	var data = eval(row);
   var comp= data.qptemplateSubSection[index].subSectionId;
	return "<a href='#' onclick='>>>>>>>("+ comp+ ")'><div><i class='glyphicon glyphicon-pencil' style='color:green;' ></i></div></a>";
}
function deleteSubSectionFormatter(value, row, index){
	var data = eval(row);
	var comp= data.qptemplateSubSection[index].subSectionId;
	return "<a href='#' onclick='>>>>>>>("+comp + ")'><div><i class='glyphicon glyphicon-remove-circle' style='color:red;' ></i></div></a>";
}


/*function responseHandler(res){
	 var flatArray = [];
	    $.each(res, function(i, element) { 
	        flatArray.push(JSON.flatten(element));
	    });
	    return flatArray;
}*/
//*******************************************






function setCBSubSecQuesVal(obj,uncheckVal,checkVal)
{
	if (obj.checked == true) {
		obj.value = 1;
		$("#isQuestionShuffleGroup").prop("checked",true);
		document.getElementById('isQuestionShuffleGroup').value =1;
		$("#isQuestionShuffleGroup").prop("disabled",true);
		} 
	else {
			obj.value = 0;
			$("#isQuestionShuffleGroup").prop("disabled",false);

		}
}

function setCBSubSecOptVal(obj,uncheckVal,checkVal)
{
	if (obj.checked == true) {
		obj.value = 1;
		$("#isOptionShuffleGroup").prop("checked",true);
		document.getElementById('isOptionShuffleGroup').value =1;
		$("#isOptionShuffleGroup").prop("disabled",true);
		} 
	else {
			obj.value = 0;
			$("#isOptionShuffleGroup").prop("disabled",false);

		}
}

