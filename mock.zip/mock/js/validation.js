/*
 File Name 		: validation.js
 Version	  		: 1.0
 Developer 		: Amit Kumar yadav
 Supported by 	: 
 Guided By		:
 */

/*
 Note --> 
 1. please name your form as form1;
 2. add your validation string in getValidateStr() function
 3. Add message in getMsg() function

 Warning : NO CHANGE WILL BE REFLECTED IN ORIGINAL VALIDATION FILE WITHOUT amit kumar yadav
 PERMISSION	 
 */

/*
 List of functions in this file

 1>	function getValidateStr(index)
 2>	function getMsg(index,conName)
 3>	function validateData(e,index)
 4>	function validAmount(obj)
 5>	function compareDate(frDate,toDate)
 6>	function validateFields(checkArray,mode)
 7>	function isDate(theField)
 8>	function IsAgeValid(theField)
 9>	function submitForm()
 10>	function removeStrSpace(str)
 11>	function daysInFebruary (year)
 12>	function DaysInMonth(mon, year) 
 13> function getSeperator(dtStr)	
 14>	function getMonthInt(str)
 15> function parseDate(dtStr,seprator,mode)
 16> function initilizeVar()
 17> function validateBeforeAddTocart(obj,fieldArray,msgArray)//added by Amit yadav
 18> function isChecked(obj,msg);//added by Amit yadav
 19> function checkCharactorCount(obj,len,msg);//added by Amit yadav
 20> function changeCheckboxVal(obj,uncheckVal,checkVal)//added by Amit yadav
 */

/*============================Global Variables declares here=====================================*/
var intDay, intMon, intYear;

/*
 * ============================Function Starts from
 * here==========================================
 */

/*
 * this function returns the requested string for validations, any validating
 * string can be appended in this function just before default keyword
 */
function getValidateStr(index) {
	var str = "";

	switch (index) {
	case 1: // for validating email
		str = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_@.";
		break;

	case 2: // for validating telephone no
		str = "1234567890-";
		break;

	case 3: // for validating address
		str = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-/,.#$()';: ";
		break;

	case 4: // for validating name
		str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ .";
		break;

	case 5: // numeric only
		str = "1234567890";
		break;

	case 6: // numeric with space
		str = "1234567890 ";
		break;

	case 7: // for validating amount
		str = "1234567890.";
		break;

	case 8: // alphanumeric
		str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		break;

	case 9: // alphanumeric with space
		str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890 ";
		break;

	case 10: // Character only
		str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		break;

	case 11: // Character with space
		str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ";
		break;

	case 12: // Upper character only
		str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		break;

	case 13: // Upper character with space
		str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";
		break;

	case 14: // Lower character
		str = "abcdefghijklmnopqrstuvwxyz";
		break;

	case 15: // Lower character with space
		str = "abcdefghijklmnopqrstuvwxyz ";
		break;

	case 16: // for entering the test name
		str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-().1234567890+'/& ";
		break;

	case 17: // for validating batchno
		str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890-/()*<>.;:{}[]%";

	case 18: // for validating batchno
		str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890-()<>._@ ";

	case 19: // for validating item name
		str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890-()<>._+%*~!$ ";
		
	case 20: // numeric only without 0
		str = "123456789";
		break;

	} // end of Switch statement
	return str;
}

// this function will have the user defined messages
function getMsg(index, conName) {
	var msgStr = "";

	switch (index) {
	case 1:
		msgStr = "Invalid amount entered [" + conName + "]";
		break;
	case 2:
		msgStr = "Invalid e-mail entered [" + conName + "]";
		break;
	case 3:
		msgStr = "Invalid Date entered [" + conName + "]";
		break;
	case 4:
		msgStr = "From Date is greater than To Date [" + conName + "]";
		break;
	case 5:
		msgStr = "Current Date is greater than " + conName;
		break;
	case 6:
		msgStr = "[" + conName + "] is blank";
		break;
	case 7:
		msgStr = "[" + conName + "] is not selected";
		break;
	case 8:
		msgStr = "Invalid age entered [" + conName + "]";
	} // end of switch statement

	$.alert.open(msgStr);
	return;
}

// this function accepts index, based on index it validates the specified
// character within the string
// defined in getValidateStr function. it validates single character at a time.
function validateData(e, index) {
	var key, keychar, str;

	if (window.event)
		key = window.event.keyCode;
	else {
		if (e)
			key = e.which;
		else
			return true;
	}

	keychar = String.fromCharCode(key);

	// control keys
	if ((key == null) || (key == 0) || (key == 8) || (key == 9) || (key == 13)
			|| (key == 27))
		return true;
	else {
		str = getValidateStr(index);
		if (((str).indexOf(keychar) > -1))
			return true;
		else
			return false;
	}

}// end of validateStr function

// this function validates the amount.this function requires the object
// call this function if you have validated each & every digit using
// validateData function
function validAmount(obj) {
	var index, len;
	var tempStr;
	var sts = 0;

	len = obj.value.length;
	tempStr = obj.value;
	index = tempStr.indexOf(".");

	if (index > -1) // amount is in decimal
	{
		if (len == index + 1) // No digit after decimal point
			sts = 1;
		else {
			if (tempStr.indexOf(".", index + 1) > -1) // more than one decimal
				// point
				sts = 1;
		}
	} // end if

	if (sts == 1) {
		getMsg(1, obj.name);
		obj.focus();
		return false;
	}

	return true;

}// end of amountOnly

// this function compares two date. pass blank to frDate if you want to compare
// toDate with current Date
// this function accepts the object. date should be dd-mm-yyyy format if mode =
// 1 otherwise dd-mmm-yyyy
function compareDate(frDate, toDate, mode) {
	var frValue, toValue, frYear, frMon, frDay, sts = 0;

	// validating todate
	if (frDate == "" || frDate == null) {
		frValue = new Date;
		frYear = frValue.getYear();
		frMon = frValue.getMonth();
		frDay = frValue.getDate();
	} else {
		if (isDate(frDate, mode) == true) {
			frYear = intYear;
			frMon = intMon;
			frDay = intDay;
		} else {
			frDate.focus();
			return false;
		}
	}

	//
	if (isDate(toDate, mode) == true) {
		if (frYear > intYear)
			sts = 1;
		else {
			if (frYear == intYear) {
				if (frMon > intMon)
					sts = 1;
				else {
					if (frMon == intMon) {
						if (frDay > intDay)
							sts = 1;
					}
				}
			}
		}
	} else {
		toDate.focus();
		return false;
	}

	if (sts == 1) {
		if (frDate == "" || frDate == null) // validating current date with
			// toDate
			getMsg(5, toDate.name);
		else {
			$.alert.open(frDate.name + " is greater than " + toDate.name);
			frDate.focus();
		}

		return false;
	}

	return true;

}

/*
 * this function checks those fields that is in checkArray for not null and
 * submits the form if mode = 1 checkArray = new Array("Control Name1","Control
 * Name 2",-----) for calling this function mode parameter
 */
function validateFields(checkArray, mode, msgArray) {
	var i, type;
	var arrLen = checkArray.length;
	var obj;

	for (i = 0; i < arrLen; i++) {
		if(mode==0)
		{
		obj = document.form1.elements[checkArray[i]];
		}
		if(mode==1)
		{
		obj = document.form1.elements[checkArray[i]];
		}
		if(mode==2)
		{
		obj = document.form2.elements[checkArray[i]];
		}
		if(mode==3)
		{
		obj = document.form3.elements[checkArray[i]];
		}
		if(mode==4)
		{
		obj = document.form4.elements[checkArray[i]];
		}
		if(mode==5)
		{
		obj = document.form5.elements[checkArray[i]];
		}
		type = obj.type;
		switch (type) {
		case "text":
			if (obj.value == null || obj.value == ""
					|| obj.value.replace(/\s*/, "") == "") {
//				alert("helo");
				$.alert.open(msgArray[i]);
				obj.focus();
				obj.style.border = "1px solid #ff0000";
				return false;
			}
			break;
		case "password":
			if (obj.value == null || obj.value == ""
					|| obj.value.replace(/\s*/, "") == "") {
				$.alert.open(msgArray[i]);
				obj.focus();
				obj.style.border = "1px solid #ff0000";
				return false;
			}
			break;

		case "select-one":
			if (obj.value == 0 || obj.value == -1) {
				$.alert.open(msgArray[i]);
				obj.style.border = "1px solid #ff0000";
				return false;
			}
			break;

		case "textarea":
			if (obj.value == null || obj.value == ""
					|| obj.value.replace(/\s*/, "") == "") {
				$.alert.open(msgArray[i]);
				obj.focus();
				obj.style.border = "1px solid #ff0000";
				return false;
			}
			break;
		case "file":
			if (obj.value == null || obj.value == ""
					|| obj.value.replace(/\s*/, "") == "") {
				$.alert.open(msgArray[i]);
				obj.focus();
				obj.style.border = "1px solid #ff0000";
				return false;
			}
			break;
		}
	}

	//if (mode == 1)
		//submitForm();
	return true;

}// end of validateFun

// this function validates the date. the format should be dd-mm-yyyy or
// dd/mm/yyyy or dd.mm.yyyy
// if mode = 1 otherwise dd/mmm/yyyy or dd-mmm-yyyy or dd.mmm.yyyy
function isDate(theField, mode) {
	var dtStr = removeStrSpace(theField.value);
	var seprator = "";

	if (dtStr == "")
		return false;
	seprator = getSeperator(dtStr) // function that returns seperator
	if (seprator != "") {
		if (parseDate(dtStr, seprator, mode) == true) {
			theField.value = dtStr;
			return true;
		}
	}

	getMsg(3, theField.name); // display error message
	theField.focus();
	return false;
}
// End OF Date Method

/* this function validates the age */
function IsAgeValid(theField) {
	if (theField.value <= 0 || theField.value > 130) {
		getMsg(8, theField.name);
		theField.focus();
		return false;
	}
	return true;
}// End of function IsAgeValid()

/* this function submits the page */
function submitForm() {
	document.form1.submit();
}// end of validateFun

/* Function For Removing spaces */
function removeStrSpace(str) {
	var j;
	var len = str.length;
	var retStr = "";

	for (j = 0; j <= len; j++) {
		if (str.charAt(j) != " ")
			retStr += str.charAt(j);
	}
	return retStr;
}

/* Function For Removing spaces */
function removeStrStartSpace(str) {
	var j;
	var len = str.length;
	var retStr = "";

	for (j = 0; j <= len; j++) {
		if (str.charAt(j) != " ") {
			retStr = str.substr(j);
			break;
		}
	}
	return retStr;
}

// returns day in feb month for specified year
function daysInFebruary(year) {
	return (((year % 4 == 0) && ((!(year % 100 == 0)) || (year % 400 == 0))) ? 29
			: 28);
}

// this function returns no of days in a month for the specified year
function DaysInMonth(mon, year) {
	var retVal;

	retVal = 31;
	if (mon == 4 || mon == 6 || mon == 9 || mon == 11) {
		retVal = 30;
	}
	if (mon == 2) {
		retVal = daysInFebruary(year);
	}
	return retVal;
}

// this function finds the seperator used for seperating the date
function getSeperator(dtStr) {
	var seprator = "";

	if (dtStr.indexOf("-") > -1)
		seprator = "-";
	else {
		if (dtStr.indexOf("/") > -1)
			seprator = "/";
		else {
			if (dtStr.indexOf(".") > -1)
				seprator = ".";
		}
	} // endif
	return seprator;
}

// this function converts the month(in string) into month(in integer)
function getMonthInt(str) {
	var month = -1;

	switch (str.toUpperCase()) {
	case "JAN":
		month = 0;
		break;
	case "FEB":
		month = 1;
		break;
	case "MAR":
		month = 2;
		break;
	case "APR":
		month = 3;
		break;
	case "MAY":
		month = 4;
		break;
	case "JUN":
		month = 5;
		break;
	case "JUL":
		month = 6;
		break;
	case "AUG":
		month = 7;
		break;
	case "SEP":
		month = 8;
		break;
	case "OCT":
		month = 9;
		break;
	case "NOV":
		month = 10;
		break;
	case "DEC":
		month = 11;
		break;
	}
	return month;
}

// this function parses the date inti day, month & year
function parseDate(dtStr, seprator, mode) {
	var pos1, pos2;
	var len = dtStr.length;

	initilizeVar(); // initilizes the variables
	pos1 = dtStr.indexOf(seprator);
	pos2 = dtStr.indexOf(seprator, pos1 + 1);

	if (len > 8 && len <= 11) {
		if (pos1 > 0 && pos1 <= 2) // validations for day
		{
			if (pos2 > pos1 + 1 && len == pos2 + 5) // validation for month &
			// year
			{
				// getting value seperately and convert it into int
				intDay = parseInt(dtStr.substring(0, pos1), '10');
				if (mode == 1)
					intMon = parseInt(dtStr.substring(pos1 + 1, pos2), '10');
				else
					intMon = getMonthInt(dtStr.substring(pos1 + 1, pos2)) + 1;

				intYear = parseInt(dtStr.substring(pos2 + 1), '10');
				if (intMon >= 0 && intMon <= 12) {
					if (intYear >= 1900 && intYear <= 2100) {
						if (intDay > 0
								&& intDay <= DaysInMonth(intMon, intYear))
							return true;
					}// end if
				}// endif
			}// endif
		}// endif
	}// endif
	return false;
}

// this function initilizes the global variable
function initilizeVar() {
	intDay = "";
	intMon = "";
	intYear = "";
}

// this function displays the layer and shifts the other layer after the

// displayed layer

// Note--> the layer's position property should be relative and top & left

// value should be zero

function Showlayer(obj, layerObj)

{

	if (obj.checked)

		layerObj.style.display = "BLOCK";

	else

		layerObj.style.display = "NONE";

}// 18

// this function displays the layer and shifts the other layer after the

// displayed layer

// Note--> the layer's position property should be relative and top & left

// value should be zero

function Hidelayer(layerObj)

{

	layerObj.style.display = "NONE";

}// 19
function compareDatecmpsep(mode) {

	var frValue, toValue, frYear, frMon, frDay, sts = 0;

	frDate = document.form1.donation_date.value;
	toDate = document.form1.cdt.value;

	// validating todate
	if (frDate == "" || frDate == null) {
		frValue = new Date;
		frYear = frValue.getYear();
		frMon = frValue.getMonth();
		frDay = frValue.getDate();
	} else {
		if (isDate(document.form1.donation_date, mode) == true) {
			frYear = intYear;
			frMon = intMon;
			frDay = intDay;

			if (isDate(document.form1.cdt, mode) == true) {
				if (frYear > intYear)
					sts = 1;
				else {
					if (frYear == intYear) {
						if (frMon > intMon)
							sts = 1;
						else {
							if (frMon == intMon) {
								if (frDay > intDay)
									sts = 1;
							}
						}
					}
				}
			} else {
				// toDate.focus();
				return false;
			}
		} else {
			frDate.focus();
			return false;
		}
	}

	if (sts == 1) {
		if (frDate == "" || frDate == null) // validating current date with
			// toDate
			getMsg(5, toDate.name);
		else
			$.alert.open("Donation Date is greater than  Current Date");

		// frDate.focus();
		return false;
	}

	return true;

}// 5

function compareDate_threemonths(mode) {

	var frValue, toValue, frYear, frMon, frDay, sts = 0;
	// $.alert.open("document.form1.previousdonation_date.value"+document.form1.previousdonation_date.value);
	// $.alert.open("document.form1.predate.value"+document.form1.predate.value);
	frDate = document.form1.previousdonation_date.value;
	toDate = document.form1.predate.value;

	// validating todate
	if (frDate == "" || frDate == null) {
		frValue = new Date;
		frYear = frValue.getYear();
		frMon = frValue.getMonth();
		frDay = frValue.getDate();
	} else {
		if (isDate(document.form1.previousdonation_date, mode) == true) {
			frYear = intYear;
			frMon = intMon;
			frDay = intDay;

			if (isDate(document.form1.predate, mode) == true) {
				if (frYear > intYear)
					sts = 1;
				else {
					if (frYear == intYear) {
						if (frMon > intMon)
							sts = 1;
						else {
							if (frMon == intMon) {
								if (frDay > intDay)
									sts = 1;
							}
						}
					}
				}
			} else {
				// toDate.focus();
				return false;
			}
		} else {
			frDate.focus();
			return false;
		}
	}

	if (sts == 1) {
		if (frDate == "" || frDate == null) // validating current date with
			// toDate
			getMsg(5, toDate.name);
		else {
			$.alert.open("Donor not Eligible for Donation.\nThere should be gap of 3 months b/w previous and current donation date.");
			return (confirm("Do You Want To Continue"));

		}
		// frDate.focus();
		return true;
	}

	return true;

}// 5

// function for the chekcing the email
function checkmail(obj) {
	var eindex;
	var mailstr = obj.value;
	var retVal = false;

	if (mailstr != "") {
		eindex = mailstr.indexOf('@');
		if (eindex != -1) {
			var newstr = mailstr.substring(eindex + 1);
			if (newstr.indexOf('@') == -1) {
				if (mailstr.indexOf('.') != -1
						&& (mailstr.indexOf('.') > (eindex + 1)))
					retVal = true;
			}
		}
	} else
		retVal = true;

	if (retVal == false)
		getMsg(2, obj.name);

	return retVal;
}//
function validateBeforeAddTocart(obj, fieldArray, msgArray) {
	for (var i = 0; i < obj.length; i++) {

		if (obj[i].checked == true) {

			for (var j = 0; j < fieldArray.length; j++) {

				if (fieldArray[j][i].value == ""
						|| fieldArray[j][i].value == "0") {
					$.alert.open(msgArray[j]);
					fieldArray[j][i].focus();
					fieldArray[j][i].disabled = false;
					fieldArray[j][i].style.border = "1px solid #ff0000";
					return false;
				}
			}
		}
	}
	return true;

}
function validateAvlAndReqQty(obj, field1, field2, msg) {
	for (var i = 0; i < obj.length; i++) {

		if (obj[i].checked == true) {

			// req and avl
			if (field1[i].value == "0" || field1[i].value == "") {
				$.alert.open("!!Quantity cannot be blank or zero.");
				field1[i].focus();
				field1[i].style.border = "1px solid #ff0000";
				return false;
			} else if (field1[i].value > field2[i].value) {
				$.alert.open(msg);
				field1[i].focus();
				field1[i].style.border = "1px solid #ff0000";
				return false;
			}

		}
	}
	return true;

}
function enableDisable(obj, fieldArray) {
	for (var i = 0; i < obj.length; i++) {
		if (obj[i].checked == true) {
			for (var j = 0; j < fieldArray.length; j++) {
				fieldArray[j][i].disabled = false;
			}
		} else {
			for (var j = 0; j < fieldArray.length; j++) {
				fieldArray[j][i].disabled = true;
				// fieldArray[j][i].style.border = "1px solid #ffffff";
			}
		}
	}
}

function isChecked(obj, msg) {
	var cnt = 0;
	for (var i = 0; i < obj.length; i++) {
		if (obj.checked == true) {
		}
	}
	if (cnt == 0) {
		return false;
	} else {
		return true;
	}
}
function checkCharactorCount(obj, len, msg) {
	
	if(obj.value.trim()=="")
	{
	
	}
	else if (parseInt(obj.value.trim().length) < len) {
		$.alert.open(msg);
		obj.focus();
		//obj.value="";
	}
}
function isSame(obj1, obj2) {
	if(obj1.value.trim()=="")
	{
	
	}
	else if (obj1.value == obj2.value) {
		$.alert.open(obj1.name + " and " + obj2.name + " value is same.");
	}
}
function validateEmail(sEmail) {
	if(sEmail.value=="")
	{
	return true;
	}
    var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (filter.test(sEmail.value)) {
        return true;
    }
    else {
    	$.alert.open("Invalid Email")
    	//sEmail.focus();
    	sEmail.value="";
        return false;
    }
}
function validateWebsite(myUrl)
{
	if(myUrl.value=="")
	{
	return true;
	}
///^(https:\/\/www\.|http:\/\/www\.|www.\/\/www\.)[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/
if(parseInt(myUrl.value.split(".").length) > 4){
    	$.alert.open("Invalid website");
	    myUrl.value="";
	    return false;
}
if(myUrl.value.split(".")[0].toUpperCase()=="HTTP://WWW" || myUrl.value.split(".")[0].toUpperCase()=="HTTPS://WWW"){
	
}
else if(myUrl.value.split(".")[0].toUpperCase()!="WWW"){
	$.alert.open("Invalid website");
    myUrl.value="";
    return false;
}
if(/^(http(s)?:\/\/)?(www\.)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/.test(myUrl.value)){
	
} 
else if(/^(HTTP(S)?:\/\/)?(WWW\.)?[A-Z0-9]+([\-\.]{1}[A-Z0-9]+)*\.[A-Z]{2,5}(:[0-9]{1,5})?(\/.*)?$/.test(myUrl.value)){
	
}

else {
    $.alert.open("Invalid website");
    myUrl.value="";
    //myUrl.focus();
}
}
function changeCheckboxVal(obj,uncheckVal,checkVal)
{
	if(obj.checked==true)
		{
		obj.value=checkVal;
		}
	else
		{
		
		obj.value=uncheckVal;
		}
}
function validateFax(obj)
{
	if(obj.value=="")
		{
		return true;
		}
	  if(!obj.value.match(/^1[\ \-]?\d{3}[\ \-]?\d{3}[\ \-]?\d{4}$/)){
		    $.alert.open("Please enter the FAX number in this format:\n\t1-999-999-9999");
		    obj.select();
		    obj.focus();
		    return false;
	}
		  return true;
}
function validateIpAddr(obj)
{
	
	if(obj.value=="")
		{
			return true;
		}
	  if(obj.value.split(".").length!=4){
		    $.alert.open("Please enter valid ip address.");
		    obj.value="";
		    obj.focus();
		    return false;
	}
		  return true;
}
/*
 * =========================================end of
 * file===============================================
 */

